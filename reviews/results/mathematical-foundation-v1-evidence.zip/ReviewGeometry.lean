import TensorRewriteTheory
open TensorRewrite.Theory.Convolution
private def mkAxis (n k s b d : Nat) (lo hi : Int) (rev : Bool)
    (sp : 0 < s) (bp : 0 < b) (dp : 0 < d) : Axis :=
  ⟨n,k,s,b,d,lo,hi,rev,sp,bp,dp⟩
#eval do
  let mut id := 0
  for n in List.range 3 do
    for k in List.range 3 do
      for s in [1,2] do
        for b in [1,2] do
          for d in [1,2] do
            for lo in [-2,-1,0,1,2] do
              for hi in [-1,0,1] do
                for rev in [false,true] do
                  if sp : 0 < s then
                    if bp : 0 < b then
                      if dp : 0 < d then
                        let axis := mkAxis n k s b d lo hi rev sp bp dp
                        let samples := (List.range (axis.outputExtent+2)).map fun o =>
                          (List.finRange k).map fun x =>
                            match axis.inputIndex? o x with
                            | none => -1
                            | some i => (i.val : Int)
                        IO.println s!"GEO {id} {axis.outputExtent} {repr samples}"
                  id := id+1
