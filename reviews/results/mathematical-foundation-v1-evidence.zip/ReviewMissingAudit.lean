import TensorRewrite
#check @TensorRewrite.Pilot.BooleanDag.and_rhs_true_of_isAll
#print axioms TensorRewrite.Pilot.BooleanDag.and_rhs_true_of_isAll
#check @TensorRewrite.Pilot.ControlOrder.original_forward_trace
#print axioms TensorRewrite.Pilot.ControlOrder.original_forward_trace
#check @TensorRewrite.Pilot.ControlOrder.original_forward_valid
#print axioms TensorRewrite.Pilot.ControlOrder.original_forward_valid
#check @TensorRewrite.Pilot.ControlOrder.original_requires_forward
#print axioms TensorRewrite.Pilot.ControlOrder.original_requires_forward
#check @TensorRewrite.Pilot.ControlOrder.original_reverse_impossible
#print axioms TensorRewrite.Pilot.ControlOrder.original_reverse_impossible
#check @TensorRewrite.Pilot.ControlOrder.repaired_forward_trace
#print axioms TensorRewrite.Pilot.ControlOrder.repaired_forward_trace
#check @TensorRewrite.Pilot.ControlOrder.repaired_forward_valid
#print axioms TensorRewrite.Pilot.ControlOrder.repaired_forward_valid
#check @TensorRewrite.Pilot.ControlOrder.repaired_refines_replacement
#print axioms TensorRewrite.Pilot.ControlOrder.repaired_refines_replacement
#check @TensorRewrite.Pilot.ControlOrder.repaired_requires_forward
#print axioms TensorRewrite.Pilot.ControlOrder.repaired_requires_forward
#check @TensorRewrite.Pilot.ControlOrder.repaired_reverse_impossible
#print axioms TensorRewrite.Pilot.ControlOrder.repaired_reverse_impossible
#check @TensorRewrite.Pilot.ControlOrder.replacement_admits_reverse
#print axioms TensorRewrite.Pilot.ControlOrder.replacement_admits_reverse
#check @TensorRewrite.Pilot.ControlOrder.replacement_reverse_trace
#print axioms TensorRewrite.Pilot.ControlOrder.replacement_reverse_trace
#check @TensorRewrite.Pilot.ControlOrder.replacement_reverse_valid
#print axioms TensorRewrite.Pilot.ControlOrder.replacement_reverse_valid
#check @TensorRewrite.Pilot.DynamicIndex.unsigned64_high_bit_disagrees
#print axioms TensorRewrite.Pilot.DynamicIndex.unsigned64_high_bit_disagrees
#check @TensorRewrite.Pilot.DynamicIndex.unsigned64_max_disagrees
#print axioms TensorRewrite.Pilot.DynamicIndex.unsigned64_max_disagrees
#check @TensorRewrite.Pilot.DynamicIndex.unsigned64_not_universally_equal
#print axioms TensorRewrite.Pilot.DynamicIndex.unsigned64_not_universally_equal
#check @TensorRewrite.Pilot.Float32Exceptional.canonical_nan_allowed
#print axioms TensorRewrite.Pilot.Float32Exceptional.canonical_nan_allowed
#check @TensorRewrite.Pilot.NestedUnsigned64.both_high_changes
#print axioms TensorRewrite.Pilot.NestedUnsigned64.both_high_changes
#check @TensorRewrite.Pilot.NestedUnsigned64.inner_high_changes
#print axioms TensorRewrite.Pilot.NestedUnsigned64.inner_high_changes
#check @TensorRewrite.Pilot.NestedUnsigned64.not_universally_preserving
#print axioms TensorRewrite.Pilot.NestedUnsigned64.not_universally_preserving
#check @TensorRewrite.Pilot.NestedUnsigned64.outer_high_changes
#print axioms TensorRewrite.Pilot.NestedUnsigned64.outer_high_changes
#check @TensorRewrite.Pilot.SelectContraction.false_witness
#print axioms TensorRewrite.Pilot.SelectContraction.false_witness
#check @TensorRewrite.Pilot.SelectContraction.true_witness
#print axioms TensorRewrite.Pilot.SelectContraction.true_witness
#check @TensorRewrite.Pilot.SliceShape.empty_witness_well_formed
#print axioms TensorRewrite.Pilot.SliceShape.empty_witness_well_formed
#check @TensorRewrite.Pilot.SliceShape.remove_redundant_stride_witness
#print axioms TensorRewrite.Pilot.SliceShape.remove_redundant_stride_witness
#check @TensorRewrite.Pilot.SliceShape.reorder_reverse_witness
#print axioms TensorRewrite.Pilot.SliceShape.reorder_reverse_witness
#check @TensorRewrite.Pilot.ZeroMacProfile.negative_zero_incompatible
#print axioms TensorRewrite.Pilot.ZeroMacProfile.negative_zero_incompatible
#check @TensorRewrite.Pilot.ZeroMacProfile.one_mac_positive
#print axioms TensorRewrite.Pilot.ZeroMacProfile.one_mac_positive
#check @TensorRewrite.Pilot.ZeroMacProfile.positive_zero_consistent
#print axioms TensorRewrite.Pilot.ZeroMacProfile.positive_zero_consistent
#check @TensorRewrite.Pilot.ZeroMacProfile.zero_bits_differ
#print axioms TensorRewrite.Pilot.ZeroMacProfile.zero_bits_differ
