import TensorRewrite
import TensorRewriteTheory
import Lean
open Lean Elab Command
run_cmd do
  let env ← getEnv
  for (name, info) in env.constants.toList do
    if (name.toString.splitOn "TensorRewrite.").length > 1 then
      match info with
      | .thmInfo _ => logInfo m!"PROJECT_THEOREM {name}"
      | .axiomInfo _ => logInfo m!"PROJECT_AXIOM {name}"
      | _ => pure ()
