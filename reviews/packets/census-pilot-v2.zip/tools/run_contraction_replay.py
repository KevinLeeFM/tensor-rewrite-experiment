"""Execute and archive a fresh modular arithmetic replay against the pinned real XLA pass."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import time
from contraction_cases import expected_word_rows,expected_fp_rows

ROOT = Path(__file__).resolve().parents[1]
TARGET = '//xla/hlo/transforms/simplifiers:contraction_replay_test'
PASS_SHA = '1ecfd7d4ba958ac0e795d8663c14f7f6b1ebd147a8a83ed0e99661740105628f'
COMMIT = 'e58e523b11f1fde802a493a776d158007486e1bf'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', required=True, help='new reports/ directory basename')
    args = parser.parse_args()
    if not re.fullmatch(r'contraction-replay-v[0-9]+', args.archive):
        raise ValueError('archive must be an explicit contraction-replay-vN basename')
    out = ROOT / 'reports' / args.archive
    if out.exists():
        raise ValueError('refusing to overwrite an existing archive')
    repo = ROOT / 'external/xla'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip() == COMMIT
    pass_source = repo / 'xla/hlo/transforms/simplifiers/algebraic_simplifier.cc'
    assert digest(pass_source) == PASS_SHA
    fixture = ROOT / 'tests/xla/contraction_replay_test.cc'
    assert digest(fixture) == digest(repo / 'xla/hlo/transforms/simplifiers' / fixture.name)
    out.mkdir()
    shutil.copyfile(fixture, out / 'fixture.cc')
    shutil.copyfile(repo / 'xla/hlo/transforms/simplifiers/BUILD', out / 'BUILD')
    command = [str(ROOT / '.build-tools/bazel'), '--output_user_root=' + str(ROOT / '.build-cache/bazel'),
               'test', TARGET, '--compilation_mode=opt', '--jobs=12',
               '--repo_env=HERMETIC_PYTHON_VERSION=3.12',
               '--repository_cache=' + str(ROOT / '.build-cache/repos'),
               '--test_output=all', '--nocache_test_results',
               '--build_event_json_file=' + str(out / 'events.json'), '--noshow_progress']
    started = time.monotonic()
    with (out / 'build.log').open('w') as log:
        run = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
    elapsed = time.monotonic() - started
    testpath = 'xla/hlo/transforms/simplifiers/contraction_replay_test'
    for name in ('test.log', 'test.xml'):
        path = repo / 'bazel-testlogs' / testpath / name
        if path.exists():
            shutil.copyfile(path, out / name)
    log = (out / 'test.log').read_text() if (out / 'test.log').exists() else ''
    rows=re.findall(r'^CONTRACTION_RESULT case=(\w+) mode=(control|handler|pass) changed=([01]) checked=(\d+) values=([-0-9,]+|empty) rewritten_verified=1$',log,re.M)
    fp_rows=re.findall(r'^CONTRACTION_FP_RESULT case=(\w+) mode=(control|handler|pass) changed=([01]) before=([0-9,]+) after=([0-9,]+) bits_equal=([01]) numeric_equal=1 rewritten_verified=1 rne=1$',log,re.M)
    expected=expected_word_rows()
    binary=repo/'bazel-bin'/testpath
    passed=run.returncode==0 and rows==expected and fp_rows==expected_fp_rows()
    result=dict(schema=1,status='integer_dot_preserved_signed_zero_difference_observed' if passed else 'replay_failed',
                source_commit=COMMIT,pass_source_sha256=PASS_SHA,command=command,
                xla_full_pass_run=any(m=='pass' for _,m,*_ in rows),xla_handler_run=bool(rows),
                native_operator_evaluation=True if passed else False,
                execution_scope='static Dot zero/no-contract axes; s8/s32 casts to s32 result; initialized handler/pass; f32 RNE signed-zero diagnostic; backend permissions pending',
                handler_initialization='public Run with only HandleDot suppressed on unchanged parameter/Dot graph; then original base handler',
                fp_diagnostic_is_source_refutation=False,
                test_passed=passed,exit_code=run.returncode,elapsed_seconds=elapsed,
                binary_sha256=digest(binary) if binary.exists() else None,
                word_cases=[dict(name=n,mode=m,changed=c=='1',checked=int(k),values=[] if v=='empty' else list(map(int,v.split(','))),rewritten_verified=True)
                       for n,m,c,k,v in rows],
                fp_cases=[dict(name=n,mode=m,changed=c=='1',before=list(map(int,b.split(','))),after=list(map(int,a.split(','))),bits_equal=e=='1',numeric_equal=True,rewritten_verified=True,rne=True)
                       for n,m,c,b,a,e in fp_rows],
                files=[dict(path=str(p.relative_to(ROOT)),sha256=digest(p)) for p in sorted(out.iterdir()) if p.is_file()])
    (out / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: result[k] for k in ('status', 'exit_code', 'test_passed', 'elapsed_seconds')}, indent=2))
    print((out / 'build.log').read_text()[-12000:])
    if not passed:
        raise SystemExit(run.returncode or 1)


if __name__ == '__main__':
    main()
