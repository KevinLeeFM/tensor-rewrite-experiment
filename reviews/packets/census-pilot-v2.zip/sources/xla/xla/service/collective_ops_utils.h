/* Copyright 2019 The OpenXLA Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#ifndef XLA_SERVICE_COLLECTIVE_OPS_UTILS_H_
#define XLA_SERVICE_COLLECTIVE_OPS_UTILS_H_

#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "absl/log/log.h"
#include "absl/status/statusor.h"
#include "absl/strings/string_view.h"
#include "absl/types/span.h"
#include "xla/core/collectives/reduction_kind.h"
#include "xla/hlo/ir/collective_op_group_mode.h"
#include "xla/hlo/ir/hlo_instruction.h"
#include "xla/hlo/ir/hlo_instructions.h"
#include "xla/hlo/ir/hlo_opcode.h"
#include "xla/hlo/ir/replica_group.h"
#include "xla/literal.h"
#include "xla/runtime/device_id.h"
#include "xla/service/computation_placer.h"
#include "xla/service/source_target_pairs.h"
#include "xla/xla.pb.h"
#include "xla/xla_data.pb.h"

namespace xla {

//===----------------------------------------------------------------------===//
// Reduction utilities.
//===----------------------------------------------------------------------===//

absl::StatusOr<ReductionKind> StringToReductionKind(
    absl::string_view reduction_kind);

// Returns the ReductionKind corresponding to the given HloOpcode and
// PrimitiveType.
// Returns std::nullopt if the HloOpcode cannot be mapped to a ReductionKind.
std::optional<ReductionKind> OpcodeToReductionKind(HloOpcode hlo_opcode,
                                                   PrimitiveType type);

// Attempts to match instruction to one of the possible cases for
// ReductionKind.
std::optional<ReductionKind> MatchReductionInstruction(
    const HloInstruction* hlo);

// Attempts to match computation to one of the possible cases in ReductionKind.
std::optional<ReductionKind> MatchReductionComputation(
    const HloComputation* computation);

// Creates a computation that performs a reduction operation.
std::unique_ptr<HloComputation> MakeReductionComputation(
    ReductionKind reduction_kind, PrimitiveType element_type);

// Returns the HloOpcode corresponding to the given ReductionKind.
// Certain reduction kinds can map to different opcodes depending on the
// element type (e.g. ReductionKind::MIN maps to kMinimum for numeric types and
// kAnd for PRED).
HloOpcode ReductionKindToOpcode(ReductionKind reduction_kind,
                                PrimitiveType element_type);

// Returns the reduction identity value for a certain ReductionKind and
// PrimitiveType.
std::optional<Literal> GetReductionIdentity(ReductionKind kind,
                                            PrimitiveType type);

//===----------------------------------------------------------------------===//
// Collective operation classification.
//===----------------------------------------------------------------------===//

// Returns true if instruction is a collective op that is not a collective
// fusion.
bool IsNonFusionCollective(const HloInstruction* instruction);

// Returns true if instruction is a collective op or a collective fusion.
bool IsCollective(const HloInstruction* instruction);

// Returns true if instruction is an async collective op.
absl::StatusOr<bool> IsAsyncCollective(const HloInstruction* instruction);

// Returns true if instruction is a RaggedAllToAll op or an async-start that
// wraps a RaggedAllToAll op.
bool IsRaggedAllToAllOrAsyncStartRaggedAllToAll(
    const HloInstruction* instruction);

// Returns true if instruction is a RaggedAllToAll op or an async-done that
// wraps a RaggedAllToAll op.
bool IsRaggedAllToAllOrAsyncDoneRaggedAllToAll(
    const HloInstruction* instruction);

// Returns the collective instruction if argument is a collective op (or a
// collective fusion) with channel_id.
HloInstruction* IsOrHasCollectiveWithChannelId(HloInstruction* instruction);

//===----------------------------------------------------------------------===//
// Replica group utilities.
//===----------------------------------------------------------------------===//

// Figures out which IDs are participating in the collective subgroup.
// An empty `groups` indicates that all [0, total_participant_count) IDs
// are participating. Note that for CollectiveOpGroupMode::kFlattenedID,
// groups cannot be empty, so `total_participant_count` is an optional.
absl::StatusOr<std::vector<int>> GetParticipatingIDs(
    CollectiveOpGroupMode group_mode, int current_id,
    std::optional<int> total_participant_count,
    absl::Span<const ReplicaGroup> replica_groups);

absl::StatusOr<std::vector<int>> GetParticipatingIDs(
    CollectiveOpGroupMode group_mode, int current_id,
    std::optional<int> total_participant_count,
    const CollectiveDeviceListBase& groups);

// Returns the replica groups for the given async collective instruction.
absl::StatusOr<std::unique_ptr<CollectiveDeviceListBase>> GetAsyncReplicaGroups(
    const HloInstruction* instruction);

// Returns the group formation mode of instr, assuming that instr is, or is
// derived from on the following instructions:
//   * HloAllGatherInstruction
//   * HloAllReduceInstructionBase
//   * HloAllToAllInstruction
//   * HloCollectiveBroadcastInstruction
//   * HloCollectivePermuteInstruction
//   * HloRaggedAllToAllInstruction
absl::StatusOr<CollectiveOpGroupMode> GetCollectiveOpGroupMode(
    const HloInstruction* instr);

// Returns the flattened IDs in each participating replica group.
absl::StatusOr<std::unique_ptr<CollectiveDeviceListBase>>
GetParticipatingFlattenedIdGroups(
    const DeviceAssignment& device_assignment,
    const CollectiveDeviceListBase& collective_device_list,
    CollectiveOpGroupMode group_mode);

// Same as above, but takes replica and partition counts instead of a device
// assignment.
absl::StatusOr<std::unique_ptr<CollectiveDeviceListBase>>
GetParticipatingFlattenedIdGroups(
    const CollectiveDeviceListBase& collective_device_list,
    CollectiveOpGroupMode group_mode, int replica_count, int partition_count);

// Same as above, with collective group mode determined by the collective
// instruction.
absl::StatusOr<std::unique_ptr<CollectiveDeviceListBase>>
GetParticipatingFlattenedIdGroups(const HloInstruction* hlo,
                                  const DeviceAssignment& device_assignment);

// Figures out how many ranks are participating in each collective subgroup.
absl::StatusOr<std::vector<int64_t>> GetParticipantCountsForReplicaGroups(
    int64_t num_replicas, int64_t num_partitions,
    absl::Span<const ReplicaGroup> replica_groups,
    CollectiveOpGroupMode group_mode);

absl::StatusOr<std::optional<std::pair<int64_t, int64_t>>>
GetReplicaGroupCountAndSize(const HloInstruction* hlo);

// Returns true if the two replica groups are orthogonal.
bool ReplicaGroupsOrthogonal(absl::Span<const ReplicaGroup> first,
                             absl::Span<const ReplicaGroup> second);

// Returns true if the two replica groups are equal.
bool ReplicaGroupsEqual(absl::Span<const ReplicaGroup> first,
                        absl::Span<const ReplicaGroup> second);

// Returns true if all subgroups in replica_groups are exclusively cross-module.
bool IsExclusivelyCrossModule(absl::Span<const ReplicaGroup> replica_groups,
                              bool use_global_ids, bool has_channel_id,
                              const DeviceAssignment& device_assignment);

// Returns true if all subgroups in replica_groups are exclusively
// cross-replica.
bool IsExclusivelyCrossReplica(absl::Span<const ReplicaGroup> replica_groups,
                               bool use_global_ids, bool has_channel_id,
                               const DeviceAssignment& device_assignment);

int64_t GetSubgroupSize(const HloCollectiveInstruction* hlo,
                        CollectiveOpGroupMode group_mode);

//===----------------------------------------------------------------------===//
// Global device ID utilities.
//===----------------------------------------------------------------------===//

// Figures out subgroups of participating devices from given replica_groups and
// group_mode.
//
// Returns list of participants, where each participant is a list of
// GlobalDeviceIds.
//
// For example:
//   device_assignment={{33, 34}, {44, 45}, {55, 56}}  3 replicas 2 partitions
//   replica_groups={{0}, {1, 2}}
//   group_mode=CollectiveOpGroupMode::kCrossReplica
//
//   This functions returns {{33}, {34}, {44, 45}, {55, 56}}.
//   Partition 0 has 2 subgroups of participating devices {33}, {44, 55} and
//   partition 1 has 2 subgroups of participating devices {34}, {45, 56}.
//
// Another example:
//   device_assignment={{33, 34}, {44, 45}, {55, 56}}  3 replicas 2 partitions
//   replica_groups={{0}, {1, 2}, {3, 4, 5}}
//   group_mode=CollectiveOpGroupMode::kFlattenedID
//
//   This functions returns {{33}, {34, 44}, {45, 55, 56}}. The replica_ids map
//   into a flattened version of device_assignment.
absl::StatusOr<std::vector<std::vector<GlobalDeviceId>>>
GetParticipatingDevicesGroups(const DeviceAssignment& device_assignment,
                              absl::Span<const ReplicaGroup> replica_groups,
                              CollectiveOpGroupMode group_mode);

// Returns the groups of global devices that communicate in `collective`.
absl::StatusOr<std::vector<std::vector<GlobalDeviceId>>>
GetParticipatingDevicesGroups(const HloInstruction& collective,
                              const DeviceAssignment& device_assignment);

// Same as above, except using the static device assignment from the module.
absl::StatusOr<std::vector<std::vector<GlobalDeviceId>>>
GetParticipatingDevicesGroups(const HloInstruction* collective);

// Figures out which devices are participating in the collective subgroup.
absl::StatusOr<std::vector<GlobalDeviceId>> GetParticipatingDevices(
    GlobalDeviceId device_id, const DeviceAssignment& device_assignment,
    absl::Span<const ReplicaGroup> replica_groups,
    CollectiveOpGroupMode group_mode);

//===----------------------------------------------------------------------===//
// Point-to-point utilities.
//===----------------------------------------------------------------------===//

bool HasDuplicateSourcesOrTargets(const SourceTargetPairs& pairs);

// We only pipeline Send-Recv chains with channel_id > 0, where each chain has a
// unique channel_id, and allow multiple Send-Recv chains using channel_id 0.
inline bool MayPipelineSendRecvChannel(int64_t channel_id) {
  return channel_id > 0;
}

// When a Send or Recv is annotated with frontend attribute
// _xla_send_recv_pipeline="1", asynchronous stream kP2P1 is used to execute the
// Send or Recv. For all other cases, asynchronous stream kP2P0 is used.
inline constexpr char kSendRecvPipelineAttr[] = "_xla_send_recv_pipeline";

// Attribute to indicate that collective operations should be issued on a
// dedicated p2p stream. This is a hint and there is no guarantee that this will
// be honored.
inline constexpr absl::string_view kCollectiveStreamAttrName =
    "_xla_gpu_collective_stream";
inline constexpr absl::string_view kCollectiveStreamP2P = "p2p";

//===----------------------------------------------------------------------===//
// Collective group attributes.
//===----------------------------------------------------------------------===//

// Returns the nonempty collective_group_key frontend attribute. An absent or
// empty attribute does not opt the instruction into collective grouping.
std::optional<absl::string_view> GetCollectiveGroupKey(
    const HloInstruction& instruction);

// Returns whether an instruction has a nonempty collective_group_key frontend
// attribute.
bool HasCollectiveGroupKey(const HloInstruction& instruction);

// Returns whether two distinct collective payloads may be coalesced without
// changing explicit collective groups. Nonempty collective group keys must
// match; an absent or empty key matches only another absent or empty key.
// This compatibility check must not gate common-subexpression elimination or
// decomposition into an equivalent sequence of operations.
bool HaveCompatibleCollectiveGroupKeys(const HloInstruction& lhs,
                                       const HloInstruction& rhs);

// Copies the collective_group_key from `source` to `destination`. Attribute
// absence is copied as well, so any existing key on `destination` is cleared.
void CopyCollectiveGroupKey(const HloInstruction& source,
                            HloInstruction& destination);

// Removes the collective_group_key attribute.
void ClearCollectiveGroupKey(HloInstruction& instruction);

//===----------------------------------------------------------------------===//
// Collective execution utilities.
//===----------------------------------------------------------------------===//

// A custom call target that can be used to create a nop that can legally
// replace a collective op.
inline constexpr absl::string_view kNopCustomCallTarget = "AllocateBuffer";
// A custom call target that can be used to create a nop that can legally
// replace a collective op and it returns a token.
inline constexpr absl::string_view kNopReturnTokenCustomCallTarget =
    "NopReturnToken";

// Returns true if the one-shot RaggedAllToAll with NCCL feature is enabled.
bool IsOneShotRaggedAllToAllWithNcclEnabled(const DebugOptions& opts);

class NcclSymmetricBuffersSpec {
 public:
  explicit NcclSymmetricBuffersSpec(const DebugOptions& debug_options);

  bool IsEnabled(const HloInstruction& inst) const;

 private:
  struct Filter {
    DebugOptions::CollectiveOpType collective;
    std::optional<int64_t> max_size_bytes;
    std::optional<PrimitiveType> op_type;
  };
  std::vector<Filter> filters_;
};

bool IsNcclSymmetricBuffersEnabledForCollective(
    const HloInstruction* instruction, const DebugOptions& opts);

// Returns the CollectiveOpType corresponding to the given instruction, or
// std::nullopt if the instruction is not a recognized collective operation.
std::optional<DebugOptions::CollectiveOpType> GetCollectiveOpType(
    const HloInstruction* instruction);

//===----------------------------------------------------------------------===//
// Async collective configuration.
//===----------------------------------------------------------------------===//

struct AsyncCollectiveConfig {
  std::vector<ReplicaGroup> replica_groups;
  std::optional<int64_t> channel_id;
  bool use_global_device_ids = false;
  std::vector<std::pair<int64_t, int64_t>> permutation;
  std::optional<int64_t> all_gather_dimension;
  std::optional<int64_t> scatter_dimension;
  std::optional<bool> tiled;
  std::optional<int64_t> split_dimension;
  std::optional<int64_t> concat_dimension;
  std::optional<int64_t> split_count;
};

absl::StatusOr<AsyncCollectiveConfig> ParseAsyncCollectiveConfig(
    absl::string_view config_json_str);

std::string SerializeAsyncCollectiveConfig(const AsyncCollectiveConfig& config);

}  // end namespace xla

#endif  // XLA_SERVICE_COLLECTIVE_OPS_UTILS_H_
