/* Copyright 2018 The OpenXLA Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "xla/hlo/ir/hlo_instructions.h"

#include <cstdint>
#include <deque>
#include <functional>
#include <iterator>
#include <memory>
#include <optional>
#include <string>
#include <utility>
#include <vector>

#include "absl/algorithm/container.h"
#include "absl/container/flat_hash_map.h"
#include "absl/container/flat_hash_set.h"
#include "absl/container/inlined_vector.h"
#include "absl/functional/function_ref.h"
#include "absl/log/check.h"
#include "absl/log/die_if_null.h"
#include "absl/log/log.h"
#include "absl/memory/memory.h"
#include "absl/status/status.h"
#include "absl/status/status_macros.h"
#include "absl/strings/escaping.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/string_view.h"
#include "absl/types/span.h"
#include "tsl/platform/protobuf.h"
#include "xla/comparison_util.h"
#include "xla/hlo/ir/dfs_hlo_visitor.h"
#include "xla/hlo/ir/hlo_casting_utils.h"
#include "xla/hlo/ir/hlo_clone_context.h"
#include "xla/hlo/ir/hlo_computation.h"
#include "xla/hlo/ir/hlo_instruction.h"
#include "xla/hlo/ir/hlo_module.h"
#include "xla/hlo/ir/hlo_opcode.h"
#include "xla/hlo/ir/hlo_original_value.h"
#include "xla/hlo/ir/hlo_print_options.h"
#include "xla/hlo/ir/hlo_sharding.h"
#include "xla/hlo/ir/replica_group.h"
#include "xla/layout.h"
#include "xla/layout_util.h"
#include "xla/literal.h"
#include "xla/literal_util.h"
#include "xla/map_util.h"
#include "xla/printer.h"
#include "xla/protobuf_util.h"
#include "xla/service/hlo.pb.h"
#include "xla/shape.h"
#include "xla/shape_util.h"
#include "xla/tsl/lib/gtl/iterator_range.h"
#include "xla/util.h"
#include "xla/window_util.h"
#include "xla/xla_data.pb.h"

namespace xla {
namespace {

using absl::CEscape;
using absl::StrCat;

bool IsInstructionElementwiseOnOperand(const HloInstruction* instruction,
                                       const HloInstruction* operand) {
  return absl::c_all_of(
      instruction->OperandIndices(operand),
      [instruction](int64_t operand_index) {
        return instruction->IsElementwiseOnOperand(operand_index);
      });
}

void PrintPrecisionConfig(HloInstruction::AttributePrinter& printer,
                          const PrecisionConfig& precision_config) {
  if (absl::c_any_of(
          precision_config.operand_precision(), [](int32_t precision) {
            return static_cast<PrecisionConfig::Precision>(precision) !=
                   PrecisionConfig::DEFAULT;
          })) {
    printer.Next([&precision_config](Printer* printer) {
      printer->Append("operand_precision={");
      AppendJoin(printer, precision_config.operand_precision(), ",",
                 [](Printer* printer, int32_t precision) {
                   CHECK(PrecisionConfig::Precision_IsValid(precision))
                       << precision;
                   printer->Append(PrecisionToString(
                       static_cast<PrecisionConfig::Precision>(precision)));
                 });
      printer->Append("}");
    });
  }

  if (precision_config.algorithm() != PrecisionConfig::ALG_UNSET) {
    printer.Next([&precision_config](Printer* printer) {
      printer->Append("algorithm=");
      printer->Append(AlgorithmToString(precision_config.algorithm()));
    });
  }
}

std::string ConvolutionKindToString(ConvolutionKind kind) {
  switch (kind) {
    case CONVOLUTION_KIND_FPROP:
      return "fprop";
    case CONVOLUTION_KIND_WGRAD:
      return "wgrad";
    case CONVOLUTION_KIND_DGRAD:
      return "dgrad";
    case CONVOLUTION_KIND_UNSET:
      return "unset";
    default:
      return absl::StrCat("unknown(", static_cast<int>(kind), ")");
  }
}

void SetThreadName(HloComputation* called_computation,
                   absl::string_view execution_thread) {
  called_computation->SetExecutionThread(execution_thread);
  for (HloInstruction* instr : called_computation->instructions()) {
    if (instr->IsAsynchronous()) {
      continue;
    }
    for (HloComputation* nested_called_computation :
         instr->called_computations()) {
      SetThreadName(nested_called_computation, execution_thread);
    }
  }
}

}  // namespace

HloBatchNormInstruction::HloBatchNormInstruction(
    HloOpcode opcode, const Shape& shape, HloInstruction* operand,
    HloInstruction* scale, float epsilon, int64_t feature_index)
    : HloInstruction(opcode, shape),
      epsilon_(epsilon),
      feature_index_(feature_index) {
  AppendOperand(operand);
  AppendOperand(scale);
}

bool HloBatchNormInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloBatchNormInstruction&>(other);
  return feature_index() == casted_other.feature_index() &&
         epsilon() == casted_other.epsilon();
}

void HloBatchNormInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_epsilon(epsilon_);
  proto->set_feature_index(feature_index_);
}

void HloBatchNormInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next(
      [this](Printer* printer) { AppendCat(printer, "epsilon=", epsilon()); });
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "feature_index=", feature_index());
  });
}

HloBatchNormTrainingInstruction::HloBatchNormTrainingInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* scale,
    HloInstruction* offset, float epsilon, int64_t feature_index)
    : HloBatchNormInstruction(HloOpcode::kBatchNormTraining, shape, operand,
                              scale, epsilon, feature_index) {
  AppendOperand(offset);
}

std::unique_ptr<HloInstruction>
HloBatchNormTrainingInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 3);
  return std::make_unique<HloBatchNormTrainingInstruction>(
      shape, new_operands[0], new_operands[1], new_operands[2], epsilon(),
      feature_index());
}

HloBatchNormInferenceInstruction::HloBatchNormInferenceInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* scale,
    HloInstruction* offset, HloInstruction* mean, HloInstruction* variance,
    float epsilon, int64_t feature_index)
    : HloBatchNormInstruction(HloOpcode::kBatchNormInference, shape, operand,
                              scale, epsilon, feature_index) {
  AppendOperand(offset);
  AppendOperand(mean);
  AppendOperand(variance);
}

std::unique_ptr<HloInstruction>
HloBatchNormInferenceInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 5);
  return std::make_unique<HloBatchNormInferenceInstruction>(
      shape, new_operands[0], new_operands[1], new_operands[2], new_operands[3],
      new_operands[4], epsilon(), feature_index());
}

HloBatchNormGradInstruction::HloBatchNormGradInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* scale,
    HloInstruction* mean, HloInstruction* variance, HloInstruction* grad_output,
    float epsilon, int64_t feature_index)
    : HloBatchNormInstruction(HloOpcode::kBatchNormGrad, shape, operand, scale,
                              epsilon, feature_index) {
  AppendOperand(mean);
  AppendOperand(variance);
  AppendOperand(grad_output);
}

std::unique_ptr<HloInstruction>
HloBatchNormGradInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 5);
  return std::make_unique<HloBatchNormGradInstruction>(
      shape, new_operands[0], new_operands[1], new_operands[2], new_operands[3],
      new_operands[4], epsilon(), feature_index());
}

HloFftInstruction::HloFftInstruction(const Shape& shape,
                                     HloInstruction* operand, FftType fft_type,
                                     absl::Span<const int64_t> fft_length)
    : HloInstruction(HloOpcode::kFft, shape),
      fft_type_(fft_type),
      fft_length_(fft_length.begin(), fft_length.end()) {
  AppendOperand(operand);
}

void HloFftInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_fft_type(fft_type_);
  for (int64_t fft_len : fft_length_) {
    proto->add_fft_length(fft_len);
  }
}

void HloFftInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "fft_type=", FftType_Name(fft_type()));
  });
  printer.Next([this](Printer* printer) {
    printer->Append("fft_length={");
    AppendJoin(printer, fft_length(), ",");
    printer->Append("}");
  });
}

bool HloFftInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloFftInstruction&>(other);
  return fft_type() == casted_other.fft_type() &&
         fft_length() == casted_other.fft_length();
}

std::unique_ptr<HloInstruction> HloFftInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloFftInstruction>(shape, new_operands[0], fft_type_,
                                             fft_length_);
}

namespace {

HloAsyncInstruction* FindAsyncChainDataflow(
    HloInstruction* instr,
    absl::FunctionRef<bool(const HloInstruction*)> is_target, ShapeIndex index,
    absl::flat_hash_set<const HloInstruction*>& visited) {
  if (instr == nullptr || !visited.insert(instr).second) {
    return nullptr;
  }

  if (is_target(instr)) {
    if (HloAsyncInstruction::ClassOf(instr)) {
      return Cast<HloAsyncInstruction>(instr);
    }
    return nullptr;
  }

  auto revert_step = [&]() { visited.erase(instr); };

  switch (instr->opcode()) {
    case HloOpcode::kGetTupleElement: {
      index.push_back(instr->tuple_index());
      HloAsyncInstruction* res = FindAsyncChainDataflow(
          instr->mutable_operand(0), is_target, index, visited);
      if (res != nullptr) {
        return res;
      }
      revert_step();
      return nullptr;
    }
    case HloOpcode::kTuple:
    case HloOpcode::kOptimizationBarrier: {
      if (instr->opcode() == HloOpcode::kOptimizationBarrier &&
          instr->operand_count() == 1) {
        HloAsyncInstruction* res = FindAsyncChainDataflow(
            instr->mutable_operand(0), is_target, index, visited);
        if (res != nullptr) {
          return res;
        }
        revert_step();
        return nullptr;
      }
      if (index.empty()) {
        // Reaching a kTuple with an empty ShapeIndex means `instr` rebuilds the
        // async context tuple `((operands...), output, sync_state...)` itself.
        // Element 0 only forwards the input operands, which sibling async ops
        // can share after tuple simplification or buffer assignment:
        //
        //   small = ((f32[8,4]), f32[2,4], s32[]) async-start(buf), ...
        //   big   = ((f32[8,4]), f32[4,4], s32[]) async-start(buf), ...
        //   ops   = (f32[8,4]) tuple(gte(gte(small, 0), 0))  // shared `buf`
        //   ctx   = ((f32[8,4]), f32[4,4], s32[])
        //             tuple(ops, gte(big, 1), gte(big, 2))
        //   done  = f32[4,4] async-done(ctx)
        //
        // Visiting operand 0 first would follow `ops` into `small` and bind
        // `done` to the wrong computation. Visit elements 1..n-1 (the output
        // and sync state uniquely produced by `big`) before element 0.
        const int64_t n = instr->operand_count();
        for (int64_t i = 1; i <= n; ++i) {
          HloAsyncInstruction* res = FindAsyncChainDataflow(
              instr->mutable_operand(i % n), is_target, index, visited);
          if (res != nullptr) {
            return res;
          }
        }
        revert_step();
        return nullptr;
      }
      int64_t idx = index.back();
      index.pop_back();
      if (idx >= 0 && idx < instr->operand_count()) {
        HloAsyncInstruction* res = FindAsyncChainDataflow(
            instr->mutable_operand(idx), is_target, index, visited);
        if (res != nullptr) {
          return res;
        }
      }
      revert_step();
      return nullptr;
    }
    case HloOpcode::kCopy:
    case HloOpcode::kCustomCall: {
      if (instr->opcode() == HloOpcode::kCustomCall &&
          !instr->IsAllowedAsyncIntermediaryCustomCall()) {
        revert_step();
        return nullptr;
      }
      if (instr->operand_count() > 0) {
        HloAsyncInstruction* res = FindAsyncChainDataflow(
            instr->mutable_operand(0), is_target, index, visited);
        if (res != nullptr) {
          return res;
        }
      }
      revert_step();
      return nullptr;
    }
    case HloOpcode::kParameter: {
      HloComputation* comp = instr->parent();
      if (comp == nullptr) {
        revert_step();
        return nullptr;
      }
      // A body can have several while callers while a pass holds a widened
      // clone of an enclosing loop next to the not yet removed original. The
      // clones carry the same chain, so any caller resolves it.
      bool is_while_body = false;
      for (HloInstruction* while_op :
           comp->caller_instructions(HloOpcode::kWhile)) {
        if (while_op->while_body() != comp) {
          continue;
        }
        is_while_body = true;
        HloAsyncInstruction* res = FindAsyncChainDataflow(
            while_op->mutable_operand(0), is_target, index, visited);
        if (res != nullptr) {
          return res;
        }
      }
      if (is_while_body && comp->root_instruction() != nullptr) {
        HloAsyncInstruction* root_res = FindAsyncChainDataflow(
            comp->root_instruction(), is_target, index, visited);
        if (root_res != nullptr) {
          return root_res;
        }
      }
      revert_step();
      return nullptr;
    }
    case HloOpcode::kWhile: {
      if (instr->while_body() != nullptr &&
          instr->while_body()->root_instruction() != nullptr) {
        HloAsyncInstruction* root_res = FindAsyncChainDataflow(
            instr->while_body()->root_instruction(), is_target, index, visited);
        if (root_res != nullptr) {
          return root_res;
        }
      }
      if (instr->operand_count() > 0) {
        HloAsyncInstruction* res = FindAsyncChainDataflow(
            instr->mutable_operand(0), is_target, index, visited);
        if (res != nullptr) {
          return res;
        }
      }
      revert_step();
      return nullptr;
    }
    default: {
      revert_step();
      return nullptr;
    }
  }
}

HloAsyncInstruction* FindAsyncChainProducer(HloInstruction* instr) {
  if (instr == nullptr) {
    return nullptr;
  }
  if (instr->IsAsyncProducer() && HloAsyncInstruction::ClassOf(instr)) {
    return Cast<HloAsyncInstruction>(instr);
  }
  ShapeIndex index;
  absl::flat_hash_set<const HloInstruction*> visited;
  return FindAsyncChainDataflow(
      instr, [](const HloInstruction* node) { return node->IsAsyncProducer(); },
      index, visited);
}

HloAsyncInstruction* FindAsyncChainStart(HloInstruction* instr) {
  if (instr == nullptr) {
    return nullptr;
  }
  if (instr->opcode() == HloOpcode::kAsyncStart &&
      HloAsyncInstruction::ClassOf(instr)) {
    return Cast<HloAsyncInstruction>(instr);
  }
  if (instr->opcode() == HloOpcode::kAsyncDone) {
    if (instr->operand_count() == 0 || instr->operand(0) == nullptr) {
      return nullptr;
    }
    instr = instr->mutable_operand(0);
  }
  HloAsyncInstruction* producer = FindAsyncChainProducer(instr);
  while (producer != nullptr && producer->opcode() == HloOpcode::kAsyncUpdate) {
    if (producer->operand_count() == 0 || producer->operand(0) == nullptr) {
      return nullptr;
    }
    producer = FindAsyncChainProducer(producer->mutable_operand(0));
  }
  return producer;
}

HloAsyncInstruction* FindAsyncChainNext(HloInstruction* instr) {
  if (instr == nullptr || instr->opcode() == HloOpcode::kAsyncDone) {
    return nullptr;
  }
  for (HloInstruction* user : instr->users()) {
    if (HloAsyncInstruction::ClassOf(user) && user->operand_count() > 0 &&
        user->operand(0) == instr) {
      return Cast<HloAsyncInstruction>(user);
    }
  }
  HloInstruction* root_producer = FindAsyncChainProducer(instr);
  if (root_producer == nullptr) {
    return nullptr;
  }
  absl::InlinedVector<HloInstruction*, 8> stack;
  absl::flat_hash_set<const HloInstruction*> visited;
  for (HloInstruction* user : instr->users()) {
    stack.push_back(user);
  }
  while (!stack.empty()) {
    HloInstruction* curr = stack.back();
    stack.pop_back();
    if (curr == nullptr || !visited.insert(curr).second) {
      continue;
    }
    if (HloAsyncInstruction::ClassOf(curr)) {
      if (curr->operand_count() > 0 &&
          FindAsyncChainProducer(curr->mutable_operand(0)) == root_producer) {
        return Cast<HloAsyncInstruction>(curr);
      }
      continue;
    }
    if (curr->IsAllowedAsyncIntermediary() ||
        curr->opcode() == HloOpcode::kGetTupleElement ||
        curr->opcode() == HloOpcode::kTuple ||
        curr->opcode() == HloOpcode::kOptimizationBarrier ||
        curr->opcode() == HloOpcode::kCopy ||
        (curr->opcode() == HloOpcode::kCustomCall &&
         curr->IsAllowedAsyncIntermediaryCustomCall())) {
      for (HloInstruction* user : curr->users()) {
        stack.push_back(user);
      }
    }
  }
  return nullptr;
}

HloAsyncInstruction* FindAsyncChainDone(HloInstruction* instr) {
  if (instr == nullptr) {
    return nullptr;
  }
  if (instr->opcode() == HloOpcode::kAsyncDone) {
    return Cast<HloAsyncInstruction>(instr);
  }
  HloAsyncInstruction* consumer = FindAsyncChainNext(instr);
  while (consumer != nullptr && consumer->opcode() == HloOpcode::kAsyncUpdate) {
    consumer = FindAsyncChainNext(consumer);
  }
  return consumer;
}

}  // namespace

HloAsyncInstruction::HloAsyncInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    std::optional<HloOpcode> async_wrapped_opcode)
    : HloInstruction(opcode, shape) {
  CHECK(opcode == HloOpcode::kAsyncStart || opcode == HloOpcode::kAsyncUpdate ||
        opcode == HloOpcode::kAsyncDone);
  // AsyncDone has only one operand.
  CHECK(opcode != HloOpcode::kAsyncDone || operands.size() == 1);
  CHECK(opcode == HloOpcode::kAsyncStart || !operands.empty());

  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }

  HloAsyncInstruction* prev = nullptr;
  if (opcode == HloOpcode::kAsyncUpdate || opcode == HloOpcode::kAsyncDone) {
    if (!operands.empty() && operands[0] != nullptr) {
      prev = FindAsyncChainProducer(operands[0]);
      if (prev != nullptr) {
        prev->async_chain_next_ = this;
      }
    }
  }

  // Drop 'async' from async-{start/update/done} to get the suffix.
  if (!async_wrapped_opcode.has_value()) {
    if (prev != nullptr) {
      async_wrapped_opcode = prev->async_wrapped_opcode();
    } else {
      async_wrapped_opcode = opcode;
    }
  }
  absl::string_view suffix = HloOpcodeString(opcode).substr(5);
  absl::string_view wrapped_name = HloOpcodeString(*async_wrapped_opcode);
  if (async_wrapped_opcode == opcode) {
    SetAndSanitizeName(wrapped_name);
  } else {
    SetAndSanitizeName(absl::StrCat(wrapped_name, suffix));
  }
}

HloComputation* HloAsyncInstruction::async_wrapped_computation() const {
  if (!called_computations().empty()) {
    return called_computations().front();
  }
  HloAsyncInstruction* start = async_chain_start();
  if (start != nullptr && !start->called_computations().empty()) {
    return start->called_computations().front();
  }
  // If there is no async-start (e.g. across a loop boundary), look upstream for
  // the nearest async op with a wrapped computation.
  if (operands().empty() || operand(0) == nullptr) {
    return nullptr;
  }
  HloAsyncInstruction* producer =
      FindAsyncChainProducer(const_cast<HloInstruction*>(operand(0)));
  while (producer != nullptr) {
    if (!producer->called_computations().empty()) {
      return producer->called_computations().front();
    }
    if (producer->operands().empty() || producer->operand(0) == nullptr) {
      break;
    }
    producer = FindAsyncChainProducer(
        const_cast<HloInstruction*>(producer->operand(0)));
  }
  return nullptr;
}

HloInstruction* HloAsyncInstruction::async_wrapped_instruction() const {
  HloComputation* comp = async_wrapped_computation();
  if (comp == nullptr) {
    return nullptr;
  }
  return comp->root_instruction();
}

HloOpcode HloAsyncInstruction::async_wrapped_opcode() const {
  HloInstruction* instr = async_wrapped_instruction();
  if (instr == nullptr) {
    return opcode();
  }
  return instr->opcode();
}

absl::string_view HloAsyncInstruction::async_execution_thread() const {
  HloAsyncInstruction* start = async_chain_start();
  if (start != nullptr) {
    return start->async_execution_thread();
  }
  if (!called_computations().empty()) {
    return called_computations().front()->execution_thread();
  }
  if (HloComputation* comp = async_wrapped_computation(); comp != nullptr) {
    return comp->execution_thread();
  }
  return kMainExecutionThread;
}

HloAsyncInstruction* HloAsyncInstruction::async_chain_start() const {
  if (opcode() == HloOpcode::kAsyncStart) {
    return const_cast<HloAsyncInstruction*>(this);
  }

  if (operands().empty() || operands()[0] == nullptr) {
    return nullptr;
  }
  return FindAsyncChainStart(const_cast<HloAsyncInstruction*>(this));
}

HloAsyncInstruction* HloAsyncInstruction::async_chain_next() const {
  if (opcode() == HloOpcode::kAsyncDone) {
    return nullptr;
  }
  return FindAsyncChainNext(const_cast<HloAsyncInstruction*>(this));
}

HloAsyncInstruction* HloAsyncInstruction::async_chain_done() const {
  if (opcode() == HloOpcode::kAsyncDone) {
    return const_cast<HloAsyncInstruction*>(this);
  }

  return FindAsyncChainDone(const_cast<HloAsyncInstruction*>(this));
}

std::vector<HloAsyncInstruction*> HloAsyncInstruction::GetAsyncChain() const {
  std::vector<HloAsyncInstruction*> chain;
  HloAsyncInstruction* current = async_chain_start();
  while (current != nullptr) {
    chain.push_back(current);
    if (current->opcode() == HloOpcode::kAsyncDone) {
      break;
    }
    current = current->async_chain_next();
  }
  return chain;
}

void HloAsyncInstruction::UpdateChainShapes() {
  if (opcode() == HloOpcode::kAsyncDone) {
    return;
  }

  const Shape& async_update_shape = shape();
  const Shape& async_done_shape = shape().tuple_shapes(1);
  HloAsyncInstruction* current = async_chain_next();
  while (current != nullptr) {
    switch (current->opcode()) {
      case HloOpcode::kAsyncUpdate: {
        *current->mutable_shape() = async_update_shape;
        current = current->async_chain_next();
        break;
      }
      case HloOpcode::kAsyncDone: {
        *current->mutable_shape() = async_done_shape;
        current = nullptr;
        break;
      }
      default: {
        LOG(FATAL) << "Unexpected async opcode: " << current->opcode();
      }
    }
  }
}

bool HloAsyncInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  return opcode() == other.opcode() &&
         eq_computations(async_wrapped_computation(),
                         other.async_wrapped_computation());
}

std::unique_ptr<HloInstruction> HloAsyncInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return absl::WrapUnique(new HloAsyncInstruction(opcode(), shape, new_operands,
                                                  async_wrapped_opcode()));
}

HloAsyncStartInstruction::HloAsyncStartInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    HloComputation* async_computation, absl::string_view async_execution_thread)
    : HloAsyncInstruction(opcode, shape, operands,
                          async_computation->root_instruction()->opcode()) {
  CHECK(async_computation->caller_instructions(HloOpcode::kCustomCall).empty());
  CHECK(!async_computation->IsFusionComputation());
  AppendComputation(async_computation);
  HloAsyncStartInstruction::set_async_execution_thread(async_execution_thread);
}

HloInstruction* HloAsyncStartInstruction::AddCallOperand(
    HloInstruction* new_operand) {
  CHECK_EQ(async_wrapped_computation()->parameter_instructions().size(),
           operand_count());
  const int64_t param_no = operand_count();
  std::string param_name = StrCat("param_", param_no);
  HloInstruction* called_computation_parameter =
      async_wrapped_computation()->AddParameter(HloInstruction::CreateParameter(
          param_no, new_operand->shape(), param_name));
  AppendOperand(new_operand);
  mutable_shape()->mutable_tuple_shapes(0)->mutable_tuple_shapes()->push_back(
      new_operand->shape());
  return called_computation_parameter;
}

void HloAsyncStartInstruction::set_async_execution_thread(
    absl::string_view async_execution_thread) {
  async_execution_thread_ = std::string(async_execution_thread);
  SetThreadName(async_wrapped_computation(), async_execution_thread);
}

void HloAsyncStartInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_async_execution_thread(async_execution_thread_ ==
                                            HloInstruction::kMainExecutionThread
                                        ? ""
                                        : async_execution_thread_);
  for (const auto& pair : output_to_operand_aliasing()) {
    auto* aliasing = proto->add_output_operand_aliasing();
    aliasing->set_operand_index(pair.second.first);
    for (int64_t index : pair.first) {
      aliasing->add_output_shape_index(index);
    }
    for (int64_t index : pair.second.second) {
      aliasing->add_operand_shape_index(index);
    }
  }
}

void HloAsyncStartInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (async_execution_thread_ != kMainExecutionThread) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "async_execution_thread=\"", async_execution_thread_,
                "\"");
    });
  }
  if (options.syntax_sugar_async_ops() &&
      async_wrapped_computation()->CanExpandIntoSingleInstruction()) {
    HloPrintOptions nested_options = options;
    nested_options.set_print_frontend_attributes(
        frontend_attributes().map().empty());
    async_wrapped_instruction()->PrintExtraAttributes(printer, nested_options);
  }

  if (!output_to_operand_aliasing().empty()) {
    printer.Next([this](Printer* printer) {
      printer->Append("output_to_operand_aliasing={");
      AppendJoin(printer, output_to_operand_aliasing(), ", ",
                 [](Printer* printer, auto& pair) {
                   AppendCat(printer, pair.first.ToString(), ": (",
                             pair.second.first, ", ");
                   AppendCat(printer, pair.second.second.ToString(), ")");
                 });
      printer->Append("}");
    });
  }
}

bool HloAsyncStartInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloAsyncStartInstruction&>(other);
  return HloAsyncInstruction::opcode() == other.opcode() &&
         eq_computations(HloAsyncInstruction::async_wrapped_computation(),
                         other.async_wrapped_computation()) &&
         output_to_operand_aliasing() ==
             casted_other.output_to_operand_aliasing();
}

std::unique_ptr<HloInstruction>
HloAsyncStartInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloComputation* new_computation, HloCloneContext* context) const {
  HloModule* module = context != nullptr ? context->module() : GetModule();
  HloComputation* new_wrapped_computation = nullptr;
  if (new_computation != nullptr) {
    new_wrapped_computation = new_computation;
  } else {
    if (context != nullptr) {
      new_wrapped_computation =
          context->FindComputation(async_wrapped_computation());
    }
    if (new_wrapped_computation == nullptr) {
      const std::string& suffix =
          context != nullptr ? context->suffix() : "clone";
      new_wrapped_computation = module->AddEmbeddedComputation(
          async_wrapped_computation()->Clone(suffix, context));
      // Give the trampoline a trivial schedule if it already had one.
      if (module->has_schedule() && module->schedule().is_computation_scheduled(
                                        async_wrapped_computation())) {
        module->schedule().set_sequence(
            new_wrapped_computation,
            new_wrapped_computation->MakeInstructionPostOrder());
      }
    }
  }

  auto cloned = std::make_unique<HloAsyncStartInstruction>(
      HloAsyncInstruction::opcode(), shape, new_operands,
      new_wrapped_computation, async_execution_thread_);
  cloned->HloAliasible::set_output_to_operand_aliasing(
      output_to_operand_aliasing());
  return cloned;
}

std::unique_ptr<HloInstruction>
HloAsyncStartInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return CloneWithNewOperandsImpl(shape, new_operands,
                                  /*new_computation=*/nullptr, context);
}

std::unique_ptr<HloInstruction>
HloAsyncStartInstruction::CloneWithNewOperandsAndComputation(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloComputation* new_computation, HloCloneContext* context) const {
  return CloneWithNewOperandsImpl(shape, new_operands, new_computation,
                                  context);
}

HloAsyncUpdateInstruction::HloAsyncUpdateInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    std::optional<HloOpcode> async_wrapped_opcode)
    : HloAsyncInstruction(HloOpcode::kAsyncUpdate, shape, operands,
                          async_wrapped_opcode) {}

void HloAsyncUpdateInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (const auto& pair : output_to_operand_aliasing()) {
    auto* aliasing = proto->add_output_operand_aliasing();
    aliasing->set_operand_index(pair.second.first);
    for (int64_t index : pair.first) {
      aliasing->add_output_shape_index(index);
    }
    for (int64_t index : pair.second.second) {
      aliasing->add_operand_shape_index(index);
    }
  }
}

void HloAsyncUpdateInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!output_to_operand_aliasing().empty()) {
    printer.Next([this](Printer* printer) {
      printer->Append("output_to_operand_aliasing={");
      AppendJoin(printer, output_to_operand_aliasing(), ", ",
                 [](Printer* printer, auto& pair) {
                   AppendCat(printer, pair.first.ToString(), ": (",
                             pair.second.first, ", ");
                   AppendCat(printer, pair.second.second.ToString(), ")");
                 });
      printer->Append("}");
    });
  }
}

bool HloAsyncUpdateInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloAsyncUpdateInstruction&>(other);
  return HloAsyncInstruction::opcode() == other.opcode() &&
         output_to_operand_aliasing() ==
             casted_other.output_to_operand_aliasing();
}

std::unique_ptr<HloInstruction>
HloAsyncUpdateInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  auto cloned =
      std::make_unique<HloAsyncUpdateInstruction>(shape, new_operands);
  cloned->HloAliasible::set_output_to_operand_aliasing(
      output_to_operand_aliasing());
  return cloned;
}

HloCopyStartInstruction::HloCopyStartInstruction(
    const Shape& shape, HloInstruction* operand,
    std::optional<int> cross_program_prefetch_index)
    : HloInstruction(HloOpcode::kCopyStart, shape),
      cross_program_prefetch_index_(cross_program_prefetch_index) {
  AppendOperand(operand);
}

void HloCopyStartInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  if (cross_program_prefetch_index_.has_value()) {
    proto->set_cross_program_prefetch_index(*cross_program_prefetch_index_);
  }
}

void HloCopyStartInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (cross_program_prefetch_index_.has_value()) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "cross_program_prefetch_index=",
                *cross_program_prefetch_index_);
    });
  }
}

bool HloCopyStartInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloCopyStartInstruction&>(other);
  return cross_program_prefetch_index() ==
         casted_other.cross_program_prefetch_index();
}

std::unique_ptr<HloInstruction>
HloCopyStartInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloCopyStartInstruction>(
      shape, new_operands[0], cross_program_prefetch_index());
}

HloCompareInstruction::HloCompareInstruction(
    const Shape& shape, HloInstruction* lhs, HloInstruction* rhs,
    ComparisonDirection direction, std::optional<ComparisonOrder> order)
    : HloInstruction(HloOpcode::kCompare, shape),
      compare_(order.has_value()
                   ? Comparison(direction, lhs->shape().element_type(), *order)
                   : Comparison(direction, lhs->shape().element_type())) {
  AppendOperand(lhs);
  AppendOperand(rhs);
}

void HloCompareInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_comparison_direction(
      ComparisonDirectionToString(compare_.GetDirection()));
  proto->set_comparison_order(
      ComparisonOrderToShortString(compare_.GetOrder()));
}

void HloCompareInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "direction=", ComparisonDirectionToString(direction()));
  });
  // We might want to print a HloInstruction which has been cleand up and has no
  // operands anymore. This should not result in a crash.
  if (operand_count() == 0 || operand(0) == nullptr ||
      order() !=
          Comparison::DefaultOrdering(operand(0)->shape().element_type())) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "order=", ComparisonOrderToShortString(order()));
    });
  }
}

bool HloCompareInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloCompareInstruction&>(other);
  return direction() == casted_other.direction() &&
         order() == casted_other.order();
}

std::unique_ptr<HloInstruction> HloCompareInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 2);
  return std::make_unique<HloCompareInstruction>(
      shape, new_operands[0], new_operands[1], direction(), order());
}

namespace {

// Converts a protocol buffer message (e.g., TriangularSolveOptions) to a
// vector of "key=value" attribute strings generically, using protocol buffer
// reflection.
//
// Currently implements a small subset of cases; feel free to add more as
// needed.
void PrintAttributeProto(HloInstruction::AttributePrinter& printer,
                         const tsl::protobuf::Message& message) {
  const tsl::protobuf::Reflection* reflection = message.GetReflection();
  std::vector<const tsl::protobuf::FieldDescriptor*> fields;
  reflection->ListFields(message, &fields);

  for (const tsl::protobuf::FieldDescriptor* field : fields) {
    CHECK(!field->is_repeated()) << "Repeated fields aren't implemented";
    printer.Next([&](Printer* printer) {
      printer->Append(field->name());
      printer->Append("=");
      switch (field->type()) {
        case tsl::protobuf::FieldDescriptor::TYPE_BOOL: {
          bool val = reflection->GetBool(message, field);
          printer->Append(val ? "true" : "false");
          break;
        }
        case tsl::protobuf::FieldDescriptor::TYPE_ENUM: {
          const tsl::protobuf::EnumValueDescriptor* evd =
              reflection->GetEnum(message, field);
          printer->Append(evd->name());
          break;
        }
        default:
          LOG(FATAL) << "Unimplemented field type: " << field->DebugString();
      }
    });
  }
}

}  // namespace

HloTriangularSolveInstruction::HloTriangularSolveInstruction(
    const Shape& shape, HloInstruction* a, HloInstruction* b,
    const TriangularSolveOptions& options)
    : HloInstruction(HloOpcode::kTriangularSolve, shape),
      triangular_solve_options_(options) {
  AppendOperand(a);
  AppendOperand(b);
}

void HloTriangularSolveInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_triangular_solve_options() = triangular_solve_options_;
}

void HloTriangularSolveInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  PrintAttributeProto(printer, triangular_solve_options_);
}

bool HloTriangularSolveInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloTriangularSolveInstruction&>(other);
  const auto& options = triangular_solve_options();
  const auto& other_options = casted_other.triangular_solve_options();

  return options.left_side() == other_options.left_side() &&
         options.lower() == other_options.lower() &&
         options.unit_diagonal() == other_options.unit_diagonal() &&
         options.transpose_a() == other_options.transpose_a();
}

std::unique_ptr<HloInstruction>
HloTriangularSolveInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 2);
  return std::make_unique<HloTriangularSolveInstruction>(
      shape, new_operands[0], new_operands[1], triangular_solve_options());
}

HloCholeskyInstruction::HloCholeskyInstruction(const Shape& shape,
                                               HloInstruction* a,
                                               const CholeskyOptions& options)
    : HloInstruction(HloOpcode::kCholesky, shape), cholesky_options_(options) {
  AppendOperand(a);
}

void HloCholeskyInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_cholesky_options() = cholesky_options_;
}

void HloCholeskyInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  PrintAttributeProto(printer, cholesky_options_);
}

bool HloCholeskyInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloCholeskyInstruction&>(other);
  const auto& options = cholesky_options();
  const auto& other_options = casted_other.cholesky_options();

  return options.lower() == other_options.lower();
}

std::unique_ptr<HloInstruction>
HloCholeskyInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloCholeskyInstruction>(shape, new_operands[0],
                                                  cholesky_options());
}

HloChannelInstruction::HloChannelInstruction(
    HloOpcode opcode, const Shape& shape,
    const std::optional<int64_t>& channel_id)
    : HloInstruction(opcode, shape), channel_id_(channel_id) {}

void HloChannelInstruction::set_channel_id(
    const std::optional<int64_t>& channel_id) {
  channel_id_ = channel_id;
}

void HloChannelInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  if (channel_id_.has_value()) {
    proto->set_channel_id(*channel_id_);
  }
}

void HloChannelInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!channel_id_.has_value()) {
    return;
  }
  printer.Next([this, &options](Printer* printer) {
    printer->Append("channel_id=");
    if (options.print_channel_id()) {
      printer->Append(*channel_id_);
    } else {
      printer->Append("_");
    }
  });
}

bool HloChannelInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  if (!IdenticalSlowPathIgnoringChannelIdValues(other, eq_computations)) {
    return false;
  }
  const auto& casted_other = static_cast<const HloChannelInstruction&>(other);
  return channel_id() == casted_other.channel_id();
}

HloTopKInstruction::HloTopKInstruction(const Shape& shape,
                                       HloInstruction* input, int64_t k,
                                       bool largest, bool is_stable)
    : HloInstruction(HloOpcode::kTopK, shape),
      k_(k),
      largest_(largest),
      is_stable_(is_stable) {
  AppendOperand(input);
}

void HloTopKInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_k(k_);
  proto->set_largest(largest_);
  proto->set_is_stable(is_stable_);
}

void HloTopKInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* p) { AppendCat(p, "k=", k_); });
  printer.Next([this](Printer* p) {
    AppendCat(p, "largest=", (largest_ ? "true" : "false"));
  });
  printer.Next([this](Printer* p) {
    AppendCat(p, "is_stable=", (is_stable_ ? "true" : "false"));
  });
}

std::unique_ptr<HloInstruction> HloTopKInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloTopKInstruction>(shape, new_operands[0], k(),
                                              largest(), is_stable());
}

bool HloTopKInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloTopKInstruction&>(other);
  return k() == casted_other.k() && largest() == casted_other.largest() &&
         is_stable() == casted_other.is_stable();
}

HloSendRecvInstruction::HloSendRecvInstruction(
    HloOpcode opcode, const Shape& shape, std::optional<int64_t> channel_id,
    bool is_host_transfer)
    : HloChannelInstruction(opcode, shape, channel_id),
      is_host_transfer_(is_host_transfer) {}

void HloSendRecvInstruction::ToProto(HloInstructionProto* proto) const {
  HloChannelInstruction::ToProto(proto);
  proto->set_is_host_transfer(is_host_transfer_);
}

void HloSendRecvInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloChannelInstruction::PrintExtraAttributesImpl(printer, options);
  if (is_host_transfer()) {
    printer.Next(
        [](Printer* printer) { printer->Append("is_host_transfer=true"); });
  }
}

bool HloSendRecvInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloSendRecvInstruction&>(other);
  if (is_host_transfer_ != casted_other.is_host_transfer()) {
    return false;
  }
  // TODO(b/436212814): In theory, frontend_attributes() are a hint, can be
  // dropped by the optimizer, and aren't check by the top-level
  // HloInstruction::Identical(). In practice, they are load-bearing for
  // host-transfer Send/Recv, even if they shouldn't be.
  return google::protobuf::util::MessageDifferencer::Equivalent(
      frontend_attributes(), casted_other.frontend_attributes());
}

// Send instruction produces a tuple of {aliased operand, U32 context}.
HloSendInstruction::HloSendInstruction(HloInstruction* operand,
                                       HloInstruction* token,
                                       std::optional<int64_t> channel_id,
                                       bool is_host_transfer)
    : HloSendRecvInstruction(
          HloOpcode::kSend,
          ShapeUtil::MakeTupleShape({ABSL_DIE_IF_NULL(operand)->shape(),
                                     ShapeUtil::MakeShape(U32, {}),
                                     ShapeUtil::MakeTokenShape()}),
          channel_id, is_host_transfer) {
  AppendOperand(operand);
  AppendOperand(token);
}

std::unique_ptr<HloInstruction> HloSendInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 2);
  return std::make_unique<HloSendInstruction>(new_operands[0], new_operands[1],
                                              channel_id(), is_host_transfer());
}

HloSendDoneInstruction::HloSendDoneInstruction(HloSendInstruction* operand,
                                               bool is_host_transfer)
    : HloSendRecvInstruction(HloOpcode::kSendDone, ShapeUtil::MakeTokenShape(),
                             operand->channel_id(), is_host_transfer) {
  AppendOperand(operand);
}

HloSendDoneInstruction::HloSendDoneInstruction(
    HloInstruction* operand, std::optional<int64_t> channel_id,
    bool is_host_transfer)
    : HloSendRecvInstruction(HloOpcode::kSendDone, ShapeUtil::MakeTokenShape(),
                             channel_id, is_host_transfer) {
  AppendOperand(operand);
}

std::unique_ptr<HloInstruction>
HloSendDoneInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  HloSendInstruction* send = DynCast<HloSendInstruction>(new_operands[0]);
  if (send != nullptr) {
    return std::make_unique<HloSendDoneInstruction>(send, is_host_transfer());
  }

  return std::make_unique<HloSendDoneInstruction>(new_operands[0], channel_id(),
                                                  is_host_transfer());
}

// Recv instruction produces a tuple of {receive buffer, U32 context}.
HloRecvInstruction::HloRecvInstruction(const Shape& shape,
                                       HloInstruction* token,
                                       std::optional<int64_t> channel_id,
                                       bool is_host_transfer)
    : HloSendRecvInstruction(
          HloOpcode::kRecv,
          ShapeUtil::MakeTupleShape({shape, ShapeUtil::MakeShape(U32, {}),
                                     ShapeUtil::MakeTokenShape()}),
          channel_id, is_host_transfer) {
  AppendOperand(token);
}

std::unique_ptr<HloInstruction> HloRecvInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloRecvInstruction>(
      ShapeUtil::GetTupleElementShape(shape, 0), new_operands[0], channel_id(),
      is_host_transfer());
}

HloRecvDoneInstruction::HloRecvDoneInstruction(HloRecvInstruction* operand,
                                               bool is_host_transfer)
    : HloSendRecvInstruction(
          HloOpcode::kRecvDone,
          ShapeUtil::MakeTupleShape(
              {ShapeUtil::GetTupleElementShape(operand->shape(), 0),
               ShapeUtil::MakeTokenShape()}),
          operand->channel_id(), is_host_transfer) {
  AppendOperand(operand);
}

HloRecvDoneInstruction::HloRecvDoneInstruction(
    HloInstruction* operand, std::optional<int64_t> channel_id,
    bool is_host_transfer)
    : HloSendRecvInstruction(
          HloOpcode::kRecvDone,
          ShapeUtil::MakeTupleShape(
              {ShapeUtil::GetTupleElementShape(operand->shape(), 0),
               ShapeUtil::MakeTokenShape()}),
          channel_id, is_host_transfer) {
  AppendOperand(operand);
}

std::unique_ptr<HloInstruction>
HloRecvDoneInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  HloRecvInstruction* recv = DynCast<HloRecvInstruction>(new_operands[0]);
  if (recv != nullptr) {
    return std::make_unique<HloRecvDoneInstruction>(recv, is_host_transfer());
  }

  return std::make_unique<HloRecvDoneInstruction>(new_operands[0], channel_id(),
                                                  is_host_transfer());
}

HloCollectiveInstruction::HloCollectiveInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id)
    : HloChannelInstruction(opcode, shape, channel_id),
      device_list_(std::move(device_list)),
      constrain_layout_(constrain_layout) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
}

void HloCollectiveInstruction::set_device_list(
    std::shared_ptr<CollectiveDeviceListBase> device_list) {
  device_list_ = std::move(device_list);
}

void HloCollectiveInstruction::ToProto(HloInstructionProto* proto) const {
  HloChannelInstruction::ToProto(proto);

  if (const CollectiveDeviceList* device_list_v1 =
          dynamic_cast<const CollectiveDeviceList*>(device_list_.get())) {
    *proto->mutable_collective_device_list() = device_list_v1->ToProto();
  } else if (const IotaReplicaGroupList* device_list_v2 =
                 dynamic_cast<const IotaReplicaGroupList*>(
                     device_list_.get())) {
    *proto->mutable_iota_collective_device_list() = device_list_v2->ToProto();
  } else if (const MeshAxesReplicaGroupList* device_list_v3 =
                 dynamic_cast<const MeshAxesReplicaGroupList*>(
                     device_list_.get())) {
    *proto->mutable_mesh_axes_replica_group_list() = device_list_v3->ToProto();
  } else {
    LOG(FATAL) << "Unknown or missing CollectiveDeviceList type in "
                  "HloCollectiveInstruction";
  }

  proto->set_constrain_layout(constrain_layout_);
}

void HloCollectiveInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloChannelInstruction::PrintExtraAttributesImpl(printer, options);
  printer.Next([this, &options](Printer* printer) {
    VLOG(4) << name() << " replica_groups=" << device_list_->ToString(options);

    printer->Append("replica_groups=");
    device_list_->Print(printer, options);
  });
  if (constrain_layout_) {
    printer.Next(
        [](Printer* printer) { printer->Append("constrain_layout=true"); });
  }
}

bool HloCollectiveInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloCollectiveInstruction&>(other);
  return HloChannelInstruction::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         constrain_layout() == casted_other.constrain_layout() &&
         absl::c_equal(replica_groups(), casted_other.replica_groups(),
                       [](const ReplicaGroup& a, const ReplicaGroup& b) {
                         return absl::c_equal(a.replica_ids(), b.replica_ids());
                       });
}

HloAllGatherInstruction::HloAllGatherInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands, int64_t all_gather_dimension,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id,
    bool use_global_device_ids)
    : HloCollectiveInstruction(opcode, shape, operands, std::move(device_list),
                               constrain_layout, channel_id),
      all_gather_dimension_(all_gather_dimension),
      use_global_device_ids_(use_global_device_ids) {}

HloAllGatherInstruction::HloAllGatherInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands, int64_t all_gather_dimension,
    absl::Span<const ReplicaGroup> replica_groups, bool constrain_layout,
    const std::optional<int64_t>& channel_id, bool use_global_device_ids)
    : HloAllGatherInstruction(
          opcode, shape, operands, all_gather_dimension,
          std::make_shared<CollectiveDeviceList>(replica_groups),
          constrain_layout, channel_id, use_global_device_ids) {}

void HloAllGatherInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloCollectiveInstruction::PrintExtraAttributesImpl(printer, options);
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "dimensions={", all_gather_dimension_, "}");
  });
  if (use_global_device_ids_) {
    printer.Next([](Printer* printer) {
      printer->Append("use_global_device_ids=true");
    });
  }
}

std::unique_ptr<HloInstruction>
HloAllGatherInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloAllGatherInstruction>(
      opcode(), shape, new_operands, all_gather_dimension(), device_list(),
      constrain_layout(), channel_id(), use_global_device_ids());
}

void HloAllGatherInstruction::ToProto(HloInstructionProto* proto) const {
  HloCollectiveInstruction::ToProto(proto);
  proto->add_dimensions(all_gather_dimension_);
  proto->set_use_global_device_ids(use_global_device_ids_);
}

bool HloAllGatherInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloAllGatherInstruction&>(other);
  return HloCollectiveInstruction::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         all_gather_dimension_ == casted_other.all_gather_dimension() &&
         use_global_device_ids() == casted_other.use_global_device_ids();
}

HloAllReduceInstructionBase::HloAllReduceInstructionBase(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    HloComputation* reduce_computation,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id,
    bool use_global_device_ids)
    : HloCollectiveInstruction(opcode, shape, operands, std::move(device_list),
                               constrain_layout, channel_id),
      use_global_device_ids_(use_global_device_ids) {
  AppendComputation(reduce_computation);
}

void HloAllReduceInstructionBase::ToProto(HloInstructionProto* proto) const {
  HloCollectiveInstruction::ToProto(proto);
  proto->set_use_global_device_ids(use_global_device_ids_);
}

void HloAllReduceInstructionBase::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloCollectiveInstruction::PrintExtraAttributesImpl(printer, options);
  if (use_global_device_ids_) {
    printer.Next([](Printer* printer) {
      printer->Append("use_global_device_ids=true");
    });
  }
}

bool HloAllReduceInstructionBase::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  if (opcode() != other.opcode()) {
    return false;
  }
  const auto& casted_other =
      static_cast<const HloAllReduceInstructionBase&>(other);
  return HloCollectiveInstruction::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         constrain_layout() == casted_other.constrain_layout() &&
         use_global_device_ids() == casted_other.use_global_device_ids() &&
         eq_computations(to_apply(), casted_other.to_apply());
}

bool HloAllReduceInstruction::IsNoop() const {
  return !channel_id().has_value() &&
         absl::c_all_of(replica_groups(),
                        [](const ReplicaGroup& replica_group) {
                          return replica_group.replica_ids().size() == 1;
                        });
}

std::unique_ptr<HloInstruction>
HloAllReduceInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloAllReduceInstruction>(
      opcode(), shape, new_operands, to_apply(), device_list(),
      constrain_layout(), channel_id(), use_global_device_ids());
}

HloReduceScatterInstruction::HloReduceScatterInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* reduce_computation,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id,
    bool use_global_device_ids, int64_t scatter_dimension)
    : HloAllReduceInstructionBase(HloOpcode::kReduceScatter, shape, operands,
                                  reduce_computation, std::move(device_list),
                                  constrain_layout, channel_id,
                                  use_global_device_ids),
      scatter_dimension_(scatter_dimension) {}

HloReduceScatterInstruction::HloReduceScatterInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* reduce_computation,
    absl::Span<const ReplicaGroup> replica_groups, bool constrain_layout,
    const std::optional<int64_t>& channel_id, bool use_global_device_ids,
    int64_t scatter_dimension)
    : HloReduceScatterInstruction(
          shape, operands, reduce_computation,
          std::make_shared<CollectiveDeviceList>(replica_groups),
          constrain_layout, channel_id, use_global_device_ids,
          scatter_dimension) {}

void HloReduceScatterInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloAllReduceInstructionBase::PrintExtraAttributesImpl(printer, options);
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "dimensions={", scatter_dimension_, "}");
  });
}

void HloReduceScatterInstruction::ToProto(HloInstructionProto* proto) const {
  HloAllReduceInstructionBase::ToProto(proto);
  proto->add_dimensions(scatter_dimension_);
}

bool HloReduceScatterInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloReduceScatterInstruction&>(other);
  return HloAllReduceInstructionBase::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         scatter_dimension_ == casted_other.scatter_dimension();
}

std::unique_ptr<HloInstruction>
HloReduceScatterInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloReduceScatterInstruction>(
      shape, new_operands, to_apply(), device_list(), constrain_layout(),
      channel_id(), use_global_device_ids(), scatter_dimension());
}

HloCollectiveReduceInstruction::HloCollectiveReduceInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* reduce_computation,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id,
    bool use_global_device_ids, bool has_dynamic_root)
    : HloAllReduceInstructionBase(HloOpcode::kCollectiveReduce, shape, operands,
                                  reduce_computation, std::move(device_list),
                                  constrain_layout, channel_id,
                                  use_global_device_ids),
      has_dynamic_root_(has_dynamic_root) {}

HloCollectiveReduceInstruction::HloCollectiveReduceInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* reduce_computation,
    absl::Span<const ReplicaGroup> replica_groups, bool constrain_layout,
    const std::optional<int64_t>& channel_id, bool use_global_device_ids,
    bool has_dynamic_root)
    : HloCollectiveReduceInstruction(
          shape, operands, reduce_computation,
          std::make_shared<CollectiveDeviceList>(replica_groups),
          constrain_layout, channel_id, use_global_device_ids,
          has_dynamic_root) {}

void HloCollectiveReduceInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloAllReduceInstructionBase::PrintExtraAttributesImpl(printer, options);
  printer.Next([this](Printer* printer) {
    printer->Append("has_dynamic_root=");
    printer->Append(has_dynamic_root_ ? "true" : "false");
  });
}

void HloCollectiveReduceInstruction::ToProto(HloInstructionProto* proto) const {
  HloAllReduceInstructionBase::ToProto(proto);
  proto->set_has_dynamic_root(has_dynamic_root_);
}

bool HloCollectiveReduceInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloCollectiveReduceInstruction&>(other);
  return HloAllReduceInstructionBase::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         has_dynamic_root_ == casted_other.has_dynamic_root();
}

std::unique_ptr<HloInstruction>
HloCollectiveReduceInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloCollectiveReduceInstruction>(
      shape, new_operands, to_apply(), device_list(), constrain_layout(),
      channel_id(), use_global_device_ids(), has_dynamic_root_);
}

HloAllToAllInstruction::HloAllToAllInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id,
    const std::optional<int64_t>& split_dimension)
    : HloCollectiveInstruction(HloOpcode::kAllToAll, shape, operands,
                               std::move(device_list), constrain_layout,
                               channel_id),
      split_dimension_(split_dimension) {}

HloAllToAllInstruction::HloAllToAllInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    absl::Span<const ReplicaGroup> replica_groups, bool constrain_layout,
    const std::optional<int64_t>& channel_id,
    const std::optional<int64_t>& split_dimension)
    : HloAllToAllInstruction(
          shape, operands,
          std::make_shared<CollectiveDeviceList>(replica_groups),
          constrain_layout, channel_id, split_dimension) {}

std::unique_ptr<HloInstruction>
HloAllToAllInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloAllToAllInstruction>(
      shape, new_operands, device_list(), constrain_layout(), channel_id(),
      split_dimension());
}

void HloAllToAllInstruction::ToProto(HloInstructionProto* proto) const {
  HloCollectiveInstruction::ToProto(proto);
  if (split_dimension_.has_value()) {
    proto->add_dimensions(*split_dimension_);
  }
}

void HloAllToAllInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloCollectiveInstruction::PrintExtraAttributesImpl(printer, options);
  if (split_dimension_.has_value()) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "dimensions={", *split_dimension_, "}");
    });
  }
}

bool HloAllToAllInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloAllToAllInstruction&>(other);
  return HloCollectiveInstruction::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         split_dimension_ == casted_other.split_dimension();
}

HloRaggedAllToAllInstruction::HloRaggedAllToAllInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    const std::optional<int64_t>& channel_id)
    : HloCollectiveInstruction(HloOpcode::kRaggedAllToAll, shape, operands,
                               std::move(device_list),
                               /*constrain_layout=*/false, channel_id) {}

HloRaggedAllToAllInstruction::HloRaggedAllToAllInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    absl::Span<const ReplicaGroup> replica_groups,
    const std::optional<int64_t>& channel_id)
    : HloRaggedAllToAllInstruction(
          shape, operands,
          std::make_shared<CollectiveDeviceList>(replica_groups), channel_id) {}

std::unique_ptr<HloInstruction>
HloRaggedAllToAllInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloRaggedAllToAllInstruction>(
      shape, new_operands, device_list(), channel_id());
}

void HloRaggedAllToAllInstruction::ToProto(HloInstructionProto* proto) const {
  HloCollectiveInstruction::ToProto(proto);
}

void HloRaggedAllToAllInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloCollectiveInstruction::PrintExtraAttributesImpl(printer, options);
}

HloCollectiveBroadcastInstruction::HloCollectiveBroadcastInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    std::shared_ptr<CollectiveDeviceListBase> device_list,
    bool constrain_layout, const std::optional<int64_t>& channel_id,
    bool has_dynamic_root)
    : HloCollectiveInstruction(opcode, shape, operands, std::move(device_list),
                               constrain_layout, channel_id),
      has_dynamic_root_(has_dynamic_root) {}

HloCollectiveBroadcastInstruction::HloCollectiveBroadcastInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    absl::Span<const ReplicaGroup> replica_groups, bool constrain_layout,
    const std::optional<int64_t>& channel_id, bool has_dynamic_root)
    : HloCollectiveBroadcastInstruction(
          opcode, shape, operands,
          std::make_shared<CollectiveDeviceList>(replica_groups),
          constrain_layout, channel_id, has_dynamic_root) {}

void HloCollectiveBroadcastInstruction::ToProto(
    HloInstructionProto* proto) const {
  HloCollectiveInstruction::ToProto(proto);
  proto->set_has_dynamic_root(has_dynamic_root());
}

std::unique_ptr<HloInstruction>
HloCollectiveBroadcastInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  return std::make_unique<HloCollectiveBroadcastInstruction>(
      opcode(), shape, new_operands, device_list(), constrain_layout(),
      channel_id(), has_dynamic_root());
}

void HloCollectiveBroadcastInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloCollectiveInstruction::PrintExtraAttributesImpl(printer, options);
  printer.Next([this](Printer* printer) {
    printer->Append("has_dynamic_root=");
    printer->Append(has_dynamic_root() ? "true" : "false");
  });
}

HloCollectivePermuteInstruction::HloCollectivePermuteInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    const std::vector<std::pair<int64_t, int64_t>>& source_target_pairs,
    const std::optional<int64_t>& channel_id)
    : HloChannelInstruction(opcode, shape, channel_id),
      source_target_pairs_(source_target_pairs) {
  AppendOperands(operands);
}

HloCollectivePermuteInstruction::HloCollectivePermuteInstruction(
    HloOpcode opcode, const Shape& shape, HloInstruction* input,
    HloInstruction* output, HloInstruction* input_start_indices,
    HloInstruction* output_start_indices,
    absl::Span<const std::pair<int64_t, int64_t>> source_target_pairs,
    absl::Span<const std::vector<int64_t>> slice_sizes,
    const std::optional<int64_t>& channel_id)
    : HloChannelInstruction(opcode, shape, channel_id),
      source_target_pairs_(source_target_pairs.begin(),
                           source_target_pairs.end()),
      slice_sizes_(slice_sizes.begin(), slice_sizes.end()) {
  AppendOperand(input);
  AppendOperand(output);
  AppendOperand(input_start_indices);
  AppendOperand(output_start_indices);
}

void HloCollectivePermuteInstruction::ToProto(
    HloInstructionProto* proto) const {
  HloChannelInstruction::ToProto(proto);
  for (const auto& pair : source_target_pairs()) {
    auto* proto_pair = proto->add_source_target_pairs();
    proto_pair->set_source(pair.first);
    proto_pair->set_target(pair.second);
  }
  for (const auto& slice_size : dynamic_slice_sizes_list()) {
    for (const auto& dimension_slice_size : slice_size) {
      proto->add_dynamic_slice_sizes(dimension_slice_size);
    }
  }
}

void HloCollectivePermuteInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloChannelInstruction::PrintExtraAttributesImpl(printer, options);
  printer.Next([this](Printer* printer) {
    printer->Append("source_target_pairs={");
    AppendJoin(printer, source_target_pairs(), ",",
               [](Printer* printer, const std::pair<int64_t, int64_t>& pair) {
                 AppendCat(printer, "{", pair.first, ",", pair.second);
                 printer->Append("}");
               });
    printer->Append("}");
  });
  if (!dynamic_slice_sizes_list().empty()) {
    printer.Next([this](Printer* printer) {
      printer->Append("slice_sizes={");
      AppendJoin(printer, dynamic_slice_sizes_list(), ",",
                 [](Printer* printer, const std::vector<int64_t>& slice_sizes) {
                   printer->Append("{");
                   AppendJoin(printer, slice_sizes, ",");
                   printer->Append("}");
                 });
      printer->Append("}");
    });
  }
}

bool HloCollectivePermuteInstruction::IdenticalSlowPathIgnoringChannelIdValues(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  if (opcode() != other.opcode()) {
    return false;
  }
  const auto& casted_other =
      static_cast<const HloCollectivePermuteInstruction&>(other);
  return HloChannelInstruction::IdenticalSlowPathIgnoringChannelIdValues(
             other, eq_computations) &&
         absl::c_equal(
             source_target_pairs(), casted_other.source_target_pairs(),
             [](const std::pair<int64_t, int64_t>& a,
                const std::pair<int64_t, int64_t>& b) { return a == b; }) &&
         absl::c_equal(
             dynamic_slice_sizes_list(),
             casted_other.dynamic_slice_sizes_list(),
             [](const std::vector<int64_t>& a, const std::vector<int64_t>& b) {
               return absl::c_equal(a, b);
             });
}

std::unique_ptr<HloInstruction>
HloCollectivePermuteInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  if (dynamic_slice_sizes_list().empty()) {
    return std::make_unique<HloCollectivePermuteInstruction>(
        opcode(), shape, new_operands, source_target_pairs(), channel_id());
  }
  return std::make_unique<HloCollectivePermuteInstruction>(
      opcode(), shape, new_operands[0], new_operands[1], new_operands[2],
      new_operands[3], source_target_pairs(), dynamic_slice_sizes_list(),
      channel_id());
}

HloReverseInstruction::HloReverseInstruction(
    const Shape& shape, HloInstruction* operand,
    absl::Span<const int64_t> dimensions)
    : HloDimensionsInstruction(HloOpcode::kReverse, shape, dimensions) {
  AppendOperand(operand);
}

void HloDimensionsInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (int64_t dimension : dimensions_) {
    proto->add_dimensions(dimension);
  }
}

void HloDimensionsInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append("dimensions={");
    AppendJoin(printer, dimensions(), ",");
    printer->Append("}");
  });
}

bool HloDimensionsInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloDimensionsInstruction&>(other);
  return dimensions() == casted_other.dimensions();
}

std::unique_ptr<HloInstruction> HloReverseInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloReverseInstruction>(shape, new_operands[0],
                                                 dimensions());
}

HloConcatenateInstruction::HloConcatenateInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    int64_t dimension)
    : HloDimensionsInstruction(HloOpcode::kConcatenate, shape, {dimension}) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
}

std::unique_ptr<HloInstruction>
HloConcatenateInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloConcatenateInstruction>(shape, new_operands,
                                                     concatenate_dimension());
}

HloReduceInstruction::HloReduceInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> args,
    absl::Span<const int64_t> dimensions_to_reduce,
    HloComputation* reduce_computation)
    : HloDimensionsInstruction(HloOpcode::kReduce, shape,
                               dimensions_to_reduce) {
  for (HloInstruction* arg : args) {
    AppendOperand(arg);
  }
  AppendComputation(reduce_computation);
}

bool HloReduceInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloReduceInstruction&>(other);
  // Reduction results are determined by the reduction dimension and the
  // reduction computation.
  return dimensions() == casted_other.dimensions() &&
         eq_computations(to_apply(), casted_other.to_apply());
}

std::unique_ptr<HloInstruction> HloReduceInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size() % 2, 0);
  return std::make_unique<HloReduceInstruction>(shape, new_operands,
                                                dimensions(), to_apply());
}

HloShuffleInstruction::HloShuffleInstruction(
    const Shape& shape, HloInstruction* operand,
    absl::Span<const int64_t> dimensions, const ShuffleMode& mode)
    : HloDimensionsInstruction(HloOpcode::kShuffle, shape, dimensions),
      mode_(mode) {
  AppendOperand(operand);
}

bool HloShuffleInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloShuffleInstruction&>(other);
  // Shuffle results are determined by the shuffled dimensions and by the mode
  // together with its attributes.
  return dimensions() == casted_other.dimensions() &&
         protobuf_util::HaveSameSerialization(mode_, casted_other.mode_);
}

std::unique_ptr<HloInstruction> HloShuffleInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloShuffleInstruction>(shape, new_operands[0],
                                                 dimensions(), mode_);
}

void HloShuffleInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  HloDimensionsInstruction::PrintExtraAttributesImpl(printer, options);
  printer.Next([this](Printer* printer) {
    printer->Append("mode=");
    printer->Append(ShuffleModeToString(mode()));
  });
  // Each mode's inner attributes.
  switch (mode()) {
    case ShuffleMode::kRotate:
      printer.Next([this](Printer* printer) {
        printer->Append("shifts={");
        AppendJoin(printer, rotate().shifts(), ",");
        printer->Append("}");
      });
      break;
    case ShuffleMode::MODE_NOT_SET:
      break;
  }
}

void HloShuffleInstruction::ToProto(HloInstructionProto* proto) const {
  HloDimensionsInstruction::ToProto(proto);
  *proto->mutable_shuffle_mode() = mode_;
}

HloScanInstruction::HloScanInstruction(const Shape& shape,
                                       absl::Span<HloInstruction* const> inputs,
                                       absl::Span<HloInstruction* const> inits,
                                       HloComputation* to_apply,
                                       int64_t scan_dimension, bool is_reverse,
                                       TriState is_associative)
    : HloDimensionsInstruction(HloOpcode::kScan, shape, {scan_dimension}),
      is_reverse_(is_reverse),
      is_associative_(is_associative),
      num_carries_(inits.size()) {
  for (HloInstruction* input : inputs) {
    AppendOperand(input);
  }
  for (HloInstruction* init : inits) {
    AppendOperand(init);
  }
  AppendComputation(to_apply);
}

absl::StatusOr<int64_t> HloScanInstruction::GetScanDimSize() const {
  int64_t scan_dim = scan_dimension();
  if (!inputs().empty()) {
    return inputs()[0]->shape().dimensions(scan_dim);
  }
  // If there are no inputs, use an output to determine the scan dimension size.
  const Shape& shape = this->shape();
  if (shape.IsTuple()) {
    int64_t num_outputs = shape.tuple_shapes().size() - num_carries();
    if (num_outputs > 0) {
      return shape.tuple_shapes(0).dimensions(scan_dim);
    }
  } else {
    // If not tuple, check if it's an output or carry.
    if (num_carries() == 0) {
      return shape.dimensions(scan_dim);
    }
  }
  return absl::InternalError(
      "Scan instruction has no inputs and no outputs, cannot determine scan "
      "dimension size.");
}

void HloScanInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (int64_t dimension : dimensions_) {
    proto->add_dimensions(dimension);
  }
  proto->set_is_reverse(is_reverse_);
  proto->set_is_associative(is_associative_);
  proto->set_num_carries(num_carries_);
}

void HloScanInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append("dimensions={");
    AppendJoin(printer, dimensions(), ",");
    printer->Append("}");
  });
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "num_carries=", num_carries_);
  });
  if (is_reverse_) {
    printer.Next([](Printer* printer) { printer->Append("is_reverse=true"); });
  }
  if (is_associative_ != TRI_STATE_UNSPECIFIED) {
    printer.Next([this](Printer* printer) {
      printer->Append("is_associative=");
      printer->Append(is_associative_ == TRI_STATE_TRUE ? "true" : "false");
    });
  }
}

bool HloScanInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloScanInstruction&>(other);
  return dimensions() == casted_other.dimensions() &&
         is_reverse() == casted_other.is_reverse() &&
         is_associative() == casted_other.is_associative() &&
         eq_computations(to_apply(), casted_other.to_apply());
}

std::unique_ptr<HloInstruction> HloScanInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  int64_t num_carries = this->num_carries();
  int64_t num_inputs = new_operands.size() - num_carries;
  return std::make_unique<HloScanInstruction>(
      shape, new_operands.subspan(0, num_inputs),
      new_operands.subspan(num_inputs, num_carries), to_apply(),
      scan_dimension(), is_reverse(), is_associative());
}

HloSortInstruction::HloSortInstruction(
    const Shape& shape, int64_t dimension,
    absl::Span<HloInstruction* const> operands, HloComputation* compare,
    bool is_stable)
    : HloDimensionsInstruction(HloOpcode::kSort, shape, {dimension}),
      is_stable_(is_stable) {
  for (HloInstruction* value : operands) {
    AppendOperand(value);
  }
  AppendComputation(compare);
}

void HloSortInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (int64_t dimension : dimensions_) {
    proto->add_dimensions(dimension);
  }
  proto->set_is_stable(is_stable());
}

void HloSortInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append("dimensions={");
    AppendJoin(printer, dimensions(), ",");
    printer->Append("}");
  });
  if (is_stable()) {
    printer.Next([](Printer* printer) { printer->Append("is_stable=true"); });
  }
}

bool HloSortInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloSortInstruction&>(other);
  if (dimensions() != casted_other.dimensions()) {
    return false;
  }
  if (is_stable() != casted_other.is_stable()) {
    return false;
  }
  return eq_computations(to_apply(), other.to_apply());
}

std::unique_ptr<HloInstruction> HloSortInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloSortInstruction>(
      shape, dimensions_[0], new_operands, to_apply(), is_stable());
}

HloTransposeInstruction::HloTransposeInstruction(
    const Shape& shape, HloInstruction* operand,
    absl::Span<const int64_t> dimensions)
    : HloDimensionsInstruction(HloOpcode::kTranspose, shape, dimensions) {
  AppendOperand(operand);
}

std::unique_ptr<HloInstruction>
HloTransposeInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloTransposeInstruction>(shape, new_operands[0],
                                                   dimensions());
}

HloBroadcastInstruction::HloBroadcastInstruction(
    const Shape& shape, HloInstruction* operand,
    absl::Span<const int64_t> broadcast_dimension)
    : HloDimensionsInstruction(HloOpcode::kBroadcast, shape,
                               broadcast_dimension) {
  AppendOperand(operand);
}

std::unique_ptr<HloInstruction>
HloBroadcastInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloBroadcastInstruction>(shape, new_operands[0],
                                                   dimensions());
}

HloDynamicReshapeInstruction::HloDynamicReshapeInstruction(
    const Shape& shape, HloInstruction* data_operand,
    absl::Span<HloInstruction* const> dim_sizes)
    : HloInstruction(HloOpcode::kDynamicReshape, shape) {
  AppendOperand(data_operand);
  for (HloInstruction* operand : dim_sizes) {
    AppendOperand(operand);
  }
}

std::unique_ptr<HloInstruction>
HloDynamicReshapeInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_GE(new_operands.size(), 1);
  return std::make_unique<HloDynamicReshapeInstruction>(
      shape, new_operands[0], new_operands.subspan(1));
}

HloReshapeInstruction::HloReshapeInstruction(const Shape& shape,
                                             HloInstruction* operand,
                                             int64_t inferred_dimension)
    : HloInstruction(HloOpcode::kReshape, shape),
      inferred_dimension_(inferred_dimension) {
  AppendOperand(operand);
}

void HloReshapeInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  if (inferred_dimension_ != -1) {
    proto->add_dimensions(inferred_dimension_);
  }
}

void HloReshapeInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (inferred_dimension() == -1) {
    return;
  }
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "inferred_dimension=", inferred_dimension());
  });
}

bool HloReshapeInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloReshapeInstruction&>(other);
  return inferred_dimension() == casted_other.inferred_dimension();
}

std::unique_ptr<HloInstruction> HloReshapeInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloReshapeInstruction>(shape, new_operands[0],
                                                 inferred_dimension());
}

HloMapInstruction::HloMapInstruction(const Shape& shape,
                                     absl::Span<HloInstruction* const> operands,
                                     HloComputation* map_computation)
    : HloInstruction(HloOpcode::kMap, shape) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
  AppendComputation(map_computation);
  // TODO(b/65689298) Remove code below once Map is generalized to accept
  // arbitrary map dimensions.
  dimensions_.resize(shape.dimensions().size());
  absl::c_iota(dimensions_, 0);
}

void HloMapInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (int64_t dimension : dimensions_) {
    proto->add_dimensions(dimension);
  }
}

bool HloMapInstruction::IsElementwiseImpl(
    const std::optional<int64_t>& operand_idx) const {
  if (!dimensions().empty()) {
    // Check that the map is executed in elementwise compatible dimensions.
    if (dimensions().size() != shape().dimensions().size()) {
      return false;
    }
    for (int i = 0; i < dimensions().size(); ++i) {
      if (dimensions()[i] != i) {
        return false;
      }
    }
  }
  return true;
}

void HloMapInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append("dimensions={");
    AppendJoin(printer, dimensions(), ",");
    printer->Append("}");
  });
}

bool HloMapInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloMapInstruction&>(other);
  return eq_computations(to_apply(), casted_other.to_apply()) &&
         dimensions() == casted_other.dimensions();
}

std::unique_ptr<HloInstruction> HloMapInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloMapInstruction>(shape, new_operands, to_apply());
}

HloSliceInstruction::HloSliceInstruction(
    const Shape& shape, HloInstruction* operand,
    absl::Span<const int64_t> start_indices,
    absl::Span<const int64_t> limit_indices, absl::Span<const int64_t> strides)
    : HloInstruction(HloOpcode::kSlice, shape),
      slice_starts_(start_indices.begin(), start_indices.end()),
      slice_limits_(limit_indices.begin(), limit_indices.end()),
      slice_strides_(strides.begin(), strides.end()) {
  AppendOperand(operand);
  // For backward compatibility with old serialized computations: if there are
  // no strides, assume all strides are 1.
  // TODO(b/63317920): remove this code.
  if (slice_strides_.empty()) {
    slice_strides_ = std::vector<int64_t>(start_indices.size(), 1LL);
  }
}

void HloSliceInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (int i = 0; i < slice_starts_.size(); ++i) {
    auto* slice_dimension = proto->add_slice_dimensions();
    slice_dimension->set_start(slice_starts_[i]);
    slice_dimension->set_limit(slice_limits_[i]);
    slice_dimension->set_stride(slice_strides_[i]);
  }
}

void HloSliceInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    const bool omit_stride = absl::c_all_of(
        slice_strides_, [](int64_t stride) { return stride == 1; });
    printer->Append("slice={");
    AppendJoin(printer, slice_starts_, ", ",
               [&](Printer* printer, auto& slice_start) {
                 const auto i = &slice_start - slice_starts_.data();
                 AppendCat(printer, "[", slice_start, ":", slice_limits_[i]);
                 if (!omit_stride) {
                   AppendCat(printer, ":", slice_strides_[i]);
                 }
                 printer->Append("]");
               });
    printer->Append("}");
  });
}

bool HloSliceInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& other_slice = static_cast<const HloSliceInstruction&>(other);
  return slice_starts_ == other_slice.slice_starts_ &&
         slice_limits_ == other_slice.slice_limits_ &&
         slice_strides_ == other_slice.slice_strides_;
}

std::unique_ptr<HloInstruction> HloSliceInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloSliceInstruction>(
      shape, new_operands[0], slice_starts_, slice_limits_, slice_strides_);
}

HloConstantInstruction::HloConstantInstruction(Literal literal)
    : HloInstruction(HloOpcode::kConstant, literal.shape()),
      literal_(std::make_shared<Literal>(std::move(literal))) {}

HloConstantInstruction::HloConstantInstruction(Literal literal,
                                               const Shape& shape)
    : HloInstruction(HloOpcode::kConstant, shape),
      literal_(std::make_shared<Literal>(std::move(literal))) {}

HloConstantInstruction::HloConstantInstruction(std::shared_ptr<Literal> literal,
                                               const Shape& shape)
    : HloInstruction(HloOpcode::kConstant, shape),
      literal_(std::move(literal)) {}

HloConstantInstruction::HloConstantInstruction(const Shape& shape)
    : HloInstruction(HloOpcode::kConstant, shape) {}

void HloConstantInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  if (literal_ != nullptr) {
    *proto->mutable_literal() = literal_->ToProto();
  }
}

bool HloConstantInstruction::IsElementwiseImpl(
    const std::optional<int64_t>& operand_idx) const {
  return true;
}

void HloConstantInstruction::RelayoutConstant(const Layout& new_layout,
                                              const ShapeIndex& shape_index) {
  Shape* mutable_array_subshape =
      ShapeUtil::GetMutableSubshape(mutable_shape(), shape_index);
  CHECK(mutable_array_subshape->IsArray());

  // Normally array_subshape will always have a layout, but this invariant is
  // temporarily broken in LayoutAssignment::AssignLayouts where all shape
  // layouts are cleared. The inner condition below ensures that we don't
  // unnecessarily relayout literals in that case.

  if (!mutable_array_subshape->has_layout() ||
      !LayoutUtil::Equal(mutable_array_subshape->layout(), new_layout)) {
    if (!LayoutUtil::Equal(
            new_layout,
            ShapeUtil::GetSubshape(literal().shape(), shape_index).layout())) {
      // Only relayout literals if that's really necessary.
      Literal new_literal = literal_->Relayout(new_layout, shape_index);
      *mutable_literal() = std::move(new_literal);
    }
    *mutable_array_subshape->mutable_layout() = new_layout;
  }
}

bool HloConstantInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& other_slice = static_cast<const HloSliceInstruction&>(other);
  return literal() == other_slice.literal();
}

std::unique_ptr<HloInstruction>
HloConstantInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  if (literal_ == nullptr) {
    return std::make_unique<HloConstantInstruction>(this->shape());
  }
  // Literal's shape may have no/different tiling info. Use this instruction's
  // shape instead.
  CHECK(Shape::Equal().MinorToMajorOnlyInLayout()(literal_->shape(),
                                                  this->shape()));
  return std::make_unique<HloConstantInstruction>(literal_, this->shape());
}

void HloConstantInstruction::PrintOperandsWithCanonicalNameMap(
    Printer* printer, const HloPrintOptions& options,
    CanonicalNameMap* canonical_name_map) const {
  if (options.print_only_essential_constants()) {
    if (literal_ == nullptr) {
      printer->Append("{...}");
      return;
    }
    if (literal().IsAll(0)) {
      printer->Append("0");
      return;
    }
    if (literal().IsAll(1)) {
      printer->Append("1");
      return;
    }
    if (shape().AreAllLeavesIntegers()) {
      // The following prevents high compilation latencies caused by serializing
      // large constant tensors; for example: b/265669625. The limit of 500k was
      // chosen empirically to make sure that serialization of the `literal_` is
      // less than a second.
      const int64_t num_constants =
          shape().IsArray()
              ? absl::c_accumulate(shape().dimensions(), int64_t{1},
                                   std::multiplies<int64_t>())
              : 1;
      if (num_constants <= 500'000) {
        literal_->PrintWithoutShapeOneline(printer);
        return;
      }
    }
    printer->Append("{...}");
    return;
  }

  // For constants, show the actual value in place of an empty operand list.
  if (literal_ != nullptr &&
      ((shape().IsArray() && ShapeUtil::ElementsIn(shape()) <= 10) ||
       options.print_large_constants())) {
    // Literal::ToString emits multidimensional arrays over multiple
    // lines. Compact this into one line by stripping out white space.
    literal_->PrintWithoutShapeOneline(printer);
  } else {
    // Do not show large constants or tuples.
    printer->Append("{...}");
  }
}

HloCallableInstruction::HloCallableInstruction(HloOpcode opcode,
                                               const Shape& shape)
    : HloInstruction(opcode, shape) {}

HloCallableInstruction::HloCallableInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands)
    : HloInstruction(opcode, shape) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
  SetAndSanitizeName(HloOpcodeString(opcode));
}

HloCallableInstruction::HloCallableInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    HloComputation* called_computation, absl::string_view prefix)
    : HloInstruction(opcode, shape) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
  SetAndSanitizeName(absl::StrCat(prefix, HloOpcodeString(opcode)));
  AppendComputation(called_computation);
}

HloCallableInstruction::HloCallableInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands,
    absl::Span<HloComputation* const> called_computations)
    : HloInstruction(opcode, shape) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
  SetAndSanitizeName(HloOpcodeString(opcode));
  for (HloComputation* called_computation : called_computations) {
    AppendComputation(called_computation);
  }
}

HloCallableInstruction::HloCallableInstruction(HloOpcode opcode,
                                               const Shape& shape,
                                               const std::string& name,
                                               const std::string& attributes,
                                               int64_t version)
    : HloInstruction(opcode, shape) {
  FrontendAttributes frontend_attributes =
      BuildFrontendAttributesForComposite(name, attributes, version);
  add_frontend_attributes(frontend_attributes);
  set_is_composite(true);
}

HloCallableInstruction::HloCallableInstruction(
    HloOpcode opcode, const Shape& shape,
    absl::Span<HloInstruction* const> operands, HloComputation* decomposition,
    const std::string& name, const std::string& attributes, int64_t version)
    : HloInstruction(opcode, shape) {
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
  SetAndSanitizeName(HloOpcodeString(opcode));
  AppendComputation(decomposition);

  FrontendAttributes frontend_attributes =
      BuildFrontendAttributesForComposite(name, attributes, version);
  add_frontend_attributes(frontend_attributes);
  set_is_composite(true);
}

HloCallableInstruction::~HloCallableInstruction() { ClearCalledComputations(); }

HloComputation* HloCallableInstruction::called_computation() const {
  CHECK(!called_computations().empty());
  return called_computations().front();
}

HloInstruction* HloCallableInstruction::called_computation_root() const {
  return called_computation()->root_instruction();
}

HloInstruction* HloCallableInstruction::AddCallOperand(
    HloInstruction* new_operand) {
  CHECK_EQ(operand_count(),
           called_computation()->parameter_instructions().size());
  const int64_t param_no = operand_count();
  std::string param_name = StrCat("param_", param_no);
  HloInstruction* called_computation_parameter =
      called_computation()->AddParameter(HloInstruction::CreateParameter(
          param_no, new_operand->shape(), param_name));
  AppendOperand(new_operand);
  return called_computation_parameter;
}

HloInstruction* HloCallableInstruction::AppendInstructionIntoCalledComputation(
    HloInstruction* instruction_to_append, bool add_output) {
  // When add_output is false, this callable instruction must be a user of
  // instruction_to_append.
  if (!add_output) {
    CHECK(IsUserOf(instruction_to_append));
  }
  return CloneAndAppendInstructionIntoCalledComputation(instruction_to_append,
                                                        add_output);
}

HloInstruction*
HloCallableInstruction::CloneAndAppendInstructionIntoCalledComputation(
    HloInstruction* instruction_to_append, bool add_output) {
  VLOG(3) << "CloneAndAppendInstructionIntoCalledComputation:\n"
          << instruction_to_append->ToString();
  HloInstruction* clone = nullptr;
  bool do_not_clone =
      instruction_to_append->opcode() == HloOpcode::kTuple &&
      absl::c_all_of(instruction_to_append->users(), [](HloInstruction* u) {
        return u->opcode() == HloOpcode::kGetTupleElement;
      });
  if (called_computations().empty()) {
    // New fusion instruction. It should not be a multi-output instruction.
    CHECK(!add_output);
    auto builder = HloComputation::Builder(default_called_computation_name());
    builder.AddInstruction(instruction_to_append->Clone(/*suffix=*/""));
    auto* new_computation = ABSL_DIE_IF_NULL(instruction_to_append->GetModule())
                                ->AddEmbeddedComputation(builder.Build());
    AppendComputation(new_computation);
    clone = called_computation_root();
  } else {
    // When add_output is false, instruction_to_append is necessarily an
    // operand of the callable instruction. After appending this will no
    // longer be the case. Remove the operand from the operand list and remove
    // its corresponding called computation parameter instruction.
    bool in_operand_list =
        absl::c_linear_search(operands(), instruction_to_append);
    CHECK(add_output || in_operand_list);
    if (do_not_clone) {
      // We assume all uses of a kTuple operation are GTE ops. In this case,
      // we don't need to clone 'instruction_to_append'.
      CHECK(!in_operand_list);
      clone = instruction_to_append;
    } else {
      clone = called_computation()->AddInstruction(
          instruction_to_append->Clone(/*suffix=*/""));
    }
    const auto& called_computation_parameters =
        called_computation()->parameter_instructions();
    for (int64_t operand_num = 0; operand_num < operand_count();
         ++operand_num) {
      if (instruction_to_append == operand(operand_num)) {
        // Replace the called computation parameter instruction's uses with
        // the clone.
        HloInstruction* called_computation_parameter =
            called_computation_parameters[operand_num];
        CHECK_OK(called_computation_parameter->ReplaceAllUsesWith(clone));

        // Remove the corresponding called computation parameter and operand
        // from their respective vectors.
        CHECK_OK(called_computation()->RemoveParameter(operand_num));
        RemoveOperandAt(operand_num);
        break;
      }
    }
    // We've cloned instruction_to_append into this callable instruction, so
    // this callable instruction is no longer a use of instruction_to_append.
    if (in_operand_list) {
      DetachFrom(instruction_to_append);
      // When the instruction_to_append does not have other users, we don't
      // need to generate a multi-output instruction.
      if (instruction_to_append->user_count() == 0) {
        add_output = false;
      }
    }
  }

  // Reread the parameters in the computation.
  const auto& called_computation_parameters =
      called_computation()->parameter_instructions();

  // Add each operand of the clone as an operand of the callable instruction.
  // A complication is that some clone operands may already be operands of the
  // callable instruction.
  for (int64_t operand_num = 0; operand_num < clone->operand_count();
       ++operand_num) {
    HloInstruction* operand = clone->mutable_operand(operand_num);

    // See if this operand is already an operand of the callable instruction.
    CHECK_EQ(operands().size(), called_computation_parameters.size());
    HloInstruction* called_computation_parameter = nullptr;
    if (auto it = absl::c_find(operands(), operand); it != operands().end()) {
      called_computation_parameter =
          called_computation_parameters[it - operands().begin()];
    }

    if (called_computation_parameter == nullptr) {
      // Clone's operand was not already an operand of the callable
      // instruction. Add it as an operand and add a corresponding called
      // computation parameter instruction.

      // No need to create an original value for an added parameter as the
      // original value is saved in the corresponding argument.
      called_computation_parameter = AddCallOperand(operand);
    }
    CHECK_OK(
        clone->ReplaceOperandWith(operand_num, called_computation_parameter));
  }

  if (clone != instruction_to_append) {
    VLOG(2) << "New clone:\n" << clone->ToString();
  }

  if (add_output) {
    int64_t user_count = instruction_to_append->user_count();
    CHECK(user_count > 0 || instruction_to_append->IsRoot() ||
          instruction_to_append->HasSideEffect())
        << "Unable to append instruction: " << instruction_to_append->ToString()
        << ", which has " << user_count << " users.";
    HloInstruction* root = called_computation_root();
    // Check whether we have replaced an existing fusion root with 'clone'. If
    // yes, no need to add a duplicate root.
    if (root->opcode() == HloOpcode::kTuple) {
      for (int64_t i = 0; i < root->operand_count(); ++i) {
        if (root->operand(i) == clone) {
          HloInstruction* new_gte = AddInstruction(
              HloInstruction::CreateGetTupleElement(clone->shape(), this, i));
          CHECK_OK(instruction_to_append->ReplaceAllUsesWith(new_gte));
          return clone;
        }
      }
    }
    // If this is already a multioutput instruction, expand the root tuple
    // by 1.
    HloInstruction::InstructionVector tuple_elements;
    bool newly_created_tuple_instr = false;
    if (root->opcode() == HloOpcode::kTuple) {
      tuple_elements = root->operands();
    } else {
      tuple_elements.push_back(root);
      newly_created_tuple_instr = true;
    }
    if (clone->opcode() == HloOpcode::kTuple) {
      for (HloInstruction* inst : clone->operands()) {
        tuple_elements.push_back(inst);
      }
    } else {
      tuple_elements.push_back(clone);
    }
    HloInstruction* new_root = called_computation()->AddInstruction(
        HloInstruction::CreateTuple(tuple_elements));
    new_root->set_original_value(
        xla::OriginalValue::CreateFromInstruction(new_root));

    // No need to create an original value for a new root with added outputs
    // as the original value is saved in the get-tuple-element instructions
    // that use it.
    called_computation()->set_root_instruction(new_root,
                                               /*accept_different_shape=*/true);

    // Update the shape of the fusion instruction to the shape of the new root.
    *mutable_shape() = new_root->shape();
    // Update the original value of the fusion instruction to the original value
    // of the new root.
    set_original_value(new_root->original_value());

    // The instruction might have an existing sharding, which will no longer
    // be valid after we change the shape. So clear the sharding.
    clear_sharding();
    if (root->opcode() == HloOpcode::kTuple) {
      CHECK_OK(called_computation()->RemoveInstruction(root));
    }

    // If this is a newly created multioutput instruction, we need to update
    // the use of the original callable instruction.
    if (newly_created_tuple_instr) {
      HloInstruction* new_instr = AddInstruction(
          HloInstruction::CreateGetTupleElement(root->shape(), this, 0));
      CHECK_OK(ReplaceAllUsesWithDifferentShape(new_instr));
    }
    int64_t index = tuple_elements.size();
    if (do_not_clone) {
      CHECK_EQ(clone, instruction_to_append);
      index -= instruction_to_append->operand_count();
      std::vector<HloInstruction*> to_be_removed;
      const auto& users = instruction_to_append->users();
      to_be_removed.reserve(users.size());
      for (HloInstruction* old_gte : users) {
        CHECK_EQ(old_gte->opcode(), HloOpcode::kGetTupleElement);
        int64_t old_tuple_index = old_gte->tuple_index();
        HloInstruction* new_gte =
            AddInstruction(HloInstruction::CreateGetTupleElement(
                old_gte->shape(), this, index + old_tuple_index));
        CHECK_OK(old_gte->ReplaceAllUsesWith(new_gte));
        to_be_removed.push_back(old_gte);
      }
      for (HloInstruction* old_gte : to_be_removed) {
        CHECK_OK(parent()->RemoveInstruction(old_gte));
      }
    } else {
      HloInstruction* new_gte =
          AddInstruction(HloInstruction::CreateGetTupleElement(
              clone->shape(), this, index - 1));
      CHECK_OK(instruction_to_append->ReplaceAllUsesWith(new_gte));
    }
  }

  return clone;
}

absl::InlinedVector<HloComputation*, 1>
HloCallableInstruction::GetOrCloneCalledComputations(
    HloCloneContext* context) const {
  HloModule* module = context != nullptr ? context->module() : GetModule();
  absl::InlinedVector<HloComputation*, 1> new_called_computations;
  const std::string& suffix = context != nullptr ? context->suffix() : "clone";
  for (HloComputation* comp : called_computations()) {
    HloComputation* new_custom_call_computation = nullptr;
    if (context != nullptr) {
      new_custom_call_computation = context->FindComputation(comp);
    }
    if (new_custom_call_computation == nullptr) {
      new_custom_call_computation =
          module->AddEmbeddedComputation(comp->Clone(suffix, context));
    }
    new_called_computations.push_back(new_custom_call_computation);
  }
  return new_called_computations;
}

void HloCallableInstruction::RecursivelySetComputationsThreadName(
    absl::string_view execution_thread) {
  for (HloComputation* comp : called_computations()) {
    SetThreadName(comp, execution_thread);
  }
}

HloFusionInstruction::HloFusionInstruction(const Shape& shape,
                                           FusionKind fusion_kind,
                                           HloInstruction* fused_root,
                                           absl::string_view prefix)
    : HloCallableInstruction(HloOpcode::kFusion, shape),
      fusion_kind_(fusion_kind) {
  CHECK(fused_root != nullptr);
  SetAndSanitizeName(absl::StrCat(prefix, HloOpcodeString(opcode())));

  set_metadata(fused_root->metadata());
  set_frontend_attributes(fused_root->frontend_attributes());
  CHECK(fused_root->IsFusible()) << fused_root->ToString();
  CloneAndAppendInstructionIntoCalledComputation(fused_root);
}

HloFusionInstruction::HloFusionInstruction(
    const Shape& shape, FusionKind fusion_kind,
    absl::Span<HloInstruction* const> operands,
    HloComputation* fusion_computation, absl::string_view prefix)
    : HloCallableInstruction(HloOpcode::kFusion, shape, operands,
                             fusion_computation, prefix),
      fusion_kind_(fusion_kind) {}

HloInstruction*
HloFusionInstruction::CloneAndAppendInstructionIntoCalledComputation(
    HloInstruction* instruction_to_append, bool add_output) {
  CHECK(instruction_to_append->IsFusible())
      << instruction_to_append->ToString();
  return HloCallableInstruction::CloneAndAppendInstructionIntoCalledComputation(
      instruction_to_append, add_output);
}

std::string HloFusionInstruction::ToCategory() const {
  switch (fusion_kind()) {
    case FusionKind::kLoop:
      return "loop fusion";
    case FusionKind::kInput:
      return "input fusion";
    case FusionKind::kOutput:
      return "output fusion";
    case FusionKind::kCustom:
      return "custom fusion";
  }
}

void HloFusionInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_fusion_kind() = std::string(xla::ToString(fusion_kind()));
  for (const auto& pair : output_to_operand_aliasing()) {
    auto* aliasing = proto->add_output_operand_aliasing();
    aliasing->set_operand_index(pair.second.first);
    for (int64_t index : pair.first) {
      aliasing->add_output_shape_index(index);
    }
    for (int64_t index : pair.second.second) {
      aliasing->add_operand_shape_index(index);
    }
  }
  proto->add_called_computation_ids(
      fused_instructions_computation()->unique_id());
}

bool HloFusionInstruction::IsElementwiseImpl(
    const std::optional<int64_t>& operand_idx) const {
  if (!operand_idx.has_value()) {
    return absl::c_all_of(fused_instructions(),
                          [](const HloInstruction* fused) {
                            return fused->opcode() == HloOpcode::kParameter ||
                                   fused->IsElementwise();
                          });
  }
  // A loop-fusion is elementwise on an operand if all operations (computed
  // using BFS) between the operand and the fused root are elementwise.
  std::deque<HloInstruction*> worklist;
  absl::flat_hash_set<const HloInstruction*> visited;
  worklist.push_back(fused_parameter(operand_idx.value()));
  visited.insert(fused_parameter(operand_idx.value()));
  while (!worklist.empty()) {
    HloInstruction* operand = worklist.front();
    worklist.pop_front();
    for (HloInstruction* user : operand->users()) {
      CHECK_GE(user->unique_id(), 0);
      if (visited.contains(user)) {
        continue;
      }
      if (user->IsElementwise() ||
          IsInstructionElementwiseOnOperand(user, operand)) {
        worklist.push_back(user);
        visited.insert(user);
      } else {
        return false;
      }
    }
  }
  return true;
}

HloInstruction* HloFusionInstruction::AddFusionOperand(
    HloInstruction* new_operand) {
  return AddCallOperand(new_operand);
}

void HloFusionInstruction::MergeFusionInstruction(
    HloFusionInstruction* instruction_to_merge, bool remove_computation) {
  CHECK(absl::c_linear_search(operands(), instruction_to_merge));
  // Clone the instruction from which to merge fused instructions.
  std::unique_ptr<HloInstruction> cloned = instruction_to_merge->Clone();
  HloFusionInstruction* cloned_fusion =
      static_cast<HloFusionInstruction*>(cloned.get());
  // Replace uses of fused parameters with the corresponding operand of the
  // fusion.  Add all non-parameter fused instructions to
  // 'unfused_instructions' to be merged into 'this'.  This is done in reverse
  // post order.
  std::vector<HloInstruction*> unfused_instructions;
  auto fused_instructions = cloned_fusion->fused_instructions_computation()
                                ->MakeInstructionPostOrder();
  for (auto fused_it = fused_instructions.rbegin();
       fused_it != fused_instructions.rend(); ++fused_it) {
    HloInstruction* fused_instruction = *fused_it;
    if (fused_instruction->opcode() == HloOpcode::kParameter) {
      CHECK_OK(
          fused_instruction->ReplaceAllUsesWith(cloned_fusion->mutable_operand(
              fused_instruction->parameter_number())));
    } else {
      unfused_instructions.push_back(fused_instruction);
    }
  }

  // If there are no unfused instructions, the fused computation must consist
  // only of kParameter instructions. Make the operand of the corresponding
  // parameter number the new root.
  HloInstruction* unfused_root =
      unfused_instructions.empty()
          ? instruction_to_merge->mutable_operand(
                instruction_to_merge->fused_instructions_computation()
                    ->root_instruction()
                    ->parameter_number())
          : unfused_instructions.front();
  CHECK(unfused_root == cloned_fusion->fused_expression_root() ||
        unfused_instructions.empty());
  // Replace instruction_to_merge use of 'this' with unfused_root.
  CHECK_OK(instruction_to_merge->ReplaceUseWith(this, unfused_root));

  // Build a dummy root for the cloned fusion as we may remove the original
  // root in the fusion process.
  if (!unfused_instructions.empty()) {
    HloComputation* computation = unfused_root->parent();
    auto* dummy_root = computation->AddInstruction(
        HloInstruction::CreateConstant(LiteralUtil::Zero(U32)));
    computation->set_root_instruction(dummy_root,
                                      /*accept_different_shape=*/true);
  }

  // Fuse 'unfused_instructions' into 'this'. Everytime we fuse an instruction
  // we remove it from the closed fusion node. This is so that we don't add
  // extra users to the producer of that instruction (we use user count to
  // decide if a side-effectful instruction is fusible).
  for (HloInstruction* instruction : unfused_instructions) {
    auto* fused = FuseInstruction(instruction);
    CHECK_OK(instruction->ReplaceAllUsesWith(fused));
    CHECK_OK(instruction->parent()->RemoveInstruction(instruction));
  }
  CHECK_EQ(0, cloned_fusion->user_count());
  if (remove_computation) {
    CHECK_OK(GetModule()->RemoveEmbeddedComputation(
        cloned_fusion->fused_instructions_computation()));
  }
}

void HloFusionInstruction::MergeFusionInstructionIntoMultiOutput(
    HloFusionInstruction* instruction_to_merge, bool remove_computation) {
  // Add all non-parameter fused instructions to 'unfused_instructions' to be
  // merged into 'this'. `old_to_new' maps the instructions in the fused node
  // to the disassembled fusion instructions.
  // Note that we add the unfused instructions to this->parent_ computation.
  // This is necessary because the unique_id needs for an instruction and
  // it's only added when inserting to the computation.
  absl::flat_hash_map<HloInstruction*, HloInstruction*> old_to_new;
  std::vector<HloInstruction*> unfused_instructions;
  absl::flat_hash_set<const HloInstruction*> new_roots;
  std::vector<std::pair<HloInstruction*, int64_t>> old_fusion_outputs;
  HloComputation* computation_to_merge =
      instruction_to_merge->fused_instructions_computation();
  for (HloInstruction* fused_instruction :
       computation_to_merge->MakeInstructionPostOrder()) {
    if (fused_instruction->opcode() == HloOpcode::kParameter) {
      CHECK(old_to_new
                .insert({fused_instruction,
                         instruction_to_merge->mutable_operand(
                             fused_instruction->parameter_number())})
                .second);
      continue;
    }
    // If 'instruction_to_merge' is a multi-output fusion, we need to skip the
    // root tuple, but remember which of the fusion outputs need to become
    // fusion outputs of the merged fusion.
    if (fused_instruction->opcode() == HloOpcode::kTuple &&
        fused_instruction == instruction_to_merge->fused_expression_root()) {
      for (const HloInstruction* user : instruction_to_merge->users()) {
        CHECK_EQ(user->opcode(), HloOpcode::kGetTupleElement);
        old_fusion_outputs.emplace_back(
            fused_instruction->mutable_operand(user->tuple_index()),
            user->tuple_index());
        const bool has_outside_user = absl::c_any_of(
            user->users(), [this](const HloInstruction* gte_user) {
              return gte_user != this;
            });
        if (!has_outside_user && !user->IsRoot()) {
          continue;
        }

        new_roots.insert(
            FindOrDie(old_to_new, old_fusion_outputs.back().first));
      }
      continue;
    }

    // Here we clone the insertion and call FuseInstructionIntoMultiOutput()
    // which clones again. This can be improved.
    std::vector<HloInstruction*> new_operands;
    new_operands.reserve(fused_instruction->operand_count());
    for (HloInstruction* new_operand : fused_instruction->mutable_operands()) {
      new_operands.push_back(FindOrDie(old_to_new, new_operand));
    }
    HloInstruction* cloned_instruction =
        parent()->AddInstruction(fused_instruction->CloneWithNewOperands(
            fused_instruction->shape(), new_operands, /*suffix=*/"clone"));
    unfused_instructions.push_back(cloned_instruction);
    CHECK(old_to_new.emplace(fused_instruction, cloned_instruction).second);
  }
  auto relay_and_drop_control_deps = [this](HloInstruction* instr) {
    if (instr->HasControlDependencies()) {
      CHECK_OK(instr->RemoveControlDependencyTo(this));
      CHECK_OK(this->RemoveControlDependencyTo(instr));
      CHECK_OK(this->CopyAllControlDepsFrom(instr));
      CHECK_OK(instr->DropAllControlDeps());
    }
  };
  if (instruction_to_merge->IsMultiOutputFusion()) {
    for (auto [old_root, tuple_index] : old_fusion_outputs) {
      HloInstruction* new_root = FindOrDie(old_to_new, old_root);
      // Replace the get-tuple-element op on 'instruction_to_merge' referencing
      // the same tuple index as 'old_root' with 'new_root'.
      for (HloInstruction* gte : instruction_to_merge->users()) {
        if (gte->opcode() == HloOpcode::kGetTupleElement &&
            gte->tuple_index() == tuple_index) {
          CHECK_OK(gte->ReplaceAllUsesWith(new_root));
          relay_and_drop_control_deps(gte);
          CHECK_OK(gte->parent()->RemoveInstruction(gte));
        }
      }
    }
  } else {
    // If there are no unfused instructions, the fused computation must consist
    // only of kParameter instructions. Make the operand of the corresponding
    // parameter number the new root.
    HloInstruction* unfused_root =
        unfused_instructions.empty()
            ? instruction_to_merge->mutable_operand(
                  instruction_to_merge->fused_instructions_computation()
                      ->root_instruction()
                      ->parameter_number())
            : unfused_instructions.back();
    new_roots.insert(unfused_root);
    CHECK_OK(instruction_to_merge->ReplaceAllUsesWith(unfused_root));
  }
  relay_and_drop_control_deps(instruction_to_merge);
  CHECK_OK(
      instruction_to_merge->parent()->RemoveInstruction(instruction_to_merge));
  if (GetModule() != nullptr && remove_computation) {
    CHECK_OK(GetModule()->RemoveEmbeddedComputation(computation_to_merge));
  }
  for (int64_t i = unfused_instructions.size() - 1; i >= 0; --i) {
    HloInstruction* instruction = unfused_instructions[i];
    if (new_roots.contains(instruction)) {
      FuseInstructionIntoMultiOutput(instruction);
    } else {
      FuseInstruction(instruction);
    }
    CHECK_OK(instruction->parent()->RemoveInstruction(instruction));
  }
}

HloComputation* HloFusionInstruction::fused_instructions_computation() const {
  CHECK_EQ(called_computations().size(), 1);
  return called_computations().front();
}

HloInstruction* HloFusionInstruction::fused_expression_root() const {
  return fused_instructions_computation()->root_instruction();
}

HloInstruction* HloFusionInstruction::fused_parameter(
    int64_t parameter_number) const {
  return fused_instructions_computation()->parameter_instruction(
      parameter_number);
}

const HloInstruction::InstructionVector&
HloFusionInstruction::fused_parameters() const {
  return fused_instructions_computation()->parameter_instructions();
}

tsl::gtl::iterator_range<HloInstructionUnwrappingConstIterator>
HloFusionInstruction::fused_instructions() const {
  const HloComputation* subcomp = fused_instructions_computation();
  return subcomp->instructions();
}

tsl::gtl::iterator_range<HloInstructionUnwrappingIterator>
HloFusionInstruction::fused_instructions() {
  return fused_instructions_computation()->instructions();
}

int64_t HloFusionInstruction::fused_instruction_count() const {
  return fused_instructions_computation()->instruction_count();
}

void HloFusionInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "kind=", xla::ToString(fusion_kind()));
  });
  if (!output_to_operand_aliasing().empty()) {
    printer.Next([this](Printer* printer) {
      printer->Append("output_to_operand_aliasing={");
      AppendJoin(printer, output_to_operand_aliasing(), ", ",
                 [](Printer* printer, auto& pair) {
                   AppendCat(printer, pair.first.ToString(), ": (",
                             pair.second.first, ", ");
                   AppendCat(printer, pair.second.second.ToString(), ")");
                 });
      printer->Append("}");
    });
  }
}

bool HloFusionInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  return fusion_kind() == other.fusion_kind() &&
         output_to_operand_aliasing() ==
             static_cast<const HloFusionInstruction&>(other)
                 .output_to_operand_aliasing() &&
         eq_computations(fused_instructions_computation(),
                         other.fused_instructions_computation());
}

std::unique_ptr<HloInstruction> HloFusionInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  auto new_fused_computation = GetOrCloneCalledComputations(context);
  CHECK_EQ(new_fused_computation.size(), 1);
  auto new_fusion_instruction = std::make_unique<HloFusionInstruction>(
      shape, fusion_kind(), new_operands, new_fused_computation.front());
  new_fusion_instruction->set_output_to_operand_aliasing(
      output_to_operand_aliasing());
  return new_fusion_instruction;
}

absl::Status HloFusionInstruction::DeduplicateFusionOperands() {
  if (IsCustomFusion()) {
    return absl::OkStatus();
  }
  absl::flat_hash_map<const HloInstruction*, int> operand_indices;
  std::vector<int> operands_to_remove;
  const int count = operand_count();
  operands_to_remove.reserve(count);
  for (int i = 0; i < count; ++i) {
    auto emplace_result = operand_indices.emplace(operand(i), i);
    if (!emplace_result.second) {
      ABSL_RETURN_IF_ERROR(fused_parameter(i)->ReplaceAllUsesWith(
          fused_parameter(emplace_result.first->second)));
      operands_to_remove.push_back(i);
    }
  }
  if (operands_to_remove.empty()) {
    return absl::OkStatus();
  }
  ABSL_RETURN_IF_ERROR(fused_instructions_computation()
                           ->RemoveUnusedParametersFromFusedComputation());
  // Keep every aliasing entry on the operand it names.
  auto aliasing = output_to_operand_aliasing();
  std::vector<const HloInstruction*> aliased_operands;
  aliased_operands.reserve(aliasing.size());
  for (const auto& entry : aliasing) {
    aliased_operands.push_back(operand(entry.second.first));
  }
  RemoveOperandsAtAscendingIndices(operands_to_remove);
  for (int64_t i = 0; i < aliasing.size(); ++i) {
    aliasing[i].second.first = operand_index(aliased_operands[i]);
  }
  set_output_to_operand_aliasing(std::move(aliasing));
  return absl::OkStatus();
}

absl::Status HloFusionInstruction::PermuteFusionOperands(
    absl::Span<const int64_t> permutation) {
  if (permutation.size() != operand_count()) {
    return absl::InvalidArgumentError(
        "Permutation size must match the number of operands.");
  }
  std::vector<bool> seen(permutation.size(), false);
  for (int64_t i = 0; i < permutation.size(); ++i) {
    if (permutation[i] < 0 || permutation[i] >= operand_count() ||
        seen[permutation[i]]) {
      return absl::InvalidArgumentError(
          "Argument is not a permutation of operand indices.");
    }
    seen[permutation[i]] = true;
  }

  ABSL_RETURN_IF_ERROR(
      fused_instructions_computation()->PermuteParameters(permutation));
  InstructionVector new_operands(operand_count());
  for (int64_t i = 0; i < operand_count(); ++i) {
    new_operands[permutation[i]] = mutable_operand(i);
  }
  RemoveAllOperands();
  AppendOperands(new_operands);
  return absl::OkStatus();
}

HloCallInstruction::HloCallInstruction(const Shape& shape,
                                       HloInstruction* called_computation_root)
    : HloCallableInstruction(HloOpcode::kCall, shape) {
  CHECK(called_computation_root != nullptr);
  SetAndSanitizeName(HloOpcodeString(opcode()));
  set_metadata(called_computation_root->metadata());
  CloneAndAppendInstructionIntoCalledComputation(called_computation_root);
}

HloCallInstruction::HloCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* called_computation)
    : HloCallableInstruction(HloOpcode::kCall, shape, operands,
                             called_computation) {}

HloCallInstruction::HloCallInstruction(const Shape& shape,
                                       HloInstruction* decomposition_root,
                                       const std::string& name,
                                       const std::string& attributes,
                                       int64_t version)
    : HloCallableInstruction(HloOpcode::kCall, shape, name, attributes,
                             version) {
  CHECK(decomposition_root != nullptr);
  SetAndSanitizeName(HloOpcodeString(opcode()));

  FrontendAttributes frontend_attributes;
  frontend_attributes.mutable_map()->insert({"composite.name", name});
  frontend_attributes.mutable_map()->insert(
      {"composite.attributes", attributes});
  frontend_attributes.mutable_map()->insert(
      {"composite.version", std::to_string(version)});

  add_frontend_attributes(frontend_attributes);
  set_is_composite(true);
  set_metadata(decomposition_root->metadata());
  CloneAndAppendInstructionIntoCalledComputation(decomposition_root);
}

HloCallInstruction::HloCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* decomposition, const std::string& name,
    const std::string& attributes, int64_t version)
    : HloCallableInstruction(HloOpcode::kCall, shape, operands, decomposition,
                             name, attributes, version) {
  FrontendAttributes frontend_attributes;
  frontend_attributes.mutable_map()->insert({"composite.name", name});
  frontend_attributes.mutable_map()->insert(
      {"composite.attributes", attributes});
  frontend_attributes.mutable_map()->insert(
      {"composite.version", std::to_string(version)});

  add_frontend_attributes(frontend_attributes);
  set_is_composite(true);
}

HloRngInstruction::HloRngInstruction(
    const Shape& shape, RandomDistribution distribution,
    absl::Span<HloInstruction* const> parameters)
    : HloInstruction(HloOpcode::kRng, shape), distribution_(distribution) {
  for (HloInstruction* param : parameters) {
    AppendOperand(param);
  }
}

void HloRngInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_distribution(distribution_);
}

void HloRngInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer,
              "distribution=", RandomDistributionToString(distribution_));
  });
}

bool HloRngInstruction::IsElementwiseImpl(
    const std::optional<int64_t>& operand_idx) const {
  return true;
}

bool HloRngInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloRngInstruction&>(other);
  return distribution_ == casted_other.distribution_;
}

std::unique_ptr<HloInstruction> HloRngInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloRngInstruction>(shape, distribution_,
                                             new_operands);
}

HloParameterInstruction::HloParameterInstruction(int64_t parameter_number,
                                                 const Shape& shape,
                                                 absl::string_view name)
    : HloInstruction(HloOpcode::kParameter, shape),
      parameter_number_(parameter_number) {
  SetAndSanitizeName(name);
}

void HloParameterInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_parameter_number(parameter_number_);
  if (parameter_replicated_at_leaf_buffers_) {
    for (bool replicated : *parameter_replicated_at_leaf_buffers_) {
      proto->mutable_parameter_replication()->add_replicated_at_leaf_buffers(
          replicated);
    }
  }
}

void HloParameterInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!parameter_replicated_at_leaf_buffers_ || !options.print_ids()) {
    return;
  }
  printer.Next([this](Printer* printer) {
    printer->Append("parameter_replication={");
    AppendJoin(printer, *parameter_replicated_at_leaf_buffers_, ",",
               [](Printer* printer, bool replicated) {
                 printer->Append(replicated ? "true" : "false");
               });
    printer->Append("}");
  });
}

void HloParameterInstruction::PrintOperandsWithCanonicalNameMap(
    Printer* printer, const HloPrintOptions& options,
    CanonicalNameMap* canonical_name_map) const {
  if (options.print_parameter_number()) {
    printer->Append(parameter_number_);
  }
}

bool HloParameterInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloParameterInstruction&>(other);
  return parameter_number() == casted_other.parameter_number();
}

std::unique_ptr<HloInstruction>
HloParameterInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  auto clone = std::make_unique<HloParameterInstruction>(parameter_number_,
                                                         shape, name());
  if (parameter_replicated_at_leaf_buffers_ &&
      ShapeUtil::Equal(shape, this->shape())) {
    clone->set_parameter_replicated_at_leaf_buffers(
        *parameter_replicated_at_leaf_buffers_);
  }
  return clone;
}

HloGetTupleElementInstruction::HloGetTupleElementInstruction(
    const Shape& shape, HloInstruction* operand, int64_t index)
    : HloInstruction(HloOpcode::kGetTupleElement, shape), tuple_index_(index) {
  AppendOperand(operand);
}

void HloGetTupleElementInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_tuple_index(tuple_index_);
}

void HloGetTupleElementInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "index=", tuple_index());
  });
}

bool HloGetTupleElementInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloGetTupleElementInstruction&>(other);
  return tuple_index() == casted_other.tuple_index();
}

std::unique_ptr<HloInstruction>
HloGetTupleElementInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloGetTupleElementInstruction>(shape, new_operands[0],
                                                         tuple_index());
}

HloReducePrecisionInstruction::HloReducePrecisionInstruction(
    const Shape& shape, HloInstruction* operand, const int exponent_bits,
    const int mantissa_bits)
    : HloInstruction(HloOpcode::kReducePrecision, shape),
      exponent_bits_(exponent_bits),
      mantissa_bits_(mantissa_bits) {
  AppendOperand(operand);
}

void HloReducePrecisionInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_exponent_bits(exponent_bits_);
  proto->set_mantissa_bits(mantissa_bits_);
}

void HloReducePrecisionInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "exponent_bits=", exponent_bits_);
  });
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "mantissa_bits=", mantissa_bits_);
  });
}

bool HloReducePrecisionInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloReducePrecisionInstruction&>(other);
  // A reduce-precision operation is determined by the bit sizes.
  return exponent_bits() == casted_other.exponent_bits() &&
         mantissa_bits() == casted_other.mantissa_bits();
}

std::unique_ptr<HloInstruction>
HloReducePrecisionInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloReducePrecisionInstruction>(
      shape, new_operands[0], exponent_bits(), mantissa_bits());
}

HloInfeedInstruction::HloInfeedInstruction(const Shape& infeed_shape,
                                           HloInstruction* token_operand,
                                           const std::string& config)
    : HloInstruction(HloOpcode::kInfeed,
                     ShapeUtil::MakeTupleShape(
                         {infeed_shape, ShapeUtil::MakeTokenShape()})),
      infeed_config_(config) {
  AppendOperand(token_operand);
}

void HloInfeedInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_infeed_config(infeed_config_);
}

void HloInfeedInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!options.print_infeed_outfeed_config() || infeed_config_.empty()) {
    return;
  }
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "infeed_config=\"", CEscape(infeed_config_), "\"");
  });
}

bool HloInfeedInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  return ShapeUtil::Equal(shape(), other.shape()) &&
         infeed_config() == other.infeed_config();
}

std::unique_ptr<HloInstruction> HloInfeedInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloInfeedInstruction>(infeed_shape(), new_operands[0],
                                                infeed_config());
}

HloOutfeedInstruction::HloOutfeedInstruction(const Shape& outfeed_shape,
                                             HloInstruction* operand,
                                             HloInstruction* token_operand,
                                             absl::string_view outfeed_config)
    : HloInstruction(HloOpcode::kOutfeed, ShapeUtil::MakeTokenShape()),
      outfeed_shape_(outfeed_shape),
      outfeed_config_(outfeed_config) {
  AppendOperand(operand);
  AppendOperand(token_operand);
}

void HloOutfeedInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_outfeed_config(outfeed_config());
  outfeed_shape().ToProto(*proto->mutable_outfeed_shape());
}

void HloOutfeedInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append("outfeed_shape=");
    ShapeUtil::PrintHumanStringWithLayout(printer, outfeed_shape_);
  });
  if (options.print_infeed_outfeed_config() && !outfeed_config_.empty()) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "outfeed_config=\"", CEscape(outfeed_config_), "\"");
    });
  }
}

bool HloOutfeedInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  return ShapeUtil::Equal(outfeed_shape(), other.outfeed_shape()) &&
         outfeed_config() == other.outfeed_config();
}

std::unique_ptr<HloInstruction> HloOutfeedInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 2);
  return std::make_unique<HloOutfeedInstruction>(
      outfeed_shape(), new_operands[0], new_operands[1], outfeed_config());
}

HloConvolutionInstruction::HloConvolutionInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    int64_t feature_group_count, int64_t batch_group_count,
    const Window& window, const ConvolutionDimensionNumbers& dimension_numbers,
    const PrecisionConfig& precision_config,
    const SparsityConfig& sparsity_config,
    const BlockScalingConfig& block_scaling_config,
    ConvolutionKind convolution_kind)
    : HloInstruction(HloOpcode::kConvolution, shape),
      feature_group_count_(feature_group_count),
      batch_group_count_(batch_group_count),
      window_(window),
      convolution_dimension_numbers_(dimension_numbers),
      precision_config_(precision_config),
      sparsity_config_(sparsity_config),
      block_scaling_config_(block_scaling_config),
      convolution_kind_(convolution_kind) {
  if (window_util::HasBaseDilation(window)) {
    SetAndSanitizeName(StrCat(name(), "-base-dilated"));
  }
  if (window_util::HasWindowDilation(window)) {
    SetAndSanitizeName(StrCat(name(), "-window-dilated"));
  }
  for (HloInstruction* operand : operands) {
    AppendOperand(operand);
  }
}

std::string HloConvolutionInstruction::ToCategory() const {
  std::string category = "convolution";
  if (window_util::HasBaseDilation(window())) {
    absl::StrAppend(&category, " base-dilated");
  }
  if (window_util::HasWindowDilation(window())) {
    absl::StrAppend(&category, " window-dilated");
  }
  return category;
}

void HloConvolutionInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_window() = window_;
  *proto->mutable_convolution_dimension_numbers() =
      convolution_dimension_numbers_;
  proto->set_feature_group_count(feature_group_count_);
  proto->set_batch_group_count(batch_group_count_);
  *proto->mutable_precision_config() = precision_config_;
  if (convolution_kind_ != CONVOLUTION_KIND_UNSET) {
    proto->set_conv_kind(convolution_kind_);
  }
  *proto->mutable_sparsity_config() = sparsity_config_;
  *proto->mutable_block_scaling_config() = block_scaling_config_;
}

void HloConvolutionInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!window_.dimensions().empty()) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "window={", window_util::ToString(window()), "}");
    });
  }
  printer.Next([this](Printer* printer) {
    AppendCat(
        printer, "dim_labels=",
        ConvolutionDimensionNumbersToString(convolution_dimension_numbers_));
  });
  if (feature_group_count_ != 1) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "feature_group_count=", feature_group_count_);
    });
  }

  if (batch_group_count_ != 1) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "batch_group_count=", batch_group_count_);
    });
  }

  if (convolution_kind_ != CONVOLUTION_KIND_UNSET) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "convolution_kind=",
                ConvolutionKindToString(convolution_kind_));
    });
  }
  PrintPrecisionConfig(printer, precision_config_);
  if (sparsity_config_.has_lhs() || sparsity_config_.has_rhs()) {
    printer.Next([this](Printer* printer) {
      printer->Append("sparsity_config={");
      printer->Append(SparsityConfigToString(sparsity_config_));
      printer->Append("}");
    });
  }
  if (block_scaling_config_.has_lhs() || block_scaling_config_.has_rhs()) {
    printer.Next([this](Printer* printer) {
      printer->Append("block_scaling_config={");
      printer->Append(BlockScalingConfigToString(block_scaling_config_));
      printer->Append("}");
    });
  }
}

bool HloConvolutionInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloConvolutionInstruction&>(other);
  if (feature_group_count_ != other.feature_group_count()) {
    return false;
  }
  if (batch_group_count_ != other.batch_group_count()) {
    return false;
  }
  if (convolution_kind_ != casted_other.convolution_kind_) {
    return false;
  }
  return protobuf_util::HaveSameSerialization(window(),
                                              casted_other.window()) &&
         protobuf_util::HaveSameSerialization(
             convolution_dimension_numbers(),
             casted_other.convolution_dimension_numbers()) &&
         protobuf_util::HaveSameSerialization(
             precision_config(), casted_other.precision_config()) &&
         protobuf_util::HaveSameSerialization(sparsity_config(),
                                              casted_other.sparsity_config()) &&
         protobuf_util::HaveSameSerialization(
             block_scaling_config(), casted_other.block_scaling_config());
}

std::unique_ptr<HloInstruction>
HloConvolutionInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloConvolutionInstruction>(
      shape, new_operands, feature_group_count_, batch_group_count_, window(),
      convolution_dimension_numbers_, precision_config_, sparsity_config_,
      block_scaling_config_, convolution_kind_);
}

HloReduceWindowInstruction::HloReduceWindowInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* init_value,
    const Window& window, HloComputation* reduce_computation)
    : HloReduceWindowInstruction(shape, absl::MakeSpan(&operand, 1),
                                 absl::MakeSpan(&init_value, 1), window,
                                 reduce_computation) {}

HloReduceWindowInstruction::HloReduceWindowInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    absl::Span<HloInstruction* const> init_values, const Window& window,
    HloComputation* reduce_computation)
    : HloInstruction(HloOpcode::kReduceWindow, shape), window_(window) {
  for (auto* operand : operands) {
    AppendOperand(operand);
  }
  for (auto* init_value : init_values) {
    AppendOperand(init_value);
  }
  AppendComputation(reduce_computation);
}

void HloReduceWindowInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_window() = window_;
}

void HloReduceWindowInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!window_.dimensions().empty()) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "window={", window_util::ToString(window()), "}");
    });
  }
}

bool HloReduceWindowInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloReduceWindowInstruction&>(other);
  return eq_computations(to_apply(), casted_other.to_apply()) &&
         protobuf_util::HaveSameSerialization(window(), casted_other.window());
}

std::unique_ptr<HloInstruction>
HloReduceWindowInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size() % 2, 0);
  int64_t num_operands = new_operands.size() / 2;
  return std::make_unique<HloReduceWindowInstruction>(
      shape, absl::MakeSpan(new_operands).subspan(0, num_operands),
      absl::MakeSpan(new_operands)
          .subspan(num_operands, new_operands.size() / 2),
      window(), to_apply());
}

HloSelectAndScatterInstruction::HloSelectAndScatterInstruction(
    const Shape& shape, HloInstruction* operand, HloComputation* select,
    const Window& window, HloInstruction* source, HloInstruction* init_value,
    HloComputation* scatter)
    : HloInstruction(HloOpcode::kSelectAndScatter, shape), window_(window) {
  AppendOperand(operand);
  AppendOperand(source);
  AppendOperand(init_value);
  // Select comes before scatter in the vector.
  AppendComputation(select);
  AppendComputation(scatter);
}

void HloSelectAndScatterInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_window() = window_;
}

void HloSelectAndScatterInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (!window_.dimensions().empty()) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "window={", window_util::ToString(window()), "}");
    });
  }
}

bool HloSelectAndScatterInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloSelectAndScatterInstruction&>(other);
  return eq_computations(select(), casted_other.select()) &&
         eq_computations(scatter(), casted_other.scatter()) &&
         protobuf_util::HaveSameSerialization(window(), casted_other.window());
}

std::unique_ptr<HloInstruction>
HloSelectAndScatterInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 3);
  return std::make_unique<HloSelectAndScatterInstruction>(
      shape, new_operands[0], select(), window(), new_operands[1],
      new_operands[2], scatter());
}

HloCustomCallInstruction::HloCustomCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    absl::string_view custom_call_target, std::string opaque,
    CustomCallApiVersion api_version)
    : HloCallableInstruction(HloOpcode::kCustomCall, shape, operands),
      custom_call_target_(custom_call_target),
      feature_group_count_(1),
      batch_group_count_(1),
      layout_constrained_(false),
      padding_type_(PaddingType::PADDING_INVALID),
      custom_call_has_side_effect_(false),
      custom_call_schedule_(CustomCallSchedule::SCHEDULE_NONE),
      api_version_(api_version) {
  set_raw_backend_config_string(std::move(opaque));
}

HloCustomCallInstruction::HloCustomCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* to_apply, absl::string_view custom_call_target,
    std::string opaque, CustomCallApiVersion api_version)
    : HloCallableInstruction(HloOpcode::kCustomCall, shape, operands, to_apply),
      custom_call_target_(custom_call_target),
      feature_group_count_(1),
      batch_group_count_(1),
      layout_constrained_(false),
      padding_type_(PaddingType::PADDING_INVALID),
      custom_call_has_side_effect_(false),
      custom_call_schedule_(CustomCallSchedule::SCHEDULE_NONE),
      api_version_(api_version) {
  set_raw_backend_config_string(std::move(opaque));
}

HloCustomCallInstruction::HloCustomCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    absl::Span<HloComputation* const> called_computations,
    absl::string_view custom_call_target, std::string opaque,
    CustomCallApiVersion api_version)
    : HloCallableInstruction(HloOpcode::kCustomCall, shape, operands,
                             called_computations),
      custom_call_target_(custom_call_target),
      feature_group_count_(1),
      batch_group_count_(1),
      layout_constrained_(false),
      padding_type_(PaddingType::PADDING_INVALID),
      custom_call_has_side_effect_(false),
      custom_call_schedule_(CustomCallSchedule::SCHEDULE_NONE),
      api_version_(api_version) {
  set_raw_backend_config_string(std::move(opaque));
}

HloCustomCallInstruction::HloCustomCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    absl::string_view custom_call_target, std::string opaque,
    absl::Span<const Shape> operand_shapes_with_layout,
    CustomCallApiVersion api_version)
    : HloCallableInstruction(HloOpcode::kCustomCall, shape, operands),
      custom_call_target_(custom_call_target),
      feature_group_count_(1),
      batch_group_count_(1),
      layout_constrained_(true),
      padding_type_(PaddingType::PADDING_INVALID),
      operand_shapes_with_layout_(operand_shapes_with_layout.begin(),
                                  operand_shapes_with_layout.end()),
      custom_call_has_side_effect_(false),
      custom_call_schedule_(CustomCallSchedule::SCHEDULE_NONE),
      api_version_(api_version) {
  set_raw_backend_config_string(std::move(opaque));
}

HloCustomCallInstruction::HloCustomCallInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    HloComputation* to_apply, absl::string_view custom_call_target,
    std::string opaque, absl::Span<const Shape> operand_shapes_with_layout,
    CustomCallApiVersion api_version)
    : HloCallableInstruction(HloOpcode::kCustomCall, shape, operands, to_apply),
      custom_call_target_(custom_call_target),
      feature_group_count_(1),
      batch_group_count_(1),
      layout_constrained_(true),
      padding_type_(PaddingType::PADDING_INVALID),
      operand_shapes_with_layout_(operand_shapes_with_layout.begin(),
                                  operand_shapes_with_layout.end()),
      custom_call_has_side_effect_(false),
      custom_call_schedule_(CustomCallSchedule::SCHEDULE_NONE),
      api_version_(api_version) {
  set_raw_backend_config_string(std::move(opaque));
}

void HloCustomCallInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  if (window_ != nullptr) {
    *proto->mutable_window() = *window_;
  }
  if (convolution_dimension_numbers_ != nullptr) {
    *proto->mutable_convolution_dimension_numbers() =
        *convolution_dimension_numbers_;
  }
  proto->set_custom_call_target(custom_call_target_);
  proto->set_feature_group_count(feature_group_count_);
  proto->set_batch_group_count(batch_group_count_);
  *proto->mutable_precision_config() = precision_config_;
  proto->set_padding_type(padding_type_);
  if (layout_constrained()) {
    proto->set_constrain_layout(true);
    for (const Shape& shape : operand_shapes_with_layout_) {
      shape.ToProto(*proto->add_operand_shapes_with_layout());
    }
  }
  proto->set_custom_call_has_side_effect(custom_call_has_side_effect_);
  if (literal_.has_value()) {
    *proto->mutable_literal() = literal_->ToProto();
  }
  for (const auto& pair : output_to_operand_aliasing()) {
    auto* aliasing = proto->add_output_operand_aliasing();
    aliasing->set_operand_index(pair.second.first);
    for (int64_t index : pair.first) {
      aliasing->add_output_shape_index(index);
    }
    for (int64_t index : pair.second.second) {
      aliasing->add_operand_shape_index(index);
    }
  }
  proto->set_custom_call_schedule(custom_call_schedule_);
  proto->set_custom_call_api_version(api_version_);
}

void HloCustomCallInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  if (window_ != nullptr) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "window={", window_util::ToString(*window_), "}");
    });
  }
  if (convolution_dimension_numbers_ != nullptr) {
    printer.Next([this](Printer* printer) {
      AppendCat(
          printer, "dim_labels=",
          ConvolutionDimensionNumbersToString(*convolution_dimension_numbers_));
    });
  }
  if (feature_group_count_ != 1) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "feature_group_count=", feature_group_count_);
    });
  }
  if (batch_group_count_ != 1) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "batch_group_count=", batch_group_count_);
    });
  }
  PrintPrecisionConfig(printer, precision_config_);
  if (padding_type_ != PaddingType::PADDING_INVALID) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer, "padding_type=", PaddingType_Name(padding_type()));
    });
  }
  // By contract, we print the custom call target even if
  // options.print_subcomputation_mode() == kOff, because the call target is
  // not an HloComputation.
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "custom_call_target=\"", CEscape(custom_call_target_),
              "\"");
  });

  if (layout_constrained()) {
    printer.Next([this](Printer* printer) {
      printer->Append("operand_layout_constraints={");
      if (!operand_shapes_with_layout_.empty()) {
        ShapeUtil::PrintHumanStringWithLayout(printer,
                                              operand_shapes_with_layout_[0]);
        for (const Shape& shape :
             absl::MakeSpan(operand_shapes_with_layout_).subspan(1)) {
          printer->Append(", ");
          ShapeUtil::PrintHumanStringWithLayout(printer, shape);
        }
      }
      printer->Append("}");
    });
  }
  if (custom_call_has_side_effect_) {
    printer.Next([](Printer* printer) {
      printer->Append("custom_call_has_side_effect=true");
    });
  }
  if (literal_.has_value()) {
    printer.Next([this](Printer* printer) {
      printer->Append("literal=");
      literal_->PrintWithLayoutOneline(printer);
    });
  }
  if (!output_to_operand_aliasing().empty()) {
    printer.Next([this](Printer* printer) {
      printer->Append("output_to_operand_aliasing={");
      AppendJoin(printer, output_to_operand_aliasing(), ", ",
                 [](Printer* printer, auto& pair) {
                   AppendCat(printer, pair.first.ToString(), ": (",
                             pair.second.first, ", ");
                   AppendCat(printer, pair.second.second.ToString(), ")");
                 });
      printer->Append("}");
    });
  }
  if (custom_call_schedule_ != CustomCallSchedule::SCHEDULE_NONE) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer,
                "schedule=", CustomCallSchedule_Name(custom_call_schedule_));
    });
  }
  if (api_version_ != CustomCallApiVersion::API_VERSION_ORIGINAL) {
    printer.Next([this](Printer* printer) {
      AppendCat(printer,
                "api_version=", CustomCallApiVersion_Name(api_version_));
    });
  }
}

bool HloCustomCallInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloCustomCallInstruction&>(other);
  if ((window_ == nullptr) != (casted_other.window_ == nullptr) ||
      (window_ != nullptr && !protobuf_util::HaveSameSerialization(
                                 *window_, *casted_other.window_))) {
    return false;
  }
  if ((convolution_dimension_numbers_ == nullptr) !=
          (casted_other.convolution_dimension_numbers_ == nullptr) ||
      (convolution_dimension_numbers_ != nullptr &&
       !protobuf_util::HaveSameSerialization(
           convolution_dimension_numbers(),
           casted_other.convolution_dimension_numbers()))) {
    return false;
  }
  if (feature_group_count_ != casted_other.feature_group_count_) {
    return false;
  }
  if (batch_group_count_ != casted_other.batch_group_count_) {
    return false;
  }

  if (padding_type_ != casted_other.padding_type()) {
    return false;
  }

  if (layout_constrained() != casted_other.layout_constrained()) {
    return false;
  }
  if (layout_constrained()) {
    for (int64_t i = 0; i < operand_shapes_with_layout_.size(); ++i) {
      if (!ShapeUtil::Equal(operand_shapes_with_layout_[i],
                            casted_other.operand_shapes_with_layout_[i])) {
        return false;
      }
    }
  }
  if (custom_call_has_side_effect_ !=
      casted_other.custom_call_has_side_effect()) {
    return false;
  }
  if (output_to_operand_aliasing() !=
      casted_other.output_to_operand_aliasing()) {
    return false;
  }
  if (!protobuf_util::HaveSameSerialization(precision_config(),
                                            casted_other.precision_config())) {
    return false;
  }

  if (!absl::c_equal(called_computations(), other.called_computations(),
                     eq_computations)) {
    return false;
  }
  if (custom_call_schedule_ != casted_other.custom_call_schedule()) {
    return false;
  }
  if (HasLiteral() != casted_other.HasLiteral()) {
    return false;
  }
  if (HasLiteral() && literal() != casted_other.literal()) {
    return false;
  }
  if (api_version_ != casted_other.api_version_) {
    return false;
  }
  // Note: backend_config comparison is done in Identical, which is the
  // intended/exposed way to compare computations, and so not repeated here.
  return custom_call_target_ == casted_other.custom_call_target_;
}

std::unique_ptr<HloInstruction>
HloCustomCallInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  absl::InlinedVector<HloComputation*, 1> new_called_computations =
      GetOrCloneCalledComputations(context);

  auto cloned = std::make_unique<HloCustomCallInstruction>(
      shape, new_operands, new_called_computations, custom_call_target(),
      opaque(), api_version_);
  if (layout_constrained()) {
    cloned->layout_constrained_ = true;
    cloned->operand_shapes_with_layout_ = operand_shapes_with_layout();
  }
  if (window_ != nullptr) {
    cloned->set_window(*window_);
  }
  if (convolution_dimension_numbers_ != nullptr) {
    cloned->set_convolution_dimension_numbers(*convolution_dimension_numbers_);
  }
  if (HasLiteral()) {
    cloned->set_literal(literal().Clone());
  }
  cloned->set_feature_group_count(feature_group_count_);
  cloned->set_batch_group_count(batch_group_count_);
  cloned->set_custom_call_has_side_effect(custom_call_has_side_effect_);
  cloned->set_output_to_operand_aliasing(output_to_operand_aliasing());
  cloned->set_padding_type(padding_type_);
  *cloned->mutable_precision_config() = precision_config();
  cloned->set_custom_call_schedule(custom_call_schedule_);
  return cloned;
}

HloPadInstruction::HloPadInstruction(const Shape& shape,
                                     HloInstruction* operand,
                                     HloInstruction* padding_value,
                                     const PaddingConfig& padding_config)
    : HloInstruction(HloOpcode::kPad, shape), padding_config_(padding_config) {
  AppendOperand(operand);
  AppendOperand(padding_value);
}

void HloPadInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_padding_config() = padding_config_;
}

void HloPadInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "padding=", xla::PaddingConfigToString(padding_config_));
  });
}

bool HloPadInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloPadInstruction&>(other);
  return protobuf_util::HaveSameSerialization(padding_config(),
                                              casted_other.padding_config());
}

std::unique_ptr<HloInstruction> HloPadInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 2);
  return std::make_unique<HloPadInstruction>(shape, new_operands[0],
                                             new_operands[1], padding_config_);
}

HloDynamicSliceInstruction::HloDynamicSliceInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* start_indices,
    absl::Span<const int64_t> slice_sizes)
    : HloDynamicIndexInstruction(HloOpcode::kDynamicSlice, shape),
      dynamic_slice_sizes_(slice_sizes.begin(), slice_sizes.end()) {
  AppendOperand(operand);
  AppendOperand(start_indices);
}

HloDynamicSliceInstruction::HloDynamicSliceInstruction(
    const Shape& shape, HloInstruction* operand,
    absl::Span<HloInstruction* const> start_indices,
    absl::Span<const int64_t> slice_sizes)
    : HloDynamicIndexInstruction(HloOpcode::kDynamicSlice, shape),
      dynamic_slice_sizes_(slice_sizes.begin(), slice_sizes.end()) {
  AppendOperand(operand);
  for (HloInstruction* index : start_indices) {
    AppendOperand(index);
  }
}

HloDynamicUpdateSliceInstruction::HloDynamicUpdateSliceInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* update,
    HloInstruction* start_indices)
    : HloDynamicIndexInstruction(HloOpcode::kDynamicUpdateSlice, shape) {
  AppendOperand(operand);
  AppendOperand(update);
  AppendOperand(start_indices);
}

HloDynamicUpdateSliceInstruction::HloDynamicUpdateSliceInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* update,
    absl::Span<HloInstruction* const> start_indices)
    : HloDynamicIndexInstruction(HloOpcode::kDynamicUpdateSlice, shape) {
  AppendOperand(operand);
  AppendOperand(update);
  for (HloInstruction* index : start_indices) {
    AppendOperand(index);
  }
}

void HloDynamicSliceInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  for (int64_t slice_size : dynamic_slice_sizes_) {
    proto->add_dynamic_slice_sizes(slice_size);
  }
}

void HloDynamicSliceInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append("dynamic_slice_sizes={");
    AppendJoin(printer, dynamic_slice_sizes(), ",");
    printer->Append("}");
  });
}

bool HloDynamicSliceInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloMapInstruction&>(other);
  return dynamic_slice_sizes() == casted_other.dynamic_slice_sizes();
}

std::unique_ptr<HloInstruction>
HloDynamicSliceInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  if (new_operands.size() == 2 &&
      new_operands[1]->shape().dimensions().size() == 1) {
    // TODO(b/118437727): Old form, remove this path.
    return std::make_unique<HloDynamicSliceInstruction>(
        shape, new_operands[0], new_operands[1], dynamic_slice_sizes_);
  }
  return std::make_unique<HloDynamicSliceInstruction>(
      shape, new_operands[0], new_operands.subspan(1), dynamic_slice_sizes_);
}

HloGatherInstruction::HloGatherInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* start_indices,
    const GatherDimensionNumbers& gather_dim_numbers,
    absl::Span<const int64_t> slice_sizes, bool indices_are_sorted)
    : HloInstruction(HloOpcode::kGather, shape),
      gather_dimension_numbers_(
          std::make_unique<GatherDimensionNumbers>(gather_dim_numbers)),
      gather_slice_sizes_(slice_sizes.begin(), slice_sizes.end()),
      indices_are_sorted_(indices_are_sorted) {
  AppendOperand(operand);
  AppendOperand(start_indices);
}

/*static*/ std::string HloGatherInstruction::GatherDimensionNumbersToString(
    const GatherDimensionNumbers& dim_numbers) {
  StringPrinter printer;
  PrintGatherDimensionNumbers(&printer, dim_numbers);
  return std::move(printer).ToString();
}

/*static*/ void HloGatherInstruction::PrintGatherDimensionNumbers(
    Printer* printer, const GatherDimensionNumbers& dim_numbers) {
  printer->Append("offset_dims={");
  AppendJoin(printer, dim_numbers.offset_dims(), ",");
  printer->Append("}, collapsed_slice_dims={");
  AppendJoin(printer, dim_numbers.collapsed_slice_dims(), ",");
  printer->Append("}, start_index_map={");
  AppendJoin(printer, dim_numbers.start_index_map(), ",");
  if (dim_numbers.operand_batching_dims_size()) {
    printer->Append("}, operand_batching_dims={");
    AppendJoin(printer, dim_numbers.operand_batching_dims(), ",");
  }
  if (dim_numbers.start_indices_batching_dims_size()) {
    printer->Append("}, start_indices_batching_dims={");
    AppendJoin(printer, dim_numbers.start_indices_batching_dims(), ",");
  }
  AppendCat(printer, "}, index_vector_dim=", dim_numbers.index_vector_dim());
}

/* static */ GatherDimensionNumbers HloGatherInstruction::MakeGatherDimNumbers(
    absl::Span<const int64_t> offset_dims,
    absl::Span<const int64_t> collapsed_slice_dims,
    absl::Span<const int64_t> start_index_map, int64_t index_vector_dim,
    absl::Span<const int64_t> operand_batching_dims,
    absl::Span<const int64_t> start_indices_batching_dims) {
  GatherDimensionNumbers gather_dim_numbers;
  for (int64_t output_window_dim : offset_dims) {
    gather_dim_numbers.add_offset_dims(output_window_dim);
  }
  for (int64_t elided_window_dim : collapsed_slice_dims) {
    gather_dim_numbers.add_collapsed_slice_dims(elided_window_dim);
  }
  for (int64_t gather_dim_to_input_dim : start_index_map) {
    gather_dim_numbers.add_start_index_map(gather_dim_to_input_dim);
  }
  for (int64_t operand_batching_dim : operand_batching_dims) {
    gather_dim_numbers.add_operand_batching_dims(operand_batching_dim);
  }
  for (int64_t start_indices_batching_dim : start_indices_batching_dims) {
    gather_dim_numbers.add_start_indices_batching_dims(
        start_indices_batching_dim);
  }

  gather_dim_numbers.set_index_vector_dim(index_vector_dim);
  return gather_dim_numbers;
}

void HloGatherInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_gather_dimension_numbers() = gather_dimension_numbers();
  for (int64_t bound : gather_slice_sizes()) {
    proto->add_gather_slice_sizes(bound);
  }
  proto->set_indices_are_sorted(indices_are_sorted());
}

void HloGatherInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    PrintGatherDimensionNumbers(printer, gather_dimension_numbers());
  });
  printer.Next([this](Printer* printer) {
    printer->Append("slice_sizes={");
    AppendJoin(printer, gather_slice_sizes(), ",");
    printer->Append("}");
  });
  if (indices_are_sorted()) {
    printer.Next(
        [](Printer* printer) { printer->Append("indices_are_sorted=true"); });
  }
}

bool HloGatherInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloGatherInstruction&>(other);
  return protobuf_util::HaveSameSerialization(
             gather_dimension_numbers(),
             casted_other.gather_dimension_numbers()) &&
         gather_slice_sizes() == casted_other.gather_slice_sizes() &&
         indices_are_sorted() == casted_other.indices_are_sorted();
}

std::unique_ptr<HloInstruction> HloGatherInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), 2);
  return std::make_unique<HloGatherInstruction>(
      shape, new_operands[0], new_operands[1], gather_dimension_numbers(),
      gather_slice_sizes(), indices_are_sorted());
}

HloScatterInstruction::HloScatterInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> args,
    HloComputation* update_computation,
    const ScatterDimensionNumbers& scatter_dim_numbers, bool indices_are_sorted,
    bool unique_indices)
    : HloInstruction(HloOpcode::kScatter, shape),
      scatter_dimension_numbers_(
          std::make_unique<ScatterDimensionNumbers>(scatter_dim_numbers)),
      indices_are_sorted_(indices_are_sorted),
      unique_indices_(unique_indices) {
  mutable_operands().reserve(args.size());
  for (HloInstruction* arg : args) {
    AppendOperand(arg);
  }
  AppendComputation(update_computation);
}

/*static*/ std::string HloScatterInstruction::ScatterDimensionNumbersToString(
    const ScatterDimensionNumbers& dim_numbers) {
  StringPrinter printer;
  PrintScatterDimensionNumbers(&printer, dim_numbers);
  return std::move(printer).ToString();
}

/*static*/ void HloScatterInstruction::PrintScatterDimensionNumbers(
    Printer* printer, const ScatterDimensionNumbers& dim_numbers) {
  printer->Append("update_window_dims={");
  AppendJoin(printer, dim_numbers.update_window_dims(), ",");
  printer->Append("}, inserted_window_dims={");
  AppendJoin(printer, dim_numbers.inserted_window_dims(), ",");
  printer->Append("}, scatter_dims_to_operand_dims={");
  AppendJoin(printer, dim_numbers.scatter_dims_to_operand_dims(), ",");
  if (dim_numbers.input_batching_dims_size()) {
    printer->Append("}, input_batching_dims={");
    AppendJoin(printer, dim_numbers.input_batching_dims(), ",");
  }
  if (dim_numbers.scatter_indices_batching_dims_size()) {
    printer->Append("}, scatter_indices_batching_dims={");
    AppendJoin(printer, dim_numbers.scatter_indices_batching_dims(), ",");
  }
  AppendCat(printer, "}, index_vector_dim=", dim_numbers.index_vector_dim());
}

/* static */ ScatterDimensionNumbers
HloScatterInstruction::MakeScatterDimNumbers(
    absl::Span<const int64_t> update_window_dims,
    absl::Span<const int64_t> inserted_window_dims,
    absl::Span<const int64_t> scatter_dims_to_operand_dims,
    int64_t index_vector_dim, absl::Span<const int64_t> input_batching_dims,
    absl::Span<const int64_t> scatter_indices_batching_dims) {
  ScatterDimensionNumbers scatter_dim_numbers;
  for (int64_t update_window_dim : update_window_dims) {
    scatter_dim_numbers.add_update_window_dims(update_window_dim);
  }
  for (int64_t inserted_window_dim : inserted_window_dims) {
    scatter_dim_numbers.add_inserted_window_dims(inserted_window_dim);
  }
  for (int64_t scatter_dim_to_operand_dim : scatter_dims_to_operand_dims) {
    scatter_dim_numbers.add_scatter_dims_to_operand_dims(
        scatter_dim_to_operand_dim);
  }
  for (int64_t input_batching_dim : input_batching_dims) {
    scatter_dim_numbers.add_input_batching_dims(input_batching_dim);
  }
  for (int64_t scatter_indices_batching_dim : scatter_indices_batching_dims) {
    scatter_dim_numbers.add_scatter_indices_batching_dims(
        scatter_indices_batching_dim);
  }
  scatter_dim_numbers.set_index_vector_dim(index_vector_dim);
  return scatter_dim_numbers;
}

void HloScatterInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_scatter_dimension_numbers() = scatter_dimension_numbers();
  proto->set_indices_are_sorted(indices_are_sorted());
  proto->set_unique_indices(unique_indices());
}

void HloScatterInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append(
        ScatterDimensionNumbersToString(scatter_dimension_numbers()));
  });
  if (indices_are_sorted()) {
    printer.Next(
        [](Printer* printer) { printer->Append("indices_are_sorted=true"); });
  }
  if (unique_indices()) {
    printer.Next(
        [](Printer* printer) { printer->Append("unique_indices=true"); });
  }
}

bool HloScatterInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloScatterInstruction&>(other);
  return protobuf_util::HaveSameSerialization(
             scatter_dimension_numbers(),
             casted_other.scatter_dimension_numbers()) &&
         eq_computations(to_apply(), casted_other.to_apply()) &&
         indices_are_sorted() == casted_other.indices_are_sorted() &&
         unique_indices() == casted_other.unique_indices();
}

std::unique_ptr<HloInstruction> HloScatterInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloScatterInstruction>(
      shape, new_operands, to_apply(), scatter_dimension_numbers(),
      indices_are_sorted(), unique_indices());
}

HloIotaInstruction::HloIotaInstruction(const Shape& shape,
                                       int64_t iota_dimension)
    : HloInstruction(HloOpcode::kIota, shape),
      iota_dimension_(iota_dimension) {}

void HloIotaInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->add_dimensions(iota_dimension());
}

void HloIotaInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "iota_dimension=", iota_dimension());
  });
}

bool HloIotaInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloIotaInstruction&>(other);
  return iota_dimension() == casted_other.iota_dimension();
}

std::unique_ptr<HloInstruction> HloIotaInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  return std::make_unique<HloIotaInstruction>(shape, iota_dimension());
}

HloDotInstruction::HloDotInstruction(
    const Shape& shape, HloInstruction* lhs, HloInstruction* rhs,
    const DotDimensionNumbers& dimension_numbers,
    const PrecisionConfig& precision_config)
    : HloDotInstruction(shape, {lhs, rhs}, dimension_numbers, precision_config,
                        SparsityConfig(), BlockScalingConfig()) {}

HloDotInstruction::HloDotInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    const DotDimensionNumbers& dimension_numbers,
    const PrecisionConfig& precision_config,
    const SparsityConfig& sparsity_config,
    const BlockScalingConfig& block_scaling_config)
    : HloInstruction(HloOpcode::kDot, shape),
      dot_dimension_numbers_(dimension_numbers),
      precision_config_(precision_config),
      sparsity_config_(sparsity_config),
      block_scaling_config_(block_scaling_config) {
  CHECK_GE(operands.size(), 2);
  AppendOperands(operands);
}

void HloDotInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_dot_dimension_numbers() = dot_dimension_numbers_;
  *proto->mutable_precision_config() = precision_config_;
  *proto->mutable_sparsity_config() = sparsity_config_;
  *proto->mutable_block_scaling_config() = block_scaling_config_;
}

void HloDotInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append(DotDimensionNumbersToString(dot_dimension_numbers_));
  });
  PrintPrecisionConfig(printer, precision_config_);
  auto print_config = [&printer](absl::string_view name,
                                 const std::string& config) {
    printer.Next(
        [&](Printer* p) { p->Append(absl::StrCat(name, "={", config, "}")); });
  };
  if (sparsity_config_.has_lhs() || sparsity_config_.has_rhs()) {
    print_config("sparsity_config", SparsityConfigToString(sparsity_config_));
  }
  if (block_scaling_config_.has_lhs() || block_scaling_config_.has_rhs()) {
    print_config("block_scaling_config",
                 BlockScalingConfigToString(block_scaling_config_));
  }
}

bool HloDotInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloDotInstruction&>(other);
  return protobuf_util::HaveSameSerialization(
             dot_dimension_numbers(), casted_other.dot_dimension_numbers()) &&
         protobuf_util::HaveSameSerialization(
             precision_config(), casted_other.precision_config()) &&
         protobuf_util::HaveSameSerialization(sparsity_config(),
                                              casted_other.sparsity_config()) &&
         protobuf_util::HaveSameSerialization(
             block_scaling_config(), casted_other.block_scaling_config());
}

std::unique_ptr<HloInstruction> HloDotInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_GE(new_operands.size(), 2);
  return std::make_unique<HloDotInstruction>(
      shape, new_operands, dot_dimension_numbers_, precision_config_,
      sparsity_config_, block_scaling_config_);
}

HloDotGeneralInstruction::HloDotGeneralInstruction(
    const Shape& shape, absl::Span<HloInstruction* const> operands,
    const DotDimensionNumbers& dimension_numbers,
    const PrecisionConfig& precision_config,
    const SparsityConfig& sparsity_config,
    const BlockScalingConfig& block_scaling_config)
    : HloInstruction(HloOpcode::kDotGeneral, shape),
      dot_dimension_numbers_(dimension_numbers),
      precision_config_(precision_config),
      sparsity_config_(sparsity_config),
      block_scaling_config_(block_scaling_config) {
  CHECK_GE(operands.size(), 2);
  AppendOperands(operands);
}

void HloDotGeneralInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_dot_dimension_numbers() = dot_dimension_numbers_;
  *proto->mutable_precision_config() = precision_config_;
  *proto->mutable_sparsity_config() = sparsity_config_;
  *proto->mutable_block_scaling_config() = block_scaling_config_;
}

void HloDotGeneralInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append(DotDimensionNumbersToString(dot_dimension_numbers_));
  });
  PrintPrecisionConfig(printer, precision_config_);
  if (sparsity_config_.has_lhs() || sparsity_config_.has_rhs()) {
    printer.Next([this](Printer* printer) {
      printer->Append(absl::StrCat(
          "sparsity_config={", SparsityConfigToString(sparsity_config_), "}"));
    });
  }
  if (block_scaling_config_.has_lhs() || block_scaling_config_.has_rhs()) {
    printer.Next([this](Printer* printer) {
      printer->Append(
          absl::StrCat("block_scaling_config={",
                       BlockScalingConfigToString(block_scaling_config_), "}"));
    });
  }
}

bool HloDotGeneralInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloDotGeneralInstruction&>(other);
  return protobuf_util::HaveSameSerialization(
             dot_dimension_numbers(), casted_other.dot_dimension_numbers()) &&
         protobuf_util::HaveSameSerialization(
             precision_config(), casted_other.precision_config()) &&
         protobuf_util::HaveSameSerialization(sparsity_config(),
                                              casted_other.sparsity_config()) &&
         protobuf_util::HaveSameSerialization(
             block_scaling_config(), casted_other.block_scaling_config());
}

std::unique_ptr<HloInstruction>
HloDotGeneralInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_GE(new_operands.size(), 2);
  return std::make_unique<HloDotGeneralInstruction>(
      shape, new_operands, dot_dimension_numbers_, precision_config_,
      sparsity_config_, block_scaling_config_);
}

HloRaggedDotInstruction::HloRaggedDotInstruction(
    const Shape& shape, HloInstruction* lhs, HloInstruction* rhs,
    HloInstruction* group_sizes,
    const RaggedDotDimensionNumbers& dimension_numbers,
    const PrecisionConfig& precision_config)
    : HloInstruction(HloOpcode::kRaggedDot, shape),
      ragged_dot_dimension_numbers_(dimension_numbers),
      precision_config_(precision_config) {
  AppendOperand(lhs);
  AppendOperand(rhs);
  AppendOperand(group_sizes);
}

void HloRaggedDotInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_ragged_dot_dimension_numbers() =
      ragged_dot_dimension_numbers_;
  *proto->mutable_precision_config() = precision_config_;
}

void HloRaggedDotInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append(
        RaggedDotDimensionNumbersToString(ragged_dot_dimension_numbers_));
  });
  PrintPrecisionConfig(printer, precision_config_);
}

bool HloRaggedDotInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloRaggedDotInstruction&>(other);
  return protobuf_util::HaveSameSerialization(
             ragged_dot_dimension_numbers(),
             casted_other.ragged_dot_dimension_numbers()) &&
         protobuf_util::HaveSameSerialization(precision_config(),
                                              casted_other.precision_config());
}

std::unique_ptr<HloInstruction>
HloRaggedDotInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), kOperands);
  return std::make_unique<HloRaggedDotInstruction>(
      shape, new_operands[0], new_operands[1], new_operands[2],
      ragged_dot_dimension_numbers_, precision_config_);
}

HloScaledDotInstruction::HloScaledDotInstruction(
    const Shape& shape, HloInstruction* lhs, HloInstruction* rhs,
    HloInstruction* lhs_scale, HloInstruction* rhs_scale,
    const DotDimensionNumbers& dimension_numbers,
    const PrecisionConfig& precision_config)
    : HloInstruction(HloOpcode::kScaledDot, shape),
      dot_dimension_numbers_(dimension_numbers),
      precision_config_(precision_config) {
  AppendOperand(lhs);
  AppendOperand(rhs);
  AppendOperand(lhs_scale);
  AppendOperand(rhs_scale);
}

void HloScaledDotInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  *proto->mutable_dot_dimension_numbers() = dot_dimension_numbers_;
  *proto->mutable_precision_config() = precision_config_;
}

void HloScaledDotInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    printer->Append(DotDimensionNumbersToString(dot_dimension_numbers_));
  });
  PrintPrecisionConfig(printer, precision_config_);
}

bool HloScaledDotInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other = static_cast<const HloScaledDotInstruction&>(other);
  return protobuf_util::HaveSameSerialization(
             dot_dimension_numbers(), casted_other.dot_dimension_numbers()) &&
         protobuf_util::HaveSameSerialization(precision_config(),
                                              casted_other.precision_config());
}

std::unique_ptr<HloInstruction>
HloScaledDotInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* context) const {
  CHECK_EQ(new_operands.size(), kOperands);
  return std::make_unique<HloScaledDotInstruction>(
      shape, new_operands[0], new_operands[1], new_operands[2], new_operands[3],
      dot_dimension_numbers_, precision_config_);
}

HloGetDimensionSizeInstruction::HloGetDimensionSizeInstruction(
    const Shape& shape, HloInstruction* operand, int64_t dimension)
    : HloInstruction(HloOpcode::kGetDimensionSize, shape),
      dimension_(dimension) {
  AppendOperand(operand);
}

void HloGetDimensionSizeInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->add_dimensions(dimension_);
}

void HloGetDimensionSizeInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& /*options*/) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "dimensions={", dimension(), "}");
  });
}

bool HloGetDimensionSizeInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
    /*eq_computations*/) const {
  const auto& casted_other =
      static_cast<const HloGetDimensionSizeInstruction&>(other);
  return dimension() == casted_other.dimension();
}

std::unique_ptr<HloInstruction>
HloGetDimensionSizeInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  if (new_operands.size() != 1) {
    LOG(FATAL) << "expects 1 operand";
  }
  return std::make_unique<HloGetDimensionSizeInstruction>(
      shape, new_operands[0], dimension());
}

HloSetDimensionSizeInstruction::HloSetDimensionSizeInstruction(
    const Shape& shape, HloInstruction* operand, HloInstruction* val,
    int64_t dimension)
    : HloInstruction(HloOpcode::kSetDimensionSize, shape),
      dimension_(dimension) {
  AppendOperand(operand);
  AppendOperand(val);
}

void HloSetDimensionSizeInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& /*options*/) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "dimensions={", dimension(), "}");
  });
}

void HloSetDimensionSizeInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->add_dimensions(dimension_);
}

bool HloSetDimensionSizeInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
    /*eq_computations*/) const {
  const auto& casted_other =
      static_cast<const HloSetDimensionSizeInstruction&>(other);
  return dimension() == casted_other.dimension();
}

std::unique_ptr<HloInstruction>
HloSetDimensionSizeInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  if (new_operands.size() != 2) {
    LOG(FATAL) << "expects 2 operand";
  }
  return std::make_unique<HloSetDimensionSizeInstruction>(
      shape, new_operands[0], new_operands[1], dimension());
}

HloRngGetAndUpdateStateInstruction::HloRngGetAndUpdateStateInstruction(
    const Shape& shape, int64_t delta)
    : HloInstruction(HloOpcode::kRngGetAndUpdateState, shape), delta_(delta) {}

void HloRngGetAndUpdateStateInstruction::ToProto(
    HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_delta(delta_);
}

void HloRngGetAndUpdateStateInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& /*options*/) const {
  printer.Next(
      [this](Printer* printer) { AppendCat(printer, "delta=", delta()); });
}

bool HloRngGetAndUpdateStateInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
    /*eq_computations*/) const {
  const auto& casted_other =
      static_cast<const HloRngGetAndUpdateStateInstruction&>(other);
  return delta() == casted_other.delta();
}

std::unique_ptr<HloInstruction>
HloRngGetAndUpdateStateInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  if (!new_operands.empty()) {
    LOG(FATAL) << "expects 0 operand";
  }
  return std::make_unique<HloRngGetAndUpdateStateInstruction>(shape, delta());
}

HloRngBitGeneratorInstruction::HloRngBitGeneratorInstruction(
    const Shape& shape, HloInstruction* state, RandomAlgorithm algorithm)
    : HloInstruction(HloOpcode::kRngBitGenerator, shape),
      algorithm_(algorithm) {
  AppendOperand(state);
}

void HloRngBitGeneratorInstruction::ToProto(HloInstructionProto* proto) const {
  HloInstruction::ToProto(proto);
  proto->set_rng_algorithm(algorithm_);
}

void HloRngBitGeneratorInstruction::PrintExtraAttributesImpl(
    AttributePrinter& printer, const HloPrintOptions& options) const {
  printer.Next([this](Printer* printer) {
    AppendCat(printer, "algorithm=", RandomAlgorithmToString(algorithm_));
  });
}

bool HloRngBitGeneratorInstruction::IdenticalSlowPath(
    const HloInstruction& other,
    absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>
        eq_computations) const {
  const auto& casted_other =
      static_cast<const HloRngBitGeneratorInstruction&>(other);
  return algorithm() == casted_other.algorithm();
}

std::unique_ptr<HloInstruction>
HloRngBitGeneratorInstruction::CloneWithNewOperandsImpl(
    const Shape& shape, absl::Span<HloInstruction* const> new_operands,
    HloCloneContext* /*context*/) const {
  CHECK_EQ(new_operands.size(), 1);
  return std::make_unique<HloRngBitGeneratorInstruction>(shape, new_operands[0],
                                                         algorithm());
}

}  // namespace xla
