/* Copyright 2017 The OpenXLA Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "xla/hlo/ir/hlo_module.h"

#include <algorithm>
#include <atomic>
#include <cstddef>
#include <cstdint>
#include <functional>
#include <iterator>
#include <limits>
#include <memory>
#include <optional>
#include <stack>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "absl/algorithm/container.h"
#include "absl/container/btree_map.h"
#include "absl/container/flat_hash_map.h"
#include "absl/container/flat_hash_set.h"
#include "absl/functional/overload.h"
#include "absl/memory/memory.h"
#include "absl/status/status.h"
#include "absl/status/status_macros.h"
#include "absl/status/statusor.h"
#include "absl/strings/cord.h"
#include "absl/strings/escaping.h"
#include "absl/strings/match.h"
#include "absl/strings/numbers.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "absl/strings/str_join.h"
#include "absl/strings/str_replace.h"
#include "absl/strings/str_split.h"
#include "absl/strings/string_view.h"
#include "absl/synchronization/mutex.h"
#include "absl/types/span.h"
#include "tsl/platform/fingerprint.h"
#include "xla/debug_options_flags.h"
#include "xla/hlo/ir/backend_config.h"
#include "xla/hlo/ir/hlo_clone_context.h"
#include "xla/hlo/ir/hlo_computation.h"
#include "xla/hlo/ir/hlo_input_output_alias_config.h"
#include "xla/hlo/ir/hlo_instruction.h"
#include "xla/hlo/ir/hlo_module_metadata.h"
#include "xla/hlo/ir/hlo_opcode.h"
#include "xla/hlo/ir/hlo_original_value.h"
#include "xla/hlo/ir/hlo_original_value_util.h"
#include "xla/hlo/ir/hlo_payload_deduplicator.h"
#include "xla/hlo/ir/hlo_print_options.h"
#include "xla/hlo/ir/hlo_schedule.h"
#include "xla/hlo/ir/hlo_sharding.h"
#include "xla/hlo/ir/stack_frames.h"
#include "xla/hlo/parser/hlo_lexer.h"
#include "xla/map_util.h"
#include "xla/printer.h"
#include "xla/service/compilation_environments.h"
#include "xla/service/computation_layout.h"
#include "xla/service/device_assignment.h"
#include "xla/service/hlo.pb.h"
#include "xla/service/hlo_module_config.h"
#include "xla/service/mapped_ptr_container_sorter.h"
#include "xla/service/name_uniquer.h"
#include "xla/shape.h"
#include "xla/shape_util.h"
#include "xla/sort_json.h"
#include "xla/status_macros.h"
#include "xla/tsl/lib/gtl/map_util.h"
#include "xla/tsl/platform/env.h"
#include "xla/tsl/platform/logging.h"
#include "xla/tuple_tree.h"
#include "xla/util.h"
#include "xla/xla.pb.h"
#include "xla/xla_data.pb.h"

namespace xla {

HloModule::HloModule(const std::string& name, HloModuleConfig config)
    : HloModule(name, std::move(config),
                std::make_unique<CompilationEnvironments>()) {}

HloModule::HloModule(const std::string& name, HloModuleConfig config,
                     std::unique_ptr<CompilationEnvironments> comp_envs)
    : HloModule(name, std::make_shared<HloModuleConfig>(std::move(config)),
                std::move(comp_envs)) {}

HloModule::HloModule(const std::string& name,
                     std::shared_ptr<const HloModuleConfig> config,
                     std::unique_ptr<CompilationEnvironments> comp_envs)
    : name_(NameUniquer::GetSanitizedName(name)),
      config_(std::move(config)),
      unique_id_(next_unique_module_id_++),
      metadata_(tsl::Env::Default()),
      autofdo_fingerprint_(""),
      comp_envs_(std::move(comp_envs)) {
  metadata_.set_canonical_module_id(unique_id_);
}

// Private constructor.
HloModule::HloModule(const std::string& name, HloModuleConfig config,
                     std::unique_ptr<CompilationEnvironments> comp_envs,
                     int module_id)
    : name_(NameUniquer::GetSanitizedName(name)),
      config_(std::make_shared<HloModuleConfig>(std::move(config))),
      unique_id_(module_id < 0 ? next_unique_module_id_++ : module_id),
      metadata_(tsl::Env::Default()),
      autofdo_fingerprint_(""),
      comp_envs_(std::move(comp_envs)) {
  metadata_.set_canonical_module_id(unique_id_);
}

HloModule::~HloModule() {
  // To avoid dangling references between computations, we first clear all the
  // inter-computation references before deleting any of the computations.
  for (HloComputation* computation : computations()) {
    computation->ClearCalledComputations();
  }
}

absl::Status HloModule::set_schedule(HloSchedule schedule) {
  TF_RET_CHECK(schedule.module() == this);
  ABSL_RETURN_IF_ERROR(schedule.Verify());
  schedule_ = std::move(schedule);
  return absl::OkStatus();
}

void HloModule::ReplaceEntryComputation(HloComputation* entry_computation) {
  entry_computation_ = entry_computation;
  mutable_config().SetDefaultComputationLayout(
      entry_computation_->ComputeProgramShape());
  input_output_alias_config_ = HloInputOutputAliasConfig(
      entry_computation_->root_instruction()->shape());
  buffer_donor_config_ = HloBufferDonorConfig();
}

HloStackFrame HloModule::get_stack_frame(StackFrameId id) const {
  return stack_frames_.GetStackFrame(id);
}

void HloModule::Finalize() {
  instruction_name_uniquer_.reset();
  computation_name_uniquer_.reset();
}

HloComputation* HloModule::AddComputationInternal(
    std::unique_ptr<HloComputation> computation, bool is_entry,
    bool uniquify_identifiers, bool preserve_entry_layouts) {
  if (is_entry) {
    CHECK_EQ(nullptr, entry_computation_);
    entry_computation_ = computation.get();

    if (preserve_entry_layouts) {
      mutable_config().SetComputationLayoutIfExists(
          entry_computation_->ComputeProgramShape());
    } else if (!config().has_entry_computation_layout()) {
      // If the module configuration has no entry layout computation set, create
      // a default one based on the program shape.
      mutable_config().SetDefaultComputationLayout(
          entry_computation_->ComputeProgramShape());
    }
    input_output_alias_config_ = HloInputOutputAliasConfig(
        entry_computation_->root_instruction()->shape());
    buffer_donor_config_ = HloBufferDonorConfig();
  }

  if (uniquify_identifiers) {
    computation->UniquifyName(&computation_name_uniquer());
    for (HloInstruction* instruction : computation->instructions()) {
      instruction->UniquifyName(&instruction_name_uniquer());
    }

    // Set unique id to this computation.
    computation->ClearUniqueIdInternal();
    computation->SetUniqueId(ReadAndIncrementNextUniqueComputationId());
    // Computation sets unique ID internally in sequence
    // Recompacts the instructions vector to remove nullptr entries.
    computation->Cleanup();
  } else {
    // Don't uniquify the names of the computation or instruction, but we must
    // run the names through the uniquifiers to prevent future name collisions
    // for computations and instructions created later.
    ResyncNextUniqueComputationId(computation->unique_id());
    computation_name_uniquer().GetUniqueName(computation->name());
    for (HloInstruction* instruction : computation->instructions()) {
      instruction_name_uniquer().GetUniqueName(instruction->name());
    }
  }

  computation->set_parent(this);
  computation->index_in_module_ = computations_.size();
  HloComputation* computation_raw_ptr = computation.get();
  computations_.push_back(std::move(computation));
  topological_sort_.AddNode(computation_raw_ptr);
  for (auto& [caller, count] : computation_raw_ptr->caller_computations_) {
    if (caller->parent() == this) {
      topological_sort_.AddEdge(caller, computation_raw_ptr);
    }
  }
  for (auto& [callee, count] : computation_raw_ptr->callee_computations_) {
    if (callee->parent() == this) {
      topological_sort_.AddEdge(computation_raw_ptr, callee);
    }
  }
  return computation_raw_ptr;
}

HloComputation* HloModule::AddEntryComputation(
    std::unique_ptr<HloComputation> computation) {
  return AddComputationInternal(std::move(computation), /*is_entry=*/true,
                                /*uniquify_identifiers=*/true,
                                /*preserve_entry_layouts=*/false);
}

HloComputation* HloModule::AddEntryComputationWithLayouts(
    std::unique_ptr<HloComputation> computation) {
  return AddComputationInternal(std::move(computation), /*is_entry=*/true,
                                /*uniquify_identifiers=*/true,
                                /*preserve_entry_layouts=*/true);
}

absl::Status HloModule::RemoveEmbeddedComputation(HloComputation* to_remove) {
  auto it =
      absl::c_find_if(computations_, [to_remove](const auto& computation) {
        return computation.get() == to_remove;
      });
  TF_RET_CHECK(it != computations_.end());
  return RemoveEmbeddedComputation(it);
}

absl::Status HloModule::RemoveEmbeddedComputation(
    std::vector<std::unique_ptr<HloComputation>>::iterator to_remove) {
  TF_RET_CHECK(to_remove != computations_.end());
  auto& computation = *to_remove;
  if (has_schedule()) {
    schedule_->remove_computation(computation.get());
  }
  topological_sort_.RemoveNode(computation.get());

  to_be_deleted_computations_.push_back(std::move(*to_remove));
  to_be_deleted_computations_.back()->ClearCalledComputations();
  // Moving a unique_ptr from computations_ to to_be_deleted_computations_ will
  // morally reset() the unique_ptr in computations_.
  return absl::OkStatus();
}

HloComputation* HloModule::AddEmbeddedComputation(
    std::unique_ptr<HloComputation> computation) {
  return AddComputationInternal(std::move(computation), /*is_entry=*/false,
                                /*uniquify_identifiers=*/true,
                                /*preserve_entry_layouts=*/false);
}

void HloModule::MarkFusionDuplications(
    const absl::flat_hash_map<HloComputation*, HloComputation*>& replacements)
    const {
  for (const HloComputation* computation : computations()) {
    for (HloInstruction* instruction : computation->instructions()) {
      if (instruction->opcode() != HloOpcode::kFusion) {
        continue;
      }
      auto it =
          replacements.find(instruction->fused_instructions_computation());
      if (it == replacements.end()) {
        continue;
      }
      HloComputation* representative = it->second;
      // Follow chain to find the root representative.
      for (auto it2 = replacements.find(representative);
           it2 != replacements.end(); it2 = replacements.find(representative)) {
        representative = it2->second;
      }
      if (!representative->IsFusionComputation()) {
        continue;
      }
      std::string dedup_name(representative->FusionInstruction()->name());
      representative->FusionInstruction()->set_metadata_deduplicated_name(
          dedup_name);
      instruction->set_metadata_deduplicated_name(dedup_name);
    }
  }
}

void HloModule::MoveComputationsFrom(HloModule* module,
                                     bool make_names_unique) {
  for (size_t i = 0; i < module->computation_count(); ++i) {
    if (module->computations_[i] == nullptr) {
      continue;
    }
    module->computations_[i]->ClearUniqueIdInternal();
    HloComputation* computation_raw_ptr = module->computations_[i].get();
    if (computation_raw_ptr->IsEntryComputation()) {
      this->entry_computation_ = nullptr;
    }
    module->topological_sort_.RemoveNode(computation_raw_ptr);
    this->AddComputationInternal(
        std::move(module->computations_[i]),
        /*is_entry=*/computation_raw_ptr->IsEntryComputation(),
        /*uniquify_identifiers=*/false,
        /*preserve_entry_layouts=*/false);
    if (make_names_unique) {
      computation_raw_ptr->UniquifyName(&computation_name_uniquer());
      for (HloInstruction* instruction : computation_raw_ptr->instructions()) {
        instruction->UniquifyName(&instruction_name_uniquer());
      }
    }
    // Set unique id to this computation_raw_ptr.
    computation_raw_ptr->SetUniqueId(ReadAndIncrementNextUniqueComputationId());
  }
  // Since the computations no longer belong to the old module, clear the list.
  module->computations_.clear();
}

namespace {

struct OriginalArrayComparator {
  bool operator()(const OriginalArray& lhs, const OriginalArray& rhs) const {
    if (lhs.instruction_name != rhs.instruction_name) {
      return lhs.instruction_name < rhs.instruction_name;
    }
    return lhs.shape_index < rhs.shape_index;
  }
};

}  // namespace

void HloModule::ReplaceComputations(
    const absl::flat_hash_map<HloComputation*, HloComputation*>& replacements) {
  // Replace all uses of non-canonical computations with their
  // representatives.
  for (const auto iter : replacements) {
    HloComputation* old_computation = iter.first;
    HloComputation* new_computation = iter.second;
    for (auto* caller_instruction : old_computation->caller_instructions()) {
      caller_instruction->ReplaceCalledComputations(
          [&](HloComputation* callee) {
            if (callee == old_computation) {
              return new_computation;
            }
            return callee;
          });
    }
  }

  for (auto iterator = computations_.begin(); iterator != computations_.end();
       ++iterator) {
    if (*iterator == nullptr) {
      continue;
    }
    auto& computation = *iterator;
    if (replacements.contains(computation.get())) {
      CHECK_OK(RemoveEmbeddedComputation(iterator));
    }
  }

  // Replace entry_computation if necessary.
  entry_computation_ = tsl::gtl::FindWithDefault(
      replacements, entry_computation_, entry_computation_);
}

void HloModule::Print(
    Printer* printer, const HloPrintOptions& options,
    const absl::btree_map<std::string, NumericOrString>& custom_fields) const {
  const std::string tab(2 * options.indent_amount(), ' ');
  printer->Append(tab);
  printer->Append("HloModule ");
  if (options.print_ids()) {
    // When print_ids() is false, exclude module's name because it includes and
    // leads to non-deterministic fingerprint.
    printer->Append(name());
  }
  if (has_schedule()) {
    printer->Append(", is_scheduled=true");
  }
  std::string serialized_aliasing = input_output_alias_config().ToShortString();
  if (!serialized_aliasing.empty()) {
    printer->Append(", input_output_alias={ ");
    printer->Append(std::move(serialized_aliasing));
    printer->Append(" }");
  }
  std::string serialized_buffer_donor = buffer_donor_config().ToShortString();
  if (!serialized_buffer_donor.empty()) {
    printer->Append(", buffer_donor={ ");
    printer->Append(std::move(serialized_buffer_donor));
    printer->Append(" }");
  }

  PrintConfig(printer, this->config());

  if (!frontend_attributes_.map().empty()) {
    AppendCat(printer, ", frontend_attributes=",
              FrontendAttributesToString(frontend_attributes_));
  }
  if (options.print_backend_config() && has_backend_config()) {
    absl::string_view config = raw_backend_config_string();
    std::string sorted_config;
    if (options.sort_backend_config()) {
      sorted_config = SortJson(config).value_or(std::string(config));
      config = sorted_config;
    }
    printer->Append(", backend_config=");
    if (printer->is_hasher() || LexesAsJsonDict(config)) {
      printer->Append(config);
    } else {
      printer->Append("\"");
      printer->Append(absl::CEscape(config));
      printer->Append("\"");
    }
  }
  if (!original_value_recovery_table_.empty()) {
    HloPrintOptions new_options = options;
    new_options.set_indent_amount(options.indent_amount() + 1);
    printer->Append(", origin_recovery_table={\n");
    printer->Append(original_value_recovery_table_.ToString(new_options));
    printer->Append("}\n");
  }
  if (!debug_attributes_.empty()) {
    absl::btree_map<OriginalArray, std::vector<DebugAttributes>,
                    OriginalArrayComparator>
        ordered_debug_attributes(debug_attributes_.begin(),
                                 debug_attributes_.end());
    const size_t non_empty_attrs = absl::c_count_if(
        ordered_debug_attributes,
        [](const auto& entry) { return !entry.second.empty(); });
    if (non_empty_attrs > 0) {
      printer->Append(",\ndebug_attributes={\n");
      const std::string tab(2 * (options.indent_amount() + 1), ' ');
      size_t i = 0;
      for (const auto& [original_array, debug_attributes_vec] :
           ordered_debug_attributes) {
        if (debug_attributes_vec.empty()) {
          continue;
        }
        printer->Append(tab);
        printer->Append("{");
        printer->Append(original_array.ToString());
        printer->Append("}:(");
        for (size_t j = 0; j < debug_attributes_vec.size(); ++j) {
          printer->Append("{");
          printer->Append(debug_attributes_vec[j].ToString());
          printer->Append("}");
          if (j + 1 < debug_attributes_vec.size()) {
            printer->Append(",");
          }
        }
        printer->Append(")");
        if (++i < non_empty_attrs) {
          printer->Append(",");
        }
        printer->Append("\n");
      }
      printer->Append("}");
    }
  }

  for (const auto& [key, value] : custom_fields) {
    printer->Append(absl::StrCat(", ", key, "="));
    std::visit(
        absl::Overload{
            [&printer](const std::string& data) { printer->Append(data); },
            [&printer](const int64_t data) { printer->Append(data); },
            [&printer](const double data) { printer->Append(data); },
        },
        value);
  }
  PrintStackFrameIndex(printer, options);
  printer->Append("\n\n");
  PrintComputations(printer, options);
}

void HloModule::PrintConfig(Printer* printer,
                            const HloModuleConfig& config) const {
  if (config.alias_passthrough_params()) {
    printer->Append(", alias_passthrough_params=true");
  }
  if (config.has_entry_computation_layout()) {
    printer->Append(", entry_computation_layout={");
    entry_computation_layout().Print(printer);
    printer->Append("}");
  }
  if (config.allow_spmd_sharding_propagation_to_parameters().size() != 1 ||
      config.allow_spmd_sharding_propagation_to_parameters().back()) {
    printer->Append(", allow_spmd_sharding_propagation_to_parameters={");
    AppendJoin(printer, config.allow_spmd_sharding_propagation_to_parameters(),
               ",", [](Printer* printer, bool i) {
                 printer->Append(i ? "true" : "false");
               });
    printer->Append("}");
  }
  if (config.allow_spmd_sharding_propagation_to_output().size() != 1 ||
      config.allow_spmd_sharding_propagation_to_output().back()) {
    printer->Append(", allow_spmd_sharding_propagation_to_output={");
    AppendJoin(printer, config.allow_spmd_sharding_propagation_to_output(), ",",
               [](Printer* printer, bool i) {
                 printer->Append(i ? "true" : "false");
               });
    printer->Append("}");
  }
  if (config.replica_count() != 1) {
    printer->Append(", replica_count=");
    printer->Append(config.replica_count());
  }
  if (config.num_partitions() != 1) {
    printer->Append(", num_partitions=");
    printer->Append(config.num_partitions());
  }
}

void HloModule::PrintComputations(Printer* printer,
                                  const HloPrintOptions& options) const {
  // We use a DFS postorder traversal to ensure that computations are printed
  // more consistently run to run. Even thet non-dfs postorder is deterministic,
  // but exactly which topological ordering it yields depends on the order in
  // which the module was constructed.
  const auto& computations =
      options.canonicalize_computations()
          ? MakeComputationSorted()
          : MakeComputationPostOrder(/*dfs_postorder=*/true);
  for (const HloComputation* computation : computations) {
    // Don't print async computations when the syntax sugar is enabled since
    // that is redundant information.
    if (options.syntax_sugar_async_ops() && computation->IsAsyncComputation() &&
        computation->CanExpandIntoSingleInstruction()) {
      continue;
    }
    HloPrintOptions new_options = options;
    new_options.set_print_computation_mode(
        HloPrintOptions::PrintComputationMode::kComputationWithEntryKeyword);
    if (has_schedule() && schedule().is_computation_scheduled(computation)) {
      computation->Print(printer, new_options,
                         schedule().sequence(computation).instructions());
    } else {
      computation->Print(printer, new_options);
    }
    printer->Append("\n\n");
  }
}

void HloModule::PrintStackFrameIndex(Printer* printer,
                                     const HloPrintOptions& options) const {
  if (stack_frames_.empty() || !options.print_metadata()) {
    return;
  }
  const auto& proto = stack_frames_.proto();
  printer->Append("\n\nFileNames\n");
  for (int i = 0; i < proto.file_names_size(); ++i) {
    printer->Append(absl::StrFormat("%d \"%s\"\n", i + 1,
                                    absl::CEscape(proto.file_names(i))));
  }
  printer->Append("\nFunctionNames\n");
  for (int i = 0; i < proto.function_names_size(); ++i) {
    printer->Append(absl::StrFormat("%d \"%s\"\n", i + 1,
                                    absl::CEscape(proto.function_names(i))));
  }
  printer->Append("\nFileLocations\n");
  for (int i = 0; i < proto.file_locations_size(); ++i) {
    const auto& file_location = proto.file_locations(i);
    printer->Append(absl::StrFormat(
        "%d {file_name_id=%d function_name_id=%d line=%d "
        "end_line=%d column=%d end_column=%d}\n",
        i + 1, file_location.file_name_id(), file_location.function_name_id(),
        file_location.line(), file_location.end_line(), file_location.column(),
        file_location.end_column()));
  }
  printer->Append("\nStackFrames\n");
  for (int i = 0; i < proto.stack_frames_size(); ++i) {
    const auto& frame = proto.stack_frames(i);
    printer->Append(
        absl::StrFormat("%d {file_location_id=%d parent_frame_id=%d}\n", i + 1,
                        frame.file_location_id(), frame.parent_frame_id() + 1));
  }
}

std::string HloModule::ToString() const {
  const DebugOptions& db_options = config().debug_options();
  HloPrintOptions print_options = db_options.xla_dump_hlo_as_long_text()
                                      ? HloPrintOptions::Default()
                                      : HloPrintOptions::ShortParsable();
  print_options.set_print_large_constants(
      db_options.xla_dump_large_constants());
  print_options.set_print_metadata(!db_options.xla_dump_disable_metadata());
  print_options.set_syntax_sugar_async_ops(
      db_options.xla_syntax_sugar_async_ops());
  print_options.set_print_inline_stack_frames(
      db_options.xla_hlo_print_inline_stack_frames());
  print_options.set_compact_gte(db_options.xla_dump_compact_gte());
  print_options.set_sort_backend_config(true);
  return ToString(print_options);
}

std::string HloModule::ToString(const HloPrintOptions& options) const {
  StringPrinter printer;
  Print(&printer, options);
  return std::move(printer).ToString();
}

absl::Cord HloModule::ToCord(const HloPrintOptions& options) const {
  CordPrinter printer;
  Print(&printer, options);
  return std::move(printer).ToCord();
}

uint64_t HloModule::ToFingerprint(
    const HloPrintOptions& options,
    const absl::btree_map<std::string, NumericOrString>& custom_fields) const {
  HighwayHashPrinter printer;
  Print(&printer, options, custom_fields);
  return printer.ToFingerprint();
}

void HloModule::ToProto(HloModuleProto* proto, HloProtoOptions options) const {
  proto->set_id(unique_id_);
  proto->set_name(name_);
  if (entry_computation_ != nullptr) {
    *proto->mutable_entry_computation_name() =
        std::string(entry_computation_->name());
    proto->set_entry_computation_id(entry_computation_->unique_id());
    *proto->mutable_host_program_shape() =
        entry_computation_layout().ComputeProgramShape().ToProto();
  }

  // Deduplicate backend configs if requested via options or via XLA flag.
  // Do not override options where it's already manually set by the caller.
  if (!options.deduplicate_backend_config &&
      config().debug_options().has_xla_deduplicate_backend_configs_min_size()) {
    int64_t min_size =
        config().debug_options().xla_deduplicate_backend_configs_min_size();
    if (min_size >= 0 && min_size < std::numeric_limits<int64_t>::max()) {
      options.deduplicate_backend_config = true;
      options.min_backend_config_size = min_size;
    }
  }

  // Instantiate one shared deduplicator when either option is enabled.
  std::optional<HloPayloadDeduplicator> payload_deduplicator;
  if (options.deduplicate_backend_config || options.deduplicate_metadata) {
    payload_deduplicator.emplace(proto->payloads_size());
    options.payload_deduplicator = &*payload_deduplicator;
  }

  const std::vector<HloComputation*> post_order = MakeComputationPostOrder();
  proto->mutable_computations()->Reserve(proto->computations_size() +
                                         post_order.size());
  for (const HloComputation* computation : post_order) {
    computation->ToProto(proto->add_computations(), options);
  }

  if (payload_deduplicator.has_value()) {
    for (std::string& payload :
         std::move(*payload_deduplicator).TakePayloads()) {
      proto->add_payloads(std::move(payload));
    }
  }

  if (has_schedule()) {
    *proto->mutable_schedule() = schedule().ToProto().value();
  }
  *proto->mutable_input_output_alias() = input_output_alias_config().ToProto();
  *proto->mutable_buffer_donor() = buffer_donor_config().ToProto();
  for (const auto& [parameter, indices, alt_memory_offset] :
       CrossProgramPrefetches()) {
    auto* prefetch = proto->mutable_cross_program_prefetches()->Add();
    prefetch->set_parameter(parameter);
    for (int64_t index : indices) {
      prefetch->add_index(index);
    }
    if (alt_memory_offset.has_value()) {
      prefetch->set_offset(*alt_memory_offset);
    }
  }
  proto->set_is_dynamic(is_dynamic_);
  if (has_spmd_output_sharding()) {
    *proto->mutable_spmd_output_sharding() = spmd_output_sharding().ToProto();
  }

  *proto->mutable_frontend_attributes() = frontend_attributes_;

  if (has_spmd_parameters_shardings()) {
    for (const HloSharding& parameter_sharding : spmd_parameters_shardings()) {
      *proto->add_spmd_parameters_shardings() = parameter_sharding.ToProto();
    }
  }

  proto->set_use_auto_spmd_partitioning(use_auto_spmd_partitioning_);

  for (const HloModuleProto::ProfileInfo& profile_info : profile_info_list_) {
    HloModuleProto::ProfileInfo& profile_info_proto =
        *proto->mutable_profile_info()->Add();
    profile_info_proto.set_profile_type(profile_info.profile_type());
    profile_info_proto.set_relative_speedup(profile_info.relative_speedup());
    profile_info_proto.set_profile_source(profile_info.profile_source());
    profile_info_proto.set_compilation_event(profile_info.compilation_event());
    profile_info_proto.set_fingerprint(profile_info.fingerprint());
    profile_info_proto.set_profile_generation_strategy(
        profile_info.profile_generation_strategy());
    profile_info_proto.set_original_changelist(
        profile_info.original_changelist());
    profile_info_proto.set_changelist(profile_info.changelist());
  }
  if (config().has_static_device_assignment()) {
    DeviceAssignmentProto device_assignment;
    config().static_device_assignment().Serialize(&device_assignment);
    (*proto->mutable_device_assignment()) = device_assignment;
  }

  if (!stack_frames_.empty()) {
    (*proto->mutable_stack_frame_index()) = stack_frames_.proto();
  }

  if (!original_value_recovery_table_.empty()) {
    *proto->mutable_original_value_recovery_table() =
        original_value_recovery_table_.ToProto();
  }
  if (!debug_attributes_.empty()) {
    absl::btree_map<OriginalArray, std::vector<DebugAttributes>,
                    OriginalArrayComparator>
        ordered_debug_attributes(debug_attributes_.begin(),
                                 debug_attributes_.end());
    for (const auto& [original_array, debug_attributes_vec] :
         ordered_debug_attributes) {
      if (debug_attributes_vec.empty()) {
        continue;
      }
      auto* debug_attribute_proto = proto->add_debug_attributes();
      *debug_attribute_proto->mutable_original_array() =
          original_array.ToProto();
      for (const DebugAttributes& debug_attributes : debug_attributes_vec) {
        auto* debug_attributes_proto =
            debug_attribute_proto->add_debug_attributes();
        switch (debug_attributes.log_mode) {
          case DebugAttributes::DebugLogMode::kDefault:
            debug_attributes_proto->set_log_mode(DebugAttributesProto::DEFAULT);
            break;
          case DebugAttributes::DebugLogMode::kFusionDebugger:
            debug_attributes_proto->set_log_mode(
                DebugAttributesProto::FUSION_DEBUGGER);
            break;
          default:
            debug_attributes_proto->set_log_mode(DebugAttributesProto::NONE);
            break;
        }
        debug_attributes_proto->set_callback_id(debug_attributes.callback_id);
        debug_attributes_proto->set_partitioned(debug_attributes.partitioned);
        debug_attributes_proto->set_op_id(debug_attributes.op_id);
      }
    }
  }

  if (!config().device_type().empty()) {
    proto->set_device_type(config().device_type());
  }

  if (has_backend_config()) {
    proto->set_backend_config(raw_backend_config_string());
  }
}

void HloModule::ToProtoWithConfig(HloModuleProtoWithConfig* proto,
                                  HloProtoOptions options) const {
  *proto->mutable_config() = config().ToProto();
  ToProto(proto->mutable_hlo_module(), std::move(options));
}

absl::Status HloModule::CheckUniqueNamesAndIdsForComputationsAndInstructions()
    const {
  absl::flat_hash_set<absl::string_view> computation_names;
  absl::flat_hash_set<int64_t> computation_ids;
  absl::flat_hash_set<absl::string_view> instruction_names;
  absl::flat_hash_set<int64_t> instruction_ids;

  for (const HloComputation* computation : computations()) {
    TF_RET_CHECK(computation_names.insert(computation->name()).second)
        << "Computation name is not unique: " << computation->name();

    TF_RET_CHECK(computation_ids.insert(computation->unique_id()).second)
        << "Computation id is not unique: " << computation->unique_id();

    for (const HloInstruction* instruction : computation->instructions()) {
      TF_RET_CHECK(instruction_names.insert(instruction->name()).second)
          << "Instruction name is not unique: " << instruction->name();

      TF_RET_CHECK(instruction_ids.insert(instruction->unique_id()).second)
          << "Instruction id is not unique: " << instruction->unique_id()
          << " name: " << instruction->name()
          << " Parent: " << computation->name()
          << " Parent id: " << computation->unique_id();
    }
  }
  return absl::OkStatus();
}
/* static */
absl::Status HloModule::UpdateIdsInSchedule(
    HloModuleProto& proto, int64_t computation_proto_id,
    absl::flat_hash_map<int64_t, int64_t>& old_instr_id_to_new_id) {
  if (!proto.has_schedule()) {
    return absl::OkStatus();
  }
  auto* sequences = proto.mutable_schedule()->mutable_sequences();
  if (auto seq_it = sequences->find(computation_proto_id);
      seq_it != sequences->end()) {
    HloScheduleProto::InstructionSequence& sequence = seq_it->second;
    for (int64_t& instr_id : *sequence.mutable_instruction_ids()) {
      int64_t local_instr_id = HloInstruction::CalculateLocalId(instr_id);
      auto it = old_instr_id_to_new_id.find(local_instr_id);
      TF_RET_CHECK(it != old_instr_id_to_new_id.end())
          << "Instruction id " << instr_id
          << " not found in map when updating schedule ids.";
      instr_id = it->second;
    }
  }
  return absl::OkStatus();
}

/* static */
absl::StatusOr<HloModuleProto> HloModule::RemapInstructionIds(
    const HloModuleProto& proto) {
  HloModuleProto proto_copy = proto;
  for (HloComputationProto& computation_proto :
       *proto_copy.mutable_computations()) {
    int64_t next_instr_id = 0;
    int64_t new_root_id = -1;
    absl::flat_hash_map<int64_t, int64_t> old_instr_id_to_new_id;
    for (HloInstructionProto& instr_proto :
         *computation_proto.mutable_instructions()) {
      int64_t old_instr_id = instr_proto.id();
      instr_proto.set_id(next_instr_id++);
      old_instr_id_to_new_id[HloInstruction::CalculateLocalId(old_instr_id)] =
          instr_proto.id();
      if (HloInstruction::CalculateLocalId(old_instr_id) ==
          HloInstruction::CalculateLocalId(computation_proto.root_id())) {
        new_root_id = instr_proto.id();
      }
    }
    // Fix operands and control_predecessors.
    for (HloInstructionProto& instr_proto :
         *computation_proto.mutable_instructions()) {
      for (int64_t& operand_id : *instr_proto.mutable_operand_ids()) {
        operand_id = old_instr_id_to_new_id[HloInstruction::CalculateLocalId(
            operand_id)];
      }
      for (int64_t& control_predecessor_id :
           *instr_proto.mutable_control_predecessor_ids()) {
        control_predecessor_id =
            old_instr_id_to_new_id[HloInstruction::CalculateLocalId(
                control_predecessor_id)];
      }
    }
    // Fix root_id.
    TF_RET_CHECK(new_root_id != -1) << "Root id " << computation_proto.root_id()
                                    << " not found in computation proto.";
    computation_proto.set_root_id(new_root_id);
    // Fix schedule.
    ABSL_RETURN_IF_ERROR(UpdateIdsInSchedule(proto_copy, computation_proto.id(),
                                             old_instr_id_to_new_id));
  }
  return proto_copy;
}

void HloModule::CanonicalizeStackFrameIds(
    const StackFrameIndexProto& index_proto) {
  absl::flat_hash_map<int, int> mapping;
  std::vector<int> path;

  for (HloComputation* computation : computations()) {
    for (HloInstruction* instruction : computation->instructions()) {
      if (!instruction->has_metadata()) {
        continue;
      }
      OpMetadata& metadata = instruction->mutable_metadata();
      int old_id = metadata.stack_frame_id();
      if (old_id == 0) {
        continue;
      }

      // Collect all ancestors that need to be interned.
      int current = old_id;
      absl::flat_hash_set<int> visited;
      bool error = false;
      while (current != 0) {
        if (current < 0 || current > index_proto.stack_frames_size()) {
          LOG_FIRST_N(WARNING, 10) << "Invalid stack_frame_id " << current;
          error = true;
          break;
        }
        if (!visited.insert(current).second) {
          LOG_FIRST_N(WARNING, 10)
              << "Cycle detected in stack_frame_id " << current;
          error = true;
          break;
        }
        if (mapping.contains(current)) {
          break;
        }
        path.push_back(current);
        current = index_proto.stack_frames(current - 1).parent_frame_id();
      }

      if (error) {
        path.clear();
        metadata.set_stack_frame_id(0);
        continue;
      }

      // Intern frames from oldest to newest.
      StackFrameId current_id =
          (current == 0) ? StackFrameId{0} : StackFrameId{mapping[current]};
      while (!path.empty()) {
        int id_to_intern = path.back();
        path.pop_back();
        const auto& old_frame = index_proto.stack_frames(id_to_intern - 1);
        int loc_id = old_frame.file_location_id();
        if (loc_id <= 0 || loc_id > index_proto.file_locations_size()) {
          LOG_FIRST_N(WARNING, 10) << "Invalid file_location_id " << loc_id;
          current_id = StackFrameId{0};
          break;
        }
        const auto& old_loc = index_proto.file_locations(loc_id - 1);

        if (old_loc.file_name_id() <= 0 ||
            old_loc.file_name_id() > index_proto.file_names_size() ||
            old_loc.function_name_id() <= 0 ||
            old_loc.function_name_id() > index_proto.function_names_size()) {
          LOG_FIRST_N(WARNING, 10) << "Invalid IDs in file_location";
          current_id = StackFrameId{0};
          break;
        }

        HloStackFrame frame;
        frame.file_name = index_proto.file_names(old_loc.file_name_id() - 1);
        frame.function_name =
            index_proto.function_names(old_loc.function_name_id() - 1);
        frame.line = old_loc.line();
        frame.column = old_loc.column();
        frame.end_line = old_loc.end_line();
        frame.end_column = old_loc.end_column();
        frame.parent_frame_id = current_id;

        current_id = stack_frames_.AddStackFrame(frame);
        mapping[id_to_intern] = current_id.value;
      }

      metadata.set_stack_frame_id(current_id.value);
    }
  }
}

namespace {
absl::Status InlineMetadataPayloadsFromProtoPayloadTable(
    HloModule* module, const HloModuleProto& proto) {
  for (HloComputation* comp : module->computations()) {
    for (HloInstruction* inst : comp->instructions()) {
      if (inst->metadata().has_metadata_payload()) {
        Payload* payload = inst->mutable_metadata().mutable_metadata_payload();
        if (payload->has_id()) {
          int64_t id = payload->id();
          TF_RET_CHECK(id >= 0 && id < proto.payloads_size())
              << "Invalid metadata payload id " << id << " with payloads size "
              << proto.payloads_size();
          payload->set_value(proto.payloads(id));
        }
      }
    }
  }
  return absl::OkStatus();
}
}  // namespace

/* static */
absl::StatusOr<std::unique_ptr<HloModule>> HloModule::CreateFromProto(
    const HloModuleProto& proto, const HloModuleConfig& module_config,
    BufferAssignmentProto* buffer_assignment_proto,
    bool preserve_instruction_ids) {
  return CreateFromProto(proto, module_config, /*prohibit_empty_literal=*/true,
                         /*comp_envs=*/nullptr, preserve_instruction_ids,
                         buffer_assignment_proto);
}

/* static */
absl::StatusOr<std::unique_ptr<HloModule>> HloModule::CreateFromProto(
    const HloModuleProto& proto, const HloModuleConfig& module_config,
    bool prohibit_empty_literal,
    std::unique_ptr<CompilationEnvironments> comp_envs,
    bool preserve_instruction_ids,
    BufferAssignmentProto* buffer_assignment_proto) {
  VLOG(2) << "CreateFromProto()";
  XLA_VLOG_LINES(3, proto.DebugString());
  bool buffer_assignment_needs_remap =
      !preserve_instruction_ids && buffer_assignment_proto != nullptr;
  bool requires_remap_memorization =
      proto.has_schedule() || buffer_assignment_needs_remap;

  // The ProgramShape in the passed in module config must match the shapes of
  // the entry parameters and root.
  TF_RET_CHECK(proto.has_host_program_shape())
      << "No program shape found in the proto";
  ABSL_ASSIGN_OR_RETURN(ProgramShape expected_program_shape,
                        ProgramShape::FromProto(proto.host_program_shape()));
  TF_RET_CHECK(expected_program_shape.parameters_size() ==
               module_config.entry_computation_layout().parameter_count());
  for (int i = 0; i < expected_program_shape.parameters_size(); ++i) {
    const Shape& parameter_shape =
        module_config.entry_computation_layout().parameter_layout(i).shape();
    TF_RET_CHECK(ShapeUtil::Compatible(expected_program_shape.parameters(i),
                                       parameter_shape))
        << "HloModuleConfig has different shape for parameter " << i
        << " than the HLO module. Expected: "
        << ShapeUtil::HumanStringWithLayout(
               expected_program_shape.parameters(i))
        << ", actual: " << ShapeUtil::HumanStringWithLayout(parameter_shape);
  }
  const Shape& result_shape =
      module_config.entry_computation_layout().result_layout().shape();
  TF_RET_CHECK(
      ShapeUtil::Compatible(expected_program_shape.result(), result_shape))
      << "HloModuleConfig has different result shape than the HLO module. "
         "Expected: "
      << ShapeUtil::HumanStringWithLayout(expected_program_shape.result())
      << ", actual: " << ShapeUtil::HumanStringWithLayout(result_shape);

  std::vector<std::shared_ptr<BackendConfigWrapper>> backend_configs;
  backend_configs.reserve(proto.payloads_size());
  for (const std::string& payload : proto.payloads()) {
    backend_configs.push_back(std::make_shared<BackendConfigWrapper>(payload));
  }

  absl::flat_hash_map<int64_t, HloComputation*> computation_map;
  absl::flat_hash_map<HloComputation*, int64_t> to_proto_id;
  std::vector<std::unique_ptr<HloComputation>> computations;
  computations.reserve(proto.computations_size());
  HloComputation* entry = nullptr;
  // Only used for fixing the schedule or buffer assignment later
  absl::flat_hash_map<int64_t, absl::flat_hash_map<int64_t, int64_t>>
      computation_id_to_id_remap_map;
  for (const HloComputationProto& computation_proto : proto.computations()) {
    // Old instruction ids to new instruction ids after they are loaded into the
    // computation and potentially changed. Only used for fixing the schedule
    // or buffer assignment later.
    absl::flat_hash_map<int64_t, int64_t> id_remap_map;
    ABSL_ASSIGN_OR_RETURN(
        std::unique_ptr<HloComputation> computation,
        HloComputation::CreateFromProto(
            computation_proto, computation_map, prohibit_empty_literal,
            /*preserve_instruction_ids=*/preserve_instruction_ids,
            requires_remap_memorization ? &id_remap_map : nullptr,
            backend_configs));
    CHECK_NE(computation.get(), nullptr);
    int64_t computation_id = computation_proto.id();
    TF_RET_CHECK(computation_id != -1);
    TF_RET_CHECK(
        computation_map.emplace(computation_id, computation.get()).second);
    to_proto_id[computation.get()] = computation_id;
    if (computation_id == proto.entry_computation_id()) {
      entry = computation.get();
    }
    computations.push_back(std::move(computation));
    if (requires_remap_memorization) {
      computation_id_to_id_remap_map[computation_id] = std::move(id_remap_map);
    }
  }
  TF_RET_CHECK(entry != nullptr);

  auto module = absl::WrapUnique(
      new HloModule(proto.name(), module_config,
                    comp_envs ? std::move(comp_envs)
                              : std::make_unique<CompilationEnvironments>(),
                    proto.has_pjrt_id() ? proto.pjrt_id() : -1));
  if (!proto.device_type().empty()) {
    module->mutable_config().set_device_type(proto.device_type());
  }

  // Add sorted computations to the module.
  for (auto& computation : computations) {
    bool is_entry = computation.get() == entry;
    // Don't uniquify names because we want names to be stable across
    // serialization and deserialization.
    module->AddComputationInternal(std::move(computation), is_entry,
                                   /*uniquify_identifiers=*/false,
                                   /*preserve_entry_layouts=*/false);
  }
  TF_RET_CHECK(module->entry_computation_ != nullptr);
  ABSL_ASSIGN_OR_RETURN(
      module->input_output_alias_config_,
      HloInputOutputAliasConfig::CreateFromProto(
          entry->ComputeProgramShape().result(), proto.input_output_alias()));
  ABSL_ASSIGN_OR_RETURN(
      module->buffer_donor_config_,
      HloBufferDonorConfig::CreateFromProto(proto.buffer_donor()));

  ABSL_RETURN_IF_ERROR(
      module->CheckUniqueNamesAndIdsForComputationsAndInstructions());

  if (proto.has_schedule()) {
    ABSL_ASSIGN_OR_RETURN(
        HloSchedule schedule,
        HloSchedule::CreateFromProto(module.get(), proto.schedule(),
                                     preserve_instruction_ids
                                         ? nullptr
                                         : &computation_id_to_id_remap_map));
    ABSL_RETURN_IF_ERROR(module->set_schedule(std::move(schedule)));
  }

  // If a pointer to a buffer assignment proto is provided, that means we need
  // to keep the HloModule and the Buffer Assignment proto consistent.
  if (buffer_assignment_needs_remap) {
    ABSL_RETURN_IF_ERROR(UpdateBufferAssignmentProto(
        buffer_assignment_proto, computation_id_to_id_remap_map));
  }

  for (const auto& prefetch : proto.cross_program_prefetches()) {
    module->AddCrossProgramPrefetch(
        prefetch.parameter(),
        ShapeIndex(prefetch.index().begin(), prefetch.index().end()),
        prefetch.offset());
  }

  module->set_is_dynamic(proto.is_dynamic());

  if (proto.has_frontend_attributes()) {
    module->set_frontend_attributes(proto.frontend_attributes());
  }

  if (proto.has_spmd_output_sharding()) {
    ABSL_ASSIGN_OR_RETURN(HloSharding hlo_sharding,
                          HloSharding::FromProto(proto.spmd_output_sharding()));
    module->set_spmd_output_sharding(hlo_sharding);
  }

  std::vector<HloSharding> param_shardings;
  param_shardings.reserve(proto.spmd_parameters_shardings_size());
  for (const auto& sharding_proto : proto.spmd_parameters_shardings()) {
    ABSL_ASSIGN_OR_RETURN(HloSharding sharding,
                          HloSharding::FromProto(sharding_proto));
    param_shardings.push_back(std::move(sharding));
  }
  if (!param_shardings.empty()) {
    module->set_spmd_parameters_shardings(param_shardings);
  }

  module->set_use_auto_spmd_partitioning(proto.use_auto_spmd_partitioning());

  for (const auto& profile_info : proto.profile_info()) {
    module->add_profile_info(profile_info);
  }
  if (proto.has_device_assignment()) {
    if (!module->config().has_static_device_assignment()) {
      ABSL_ASSIGN_OR_RETURN(
          std::unique_ptr<DeviceAssignment> device_assignment,
          DeviceAssignment::Deserialize(proto.device_assignment()));
      module->mutable_config().set_static_device_assignment(*device_assignment);
    }
  }

  module->CanonicalizeStackFrameIds(proto.stack_frame_index());
  ABSL_RETURN_IF_ERROR(module->ReorderComputationsToPostOrder());

  if (proto.has_original_value_recovery_table()) {
    ABSL_ASSIGN_OR_RETURN(module->original_value_recovery_table_,
                          HloModule::OriginalValueRecoveryTable::FromProto(
                              proto.original_value_recovery_table()));
  }
  for (const auto& debug_attribute_table_entry : proto.debug_attributes()) {
    OriginalArray original_array =
        OriginalArray::FromProto(debug_attribute_table_entry.original_array());
    for (const auto& debug_attr_proto :
         debug_attribute_table_entry.debug_attributes()) {
      DebugAttributes::DebugLogMode debug_log_mode =
          DebugAttributes::DebugLogMode::kNone;
      switch (debug_attr_proto.log_mode()) {
        case DebugAttributesProto::DEFAULT:
          debug_log_mode = DebugAttributes::DebugLogMode::kDefault;
          break;
        case DebugAttributesProto::FUSION_DEBUGGER:
          debug_log_mode = DebugAttributes::DebugLogMode::kFusionDebugger;
          break;
        default:
          break;
      }
      module->AddDebugAttributes(
          original_array,
          DebugAttributes{debug_log_mode, debug_attr_proto.callback_id(),
                          debug_attr_proto.partitioned(),
                          debug_attr_proto.op_id()});
    }
  }

  DeduplicateOriginalValues(module.get());

  ABSL_RETURN_IF_ERROR(
      InlineMetadataPayloadsFromProtoPayloadTable(module.get(), proto));

  if (!proto.backend_config().empty()) {
    module->set_raw_backend_config_string(proto.backend_config());
  }

  return module;
}

/* static */
absl::Status HloModule::UpdateBufferAssignmentProto(
    BufferAssignmentProto* buffer_assignment_proto,
    const absl::flat_hash_map<int64_t, absl::flat_hash_map<int64_t, int64_t>>&
        computation_id_to_id_remap_map) {
  for (xla::LogicalBufferProto& logical_buffer :
       *buffer_assignment_proto->mutable_logical_buffers()) {
    int64_t computation_id = HloInstruction::CalculateParentId(
        logical_buffer.defined_at().instruction_id());
    auto comp_it = computation_id_to_id_remap_map.find(computation_id);
    TF_RET_CHECK(comp_it != computation_id_to_id_remap_map.end())
        << "Computation id " << computation_id << " not found in id remap map.";
    auto instr_it =
        comp_it->second.find(logical_buffer.defined_at().instruction_id());
    TF_RET_CHECK(instr_it != comp_it->second.end())
        << "Instruction id " << logical_buffer.defined_at().instruction_id()
        << " not found in id remap map for computation id " << computation_id;
    logical_buffer.mutable_defined_at()->set_instruction_id(instr_it->second);
  }
  for (xla::BufferAssignmentProto::BufferAlias& buffer_alias :
       *buffer_assignment_proto->mutable_buffer_aliases()) {
    int64_t computation_id = HloInstruction::CalculateParentId(
        buffer_alias.location().instruction_id());
    auto comp_it = computation_id_to_id_remap_map.find(computation_id);
    TF_RET_CHECK(comp_it != computation_id_to_id_remap_map.end())
        << "Computation id " << computation_id << " not found in id remap map.";
    auto instr_it =
        comp_it->second.find(buffer_alias.location().instruction_id());
    TF_RET_CHECK(instr_it != comp_it->second.end())
        << "Instruction id " << buffer_alias.location().instruction_id()
        << " not found in id remap map for computation id " << computation_id;
    buffer_alias.mutable_location()->set_instruction_id(instr_it->second);
  }
  return absl::OkStatus();
}

/* static */
absl::StatusOr<HloModuleConfig> HloModule::CreateModuleConfigFromShape(
    const ProgramShape& program_shape, const DebugOptions& debug_options,
    const ExecutionOptions* execution_options) {
  HloModuleConfig module_config(ProgramShape{program_shape});
  module_config.set_debug_options(debug_options);
  if (execution_options != nullptr) {
    if (execution_options->num_replicas() > 0) {
      module_config.set_replica_count(execution_options->num_replicas());
    }
    if (execution_options->num_partitions() > 0) {
      module_config.set_num_partitions(execution_options->num_partitions());
    }
    module_config.set_use_spmd_partitioning(
        execution_options->use_spmd_partitioning());
    module_config.set_use_auto_spmd_partitioning(
        execution_options->use_auto_spmd_partitioning());
    module_config.set_auto_spmd_partitioning_mesh_shape(std::vector<int64_t>(
        execution_options->auto_spmd_partitioning_mesh_shape().begin(),
        execution_options->auto_spmd_partitioning_mesh_shape().end()));
    module_config.set_auto_spmd_partitioning_mesh_ids(std::vector<int64_t>(
        execution_options->auto_spmd_partitioning_mesh_ids().begin(),
        execution_options->auto_spmd_partitioning_mesh_ids().end()));
    module_config.set_optimization_level(
        execution_options->optimization_level());
    module_config.set_memory_fitting_level(
        execution_options->memory_fitting_level());
    module_config.set_deduplicate_hlo(execution_options->deduplicate_hlo());
    if (!execution_options->allow_spmd_sharding_propagation_to_parameters()
             .empty()) {
      module_config.set_allow_spmd_sharding_propagation_to_parameters(
          execution_options->allow_spmd_sharding_propagation_to_parameters());
    }
    if (!execution_options->allow_spmd_sharding_propagation_to_output()
             .empty()) {
      module_config.set_allow_spmd_sharding_propagation_to_output(
          execution_options->allow_spmd_sharding_propagation_to_output());
    }
    if (execution_options->has_device_assignment()) {
      ABSL_ASSIGN_OR_RETURN(std::unique_ptr<DeviceAssignment> device_assignment,
                            DeviceAssignment::Deserialize(
                                execution_options->device_assignment()));
      module_config.set_static_device_assignment(*device_assignment);
      if (execution_options->num_replicas() > 0) {
        CHECK_EQ(module_config.static_device_assignment().replica_count(),
                 module_config.replica_count());
      }
      if (execution_options->num_partitions() > 0) {
        CHECK_EQ(module_config.static_device_assignment().computation_count(),
                 module_config.num_partitions());
      }
    }
    module_config.set_param_requires_broadcast_via_collectives(std::vector<
                                                               bool>(
        execution_options->param_requires_broadcast_via_collectives().begin(),
        execution_options->param_requires_broadcast_via_collectives().end()));
    module_config.set_allow_separate_sharding_programs(
        execution_options->allow_separate_sharding_programs());
    HloModuleConfig::AssignStructShardableValueUpdatePairs(
        module_config, execution_options->shardable_value_update_pairs());
    module_config.set_use_shardy_partitioner(
        execution_options->use_shardy_partitioner());
  }

  // The module config is constructed with default layouts regardless of what is
  // passed in via the ProgramShape. Set the layouts to the appropriate values.
  ComputationLayout* entry_layout =
      module_config.mutable_entry_computation_layout();
  for (int64_t i = 0; i < entry_layout->parameter_count(); ++i) {
    ABSL_RETURN_IF_ERROR(
        entry_layout->mutable_parameter_layout(i)->CopyLayoutFromShape(
            program_shape.parameters(i)));
  }
  ABSL_RETURN_IF_ERROR(
      entry_layout->mutable_result_layout()->CopyLayoutFromShape(
          program_shape.result()));
  return module_config;
}

/* static */
absl::StatusOr<HloModuleConfig> HloModule::CreateModuleConfigFromProto(
    const HloModuleProto& module, const DebugOptions& debug_options,
    const ExecutionOptions* execution_options) {
  if (!module.has_host_program_shape()) {
    return absl::FailedPreconditionError("No program shape found in the proto");
  }
  ABSL_ASSIGN_OR_RETURN(ProgramShape program_shape,
                        ProgramShape::FromProto(module.host_program_shape()));
  ABSL_ASSIGN_OR_RETURN(HloModuleConfig config,
                        CreateModuleConfigFromShape(
                            program_shape, debug_options, execution_options));
  if (!module.device_type().empty()) {
    config.set_device_type(module.device_type());
  }
  if (!config.has_static_device_assignment()) {
    if (module.has_device_assignment()) {
      // Get the proto from the execution options rather than the module proto.
      ABSL_ASSIGN_OR_RETURN(
          std::unique_ptr<DeviceAssignment> device_assignment,
          DeviceAssignment::Deserialize(module.device_assignment()));
      config.set_static_device_assignment(*device_assignment);
    }
  }
  return config;
}

/* static */
absl::StatusOr<std::unique_ptr<HloModule>> HloModule::CreateFromProtoWithConfig(
    const HloModuleProtoWithConfig& proto,
    BufferAssignmentProto* buffer_assignment_proto,
    bool preserve_instruction_ids) {
  return CreateFromProtoWithConfig(
      proto, /*prohibit_empty_literal=*/true,
      /*comp_envs=*/nullptr, preserve_instruction_ids, buffer_assignment_proto);
}

absl::StatusOr<std::unique_ptr<HloModule>> HloModule::CreateFromProtoWithConfig(
    const HloModuleProtoWithConfig& proto, bool prohibit_empty_literal,
    std::unique_ptr<CompilationEnvironments> comp_envs,
    bool preserve_instruction_ids,
    BufferAssignmentProto* buffer_assignment_proto) {
  const auto& hlo_module_proto = proto.hlo_module();
  ABSL_ASSIGN_OR_RETURN(std::unique_ptr<HloModuleConfig> config_ptr,
                        HloModuleConfig::CreateFromProto(proto.config()));
  return HloModule::CreateFromProto(
      hlo_module_proto, *config_ptr, prohibit_empty_literal,
      std::move(comp_envs), preserve_instruction_ids, buffer_assignment_proto);
}

namespace {
// Returns whether `hlo` is used outside the given subcomputation.
// `instructions_in_subcomputation` is the instruction set of the given
// subcomputation.
bool IsUsedOutsideSubcomputation(const HloInstruction& hlo,
                                 const absl::flat_hash_set<HloInstruction*>&
                                     instructions_in_subcomputation) {
  return absl::c_any_of(hlo.users(), [&](HloInstruction* user) {
    return !instructions_in_subcomputation.contains(user);
  });
}
}  // anonymous namespace

void HloModule::CleanupComputations() {
  if (to_be_deleted_computations_.empty()) {
    return;
  }
  std::vector<int> old_to_new(computations_.size(), -1);
  computations_.erase(
      std::remove_if(computations_.begin(), computations_.end(),
                     [](const std::unique_ptr<HloComputation>& comp) {
                       return comp == nullptr;
                     }),
      computations_.end());
  for (size_t i = 0; i < computations_.size(); ++i) {
    old_to_new[computations_[i]->index_in_module_] = i;
    computations_[i]->index_in_module_ = i;
  }
  topological_sort_.Reindex(old_to_new);
  to_be_deleted_computations_.clear();
}

void HloModule::CanonicalizeComputationLocalIds() {
  for (HloComputation* computation : computations()) {
    if (computation == nullptr) {
      continue;
    }
    computation->CanonicalizeLocalIds();
    if (has_schedule() && schedule().is_computation_scheduled(computation)) {
      schedule().GetOrCreateSequence(computation).update_id_sequence();
    }
  }
}

absl::Status HloModule::ReorderComputationsToPostOrder() {
  std::vector<HloComputation*> post_order = MakeComputationPostOrder();
  // Reorder computations_ in place based on post_order.
  // We move the computations into a temporary map keyed by their raw pointers,
  // and then move unique_ptrs back into computations_ in the post-order.
  // This avoids copying and handles unique_ptr correctly.
  absl::flat_hash_map<HloComputation*, std::unique_ptr<HloComputation>>
      comp_map;
  comp_map.reserve(computations_.size());
  for (auto& comp : computations_) {
    HloComputation* comp_ptr = comp.get();
    comp_map[comp_ptr] = std::move(comp);
  }

  std::vector<int> old_to_new(computations_.size(), -1);
  computations_.clear();
  computations_.reserve(post_order.size());
  for (size_t i = 0; i < post_order.size(); ++i) {
    HloComputation* comp = post_order[i];
    auto it = comp_map.find(comp);
    TF_RET_CHECK(it != comp_map.end()) << "Computation not found in module";
    old_to_new[comp->index_in_module_] = i;
    comp->index_in_module_ = i;
    computations_.push_back(std::move(it->second));
  }
  topological_sort_.Reindex(old_to_new);

  TF_RET_CHECK(computations_.size() == comp_map.size())
      << "Lost computations during reordering. Original count: "
      << comp_map.size() << ", Post-order count: " << computations_.size();

  return absl::OkStatus();
}

HloInstruction* HloModule::OutlineExpressionFromComputation(
    absl::Span<HloInstruction* const> instructions_to_outline,
    const std::string& outlined_computation_name, HloComputation* computation) {
  auto builder = HloComputation::Builder(outlined_computation_name);

  // A map from original instructions to their counterparts in the new outlined
  // function.
  absl::flat_hash_map<HloInstruction*, HloInstruction*> outlined_instructions;
  // A set that contains all instructions to be outlined.
  absl::flat_hash_set<HloInstruction*> instruction_set_to_outline(
      instructions_to_outline.begin(), instructions_to_outline.end());
  std::vector<HloInstruction*> arguments;
  std::vector<HloInstruction*> outputs;
  int64_t parameter_count = 0;
  for (HloInstruction* instruction_to_outline : instructions_to_outline) {
    // Clone the original instruction.
    HloInstruction* outlined_instruction =
        builder.AddInstruction(instruction_to_outline->Clone());

    // Replace its operands to their counterparts in the new function.
    for (int64_t operand_num = 0;
         operand_num < outlined_instruction->operand_count(); ++operand_num) {
      HloInstruction* old_operand =
          outlined_instruction->mutable_operand(operand_num);

      HloInstruction** operand_slot = &(outlined_instructions[old_operand]);
      if (*operand_slot == nullptr) {
        // Because instructions_to_outline is in topological order, if
        // old_operand is not in outlined_instructions, old_operand must be an
        // input of the outlined subcomputation and thus should be represented
        // as a parameter in the new function.
        arguments.push_back(old_operand);
        *operand_slot = builder.AddInstruction(HloInstruction::CreateParameter(
            parameter_count, old_operand->shape(), "p"));
        ++parameter_count;
      }
      CHECK_OK(
          outlined_instruction->ReplaceOperandWith(operand_num, *operand_slot));
    }

    // Insert the new instruction into the outlined_instructions map.
    CHECK(outlined_instructions
              .emplace(instruction_to_outline, outlined_instruction)
              .second);

    // Mark instruction_to_outline an output if it is used outside the
    // sub-computation or is the output of the original computation (i.e. used
    // externally).
    if (instruction_to_outline->user_count() == 0 ||
        IsUsedOutsideSubcomputation(*instruction_to_outline,
                                    instruction_set_to_outline)) {
      outputs.push_back(instruction_to_outline);
    }
  }

  if (outputs.size() != 1) {
    std::string error_message =
        "The subcomputation to outline has multiple outputs:\n";
    for (HloInstruction* output : outputs) {
      absl::StrAppend(&error_message, output->ToString(), "\n");
    }
    LOG(FATAL) << error_message;
  }
  HloInstruction* output = outputs[0];

  // Creates a call to the nested computation.
  HloComputation* nested_computation = AddEmbeddedComputation(
      builder.Build(FindOrDie(outlined_instructions, output)));
  HloInstruction* call = computation->AddInstruction(HloInstruction::CreateCall(
      output->shape(), arguments, nested_computation));

  VLOG(2) << "Outlining the following instructions";
  for (const HloInstruction* instruction_to_outline : instructions_to_outline) {
    VLOG(2) << "  " << instruction_to_outline->ToString();
  }
  VLOG(2) << "as a call " << call->ToString();
  VLOG(2) << "to " << nested_computation->ToString();

  CHECK_OK(output->ReplaceAllUsesWith(call));
  for (auto i = instructions_to_outline.rbegin();
       i != instructions_to_outline.rend(); ++i) {
    CHECK_OK(computation->RemoveInstruction(*i));
  }

  return call;
}

int64_t HloModule::instruction_count() const {
  int64_t num_instructions = 0;
  for (const HloComputation* computation : computations()) {
    num_instructions += computation->instruction_count();
  }
  return num_instructions;
}

std::vector<HloComputation*> HloModule::MakeComputationPostOrder(
    const absl::flat_hash_set<absl::string_view>& execution_threads,
    const absl::flat_hash_set<HloComputation*>& allow_list,
    bool dfs_postorder) const {
  std::vector<HloComputation*> post_order =
      this->MakeComputationPostOrder(execution_threads, dfs_postorder);

  post_order.erase(std::remove_if(post_order.begin(), post_order.end(),
                                  [&allow_list](HloComputation* computation) {
                                    return !allow_list.contains(computation);
                                  }),
                   post_order.end());

  return post_order;
}

std::vector<HloComputation*> HloModule::MakeComputationPostOrder(
    const absl::flat_hash_set<absl::string_view>& execution_threads,
    bool dfs_postorder) const {
  if (computations_.empty()) {
    return {};
  }

  if (dfs_postorder) {
    // First determine all root computations by building a set of non-root
    // computations (computations which are called by an instruction in the
    // module).
    absl::flat_hash_set<HloComputation*> nonroot_computations;
    nonroot_computations.reserve(computation_count() - 1);
    for (HloComputation* computation : computations()) {
      if (!computation->HasCalledComputations()) {
        continue;
      }
      for (const HloInstructionInfo& inst :
           computation->instructions_with_info()) {
        if (HloInstruction::MightHaveCalledComputations(inst.opcode())) {
          for (HloComputation* called_computation :
               inst->called_computations()) {
            nonroot_computations.insert(called_computation);
          }
        }
      }
    }

    // Keep track of computations which have already been added to the post
    // order. This prevents duplication as an embedded computation may be called
    // from two different root computations.
    absl::flat_hash_set<HloComputation*> added_computations;
    std::vector<HloComputation*> post_order;
    added_computations.reserve(computation_count());
    post_order.reserve(computation_count());
    size_t num_computations = 0;
    for (HloComputation* computation : computations()) {
      ++num_computations;
      if (nonroot_computations.contains(computation)) {
        continue;
      }
      if (computation->HasCalledComputations()) {
        for (HloComputation* embedded_computation :
             computation->MakeEmbeddedComputationsList()) {
          if (added_computations.insert(embedded_computation).second) {
            post_order.push_back(embedded_computation);
          }
        }
      }
      // Root computations should only be encountered once.
      CHECK(added_computations.insert(computation).second);
      post_order.push_back(computation);
    }
    if (post_order.size() != num_computations) {
      for (HloComputation* computation : post_order) {
        LOG(ERROR) << "Post Order: " << computation->name() << " ("
                   << computation->parent()->name() << ")";
      }
      for (const HloComputation* computation : computations()) {
        LOG(ERROR) << "Computations: " << computation->name() << " ("
                   << computation->parent()->name() << ")";
      }
      LOG(FATAL) << "Mismatch computation count: post_order="
                 << post_order.size()
                 << " num_computations=" << num_computations;
    }
    if (!execution_threads.empty()) {
      post_order.erase(std::remove_if(post_order.begin(), post_order.end(),
                                      [&](HloComputation* computation) {
                                        return !execution_threads.contains(
                                            computation->execution_thread());
                                      }),
                       post_order.end());
    }
    return post_order;
  }  // The topological sort is a reverse post-order, reverse it so we get a
  // post-order.
  std::vector<HloComputation*> post_order;
  post_order.reserve(computation_count());
  size_t num_computations = 0;
  for (auto it = topological_sort_.rbegin(); it != topological_sort_.rend();
       ++it) {
    ++num_computations;
    HloComputation* computation = computations_[*it].get();
    if (execution_threads.empty() ||
        execution_threads.contains(computation->execution_thread())) {
      post_order.push_back(computation);
    }
  }

  if (num_computations != computation_count()) {
    for (int32_t idx : topological_sort_) {
      HloComputation* computation = computations_[idx].get();
      LOG(ERROR) << "Reverse postorder: " << computation->name() << " ("
                 << computation->parent()->name() << ")";
    }
    for (const HloComputation* computation : computations()) {
      LOG(ERROR) << "Computations: " << computation->name() << " ("
                 << computation->parent()->name() << ")";
    }
    LOG(FATAL) << "Mismatch computation count: post_order=" << post_order.size()
               << " computation_count=" << computation_count();
  }
  return post_order;
}

namespace {

class FingerprintMap {
 public:
  void Reserve(int capacity) { fingerprint_map_.reserve(capacity); }

  uint64_t GetFingerprint(const HloComputation* computation) {
    auto result = fingerprint_map_.try_emplace(computation, 0);
    if (result.second) {
      HighwayHashPrinter printer;
      computation->Print(&printer, print_options_,
                         computation->MakeInstructionPostOrder());
      result.first->second = printer.ToFingerprint();
    }
    return result.first->second;
  }

 private:
  HloPrintOptions print_options_ = HloPrintOptions::ModuleFingerprint();
  absl::flat_hash_map<const HloComputation*, uint64_t> fingerprint_map_;
};

void SortComputationsByContent(std::vector<HloComputation*>* computations) {
  FingerprintMap fingerprint_map;
  fingerprint_map.Reserve(computations->size());
  auto cmp = [&fingerprint_map](const HloComputation* a,
                                const HloComputation* b) {
    if (a->instruction_count() != b->instruction_count()) {
      return a->instruction_count() < b->instruction_count();
    }
    // Avoid computing fingerprints of (potentially) giant computation strings
    // just to compare when a == b
    if (a == b) {
      return false;
    }

    return fingerprint_map.GetFingerprint(a) <
           fingerprint_map.GetFingerprint(b);
  };
  absl::c_sort(*computations, cmp);
}

}  // anonymous namespace

std::vector<HloComputation*> HloModule::MakeComputationSorted(
    const absl::flat_hash_set<absl::string_view>& execution_threads) const {
  std::vector<HloComputation*> result =
      MakeComputationPostOrder(execution_threads);
  if (config().content_aware_computation_sorting()) {
    SortComputationsByContent(&result);
  }
  return result;
}

std::vector<HloComputation*> HloModule::MakeNonfusionComputations(
    const absl::flat_hash_set<absl::string_view>& execution_threads) const {
  std::vector<HloComputation*> result =
      MakeComputationPostOrder(execution_threads);
  result.erase(std::remove_if(
                   result.begin(), result.end(),
                   [](HloComputation* c) { return c->IsFusionComputation(); }),
               result.end());
  return result;
}

std::vector<HloComputation*> HloModule::MakeNonfusionComputationsSorted(
    const absl::flat_hash_set<absl::string_view>& execution_threads) const {
  std::vector<HloComputation*> result =
      MakeNonfusionComputations(execution_threads);
  if (config().content_aware_computation_sorting()) {
    SortComputationsByContent(&result);
  }
  return result;
}

namespace {
std::unique_ptr<HloModule> CreateModule(
    absl::string_view suffix, std::optional<const HloModuleConfig> config_in,
    const HloModule& source) {
  std::string div = suffix.empty() ? "" : "-";
  std::string new_name = absl::StrCat(source.name(), div, suffix);
  VLOG(1) << "Cloning module :" << source.name() << " --> " << new_name << "\n";
  std::shared_ptr<const HloModuleConfig> new_config =
      config_in.has_value()
          ? std::make_shared<const HloModuleConfig>(*config_in)
          : source.shared_config();
  return std::make_unique<HloModule>(
      new_name, new_config,
      std::make_unique<CompilationEnvironments>(source.comp_envs()));
}

void CopyUniqueIds(const HloModule& source, HloModule* clone,
                   const HloCloneContext& context) {
  for (HloComputation* computation : source.computations()) {
    HloComputation* new_computation = context.FindComputation(computation);
    if (new_computation == nullptr) {
      continue;
    }
    new_computation->CopyLocalIdsFromComputation(*computation, context);
  }
}

}  // namespace

void HloModule::Clone(const std::string& suffix, HloCloneContext* context,
                      std::optional<const HloModuleConfig> config) const {
  HloModule* module = context->module();
  if (entry_computation_ != nullptr) {
    std::unique_ptr<HloComputation> cloned_computation =
        entry_computation_->Clone(suffix, context);
    module->AddEntryComputation(std::move(cloned_computation));
  }

  // Preserve original instruction and computation ids.
  CopyUniqueIds(*this, module, *context);
  module->SetNextUniqueComputationId(ReadNextUniqueComputationId());

  module->input_output_alias_config() = input_output_alias_config();
  module->buffer_donor_config() = buffer_donor_config();
  module->set_is_dynamic(is_dynamic());
  module->set_hlo_passes_started(hlo_passes_started());
  module->set_frontend_attributes(frontend_attributes());
  module->set_unoptimized_fingerprint(unoptimized_fingerprint());
  module->backend_config_ = backend_config_;
  *module->metadata() = metadata();
  // The canonical module id should be the same as the unique id from the
  // module. We don't want to copy the id from the other metadata.
  module->metadata()->set_canonical_module_id(module->unique_id());
  if (!stack_frames().empty()) {
    module->set_stack_frames(stack_frames());
  }
  if (has_schedule() && schedule().Verify().ok()) {
    HloSchedule clone_schedule(module);
    for (HloComputation* computation : computations()) {
      if (schedule().is_computation_scheduled(computation)) {
        HloComputation* new_computation = context->FindComputation(computation);
        // The module being cloned may have computations that are dead, i.e.,
        // unreachable from the entry computation. In that case, new_computation
        // is nullptr.
        if (new_computation != nullptr) {
          HloInstructionSequence& clone_sequence =
              clone_schedule.GetOrCreateSequence(new_computation);
          for (const HloInstruction* instruction :
               schedule().sequence(computation).instructions()) {
            clone_sequence.push_back(context->GetInstruction(instruction));
          }
        }
      }
    }
    CHECK_OK(module->set_schedule(std::move(clone_schedule)));
  }
  for (const auto& [parameter, indices, offset] : CrossProgramPrefetches()) {
    module->AddCrossProgramPrefetch(parameter, indices, offset);
  }
  if (has_spmd_output_sharding()) {
    module->set_spmd_output_sharding(spmd_output_sharding());
  }
  if (has_spmd_parameters_shardings()) {
    module->set_spmd_parameters_shardings(spmd_parameters_shardings());
  }

  // To make clone behavior match uncloned behavior, we reorder
  // module->computations_ to match the order in computations_.
  using ComputationSorter = MappedPtrContainerSorter<HloComputation>;
  auto computation_map_fn = [&context](const HloComputation* c) {
    return context->FindComputation(c);
  };
  auto status = ComputationSorter::Sort(
      computation_map_fn, ComputationSorter::IndexAfterMappedElementsFn(),
      computations_, module->computations_);
  if (!status.ok()) {
    LOG(ERROR) << "Failed to sort module computations for " << name() << "; "
               << status;
  }
  std::vector<int> old_to_new(module->computations_.size(), -1);
  for (size_t i = 0; i < module->computations_.size(); ++i) {
    old_to_new[module->computations_[i]->index_in_module_] = i;
    module->computations_[i]->index_in_module_ = i;
  }
  module->topological_sort_.Reindex(old_to_new);
}

std::unique_ptr<HloModule> HloModule::Clone(
    const std::string& suffix,
    std::optional<const HloModuleConfig> config) const {
  std::unique_ptr<HloModule> module = CreateModule(suffix, config, *this);
  auto clone_context = std::make_unique<HloCloneContext>(module.get(), suffix);
  Clone(suffix, clone_context.get(), config);
  return module;
}

std::pair<std::unique_ptr<HloModule>, std::unique_ptr<HloCloneContext>>
HloModule::CloneWithContext(const std::string& suffix,
                            std::optional<const HloModuleConfig> config) const {
  std::unique_ptr<HloModule> module = CreateModule(suffix, config, *this);
  auto clone_context = std::make_unique<HloCloneContext>(module.get(), suffix);
  Clone(suffix, clone_context.get(), config);
  return std::make_pair(std::move(module), std::move(clone_context));
}

absl::Status HloModule::RemoveUnusedComputations() {
  absl::flat_hash_set<HloComputation*> to_remove(computations().begin(),
                                                 computations().end());
  std::stack<HloComputation*> agenda;
  agenda.push(entry_computation_);
  to_remove.erase(entry_computation_);
  while (!agenda.empty()) {
    HloComputation* computation = agenda.top();
    agenda.pop();
    if (!computation->HasCalledComputations()) {
      continue;
    }
    for (const HloInstructionInfo& inst :
         computation->instructions_with_info()) {
      if (!HloInstruction::MightHaveCalledComputations(inst.opcode())) {
        continue;
      }
      for (HloComputation* called_computation : inst->called_computations()) {
        if (to_remove.erase(called_computation) > 0) {
          agenda.push(called_computation);
        }
      }
    }
  }

  for (auto it = computations_.begin(); it != computations_.end(); ++it) {
    if (*it != nullptr && to_remove.contains(it->get())) {
      ABSL_RETURN_IF_ERROR(RemoveEmbeddedComputation(it));
    }
  }
  CleanupComputations();
  return absl::OkStatus();
}

HloComputation* HloModule::DeepCloneComputation(HloComputation* computation,
                                                HloCloneContext* context) {
  HloComputation* new_computation;
  if (context != nullptr) {
    if ((new_computation = context->FindComputation(computation)) != nullptr) {
      return new_computation;
    }
    new_computation =
        AddEmbeddedComputation(computation->Clone(context->suffix(), context));
  } else {
    new_computation = AddEmbeddedComputation(computation->Clone(""));
  }
  return new_computation;
}

uint64_t HloModule::RandomNew64() const {
  absl::MutexLock l(rng_mutex_);
  return rng_();
}

HloComputation* HloModule::GetComputationWithName(
    absl::string_view name) const {
  auto computations_in_module = computations();
  auto it = absl::c_find_if(
      computations_in_module,
      [&](HloComputation* computation) { return computation->name() == name; });
  return it == computations_in_module.end() ? nullptr : *it;
}

std::string HloModule::GetFingerprint128(const HloPrintOptions& options) const {
  // Use HighwayHashPrinter to compute the fingerprint by streaming HLO text
  // directly into the hasher, avoiding materialization of the full module text
  // as a string. For large modules this avoids multi-GB string allocations.
  HighwayHashPrinter printer;
  Print(&printer, options);
  tsl::Fprint128 fingerprint = printer.ToFingerprint128();
  return absl::StrCat(absl::Hex(fingerprint.low64, absl::kZeroPad16),
                      absl::Hex(fingerprint.high64, absl::kZeroPad16));
}

namespace {

// Order the original value recovery table by the instruction name of the key
// OriginalArray. This is to make the order of the table deterministic for
// testing and debugging.
absl::btree_map<OriginalArray, std::pair<OriginalArray, HloModule*>,
                OriginalArrayComparator>
GetOrderedHashMap(
    const HloModule::OriginalValueRecoveryTable::Table& unordered_table) {
  absl::btree_map<OriginalArray, std::pair<OriginalArray, HloModule*>,
                  OriginalArrayComparator>
      ordered_table;
  for (const auto& p : unordered_table) {
    ordered_table[p.first] =
        std::make_pair(p.second.first, p.second.second.get());
  }
  return ordered_table;
}

}  // namespace

std::string HloModule::DebugAttributes::ToString() const {
  std::vector<std::string> attrs;
  if (log_mode != DebugLogMode::kNone) {
    std::string mode_str;
    switch (log_mode) {
      case DebugLogMode::kDefault:
        mode_str = "default";
        break;
      case DebugLogMode::kFusionDebugger:
        mode_str = "fusion_debugger";
        break;
      default:
        break;
    }
    attrs.push_back(absl::StrCat("log_mode=", mode_str));
  }
  if (callback_id != 0) {
    attrs.push_back(absl::StrCat("callback_id=", callback_id));
  }
  if (partitioned) {
    attrs.push_back("partitioned=true");
  }
  if (op_id != 0) {
    attrs.push_back(absl::StrCat("op_id=", op_id));
  }
  return absl::StrJoin(attrs, ",");
}

std::string HloModule::OriginalValueRecoveryTable::ToString(
    HloPrintOptions options) const {
  std::string result;
  for (const auto& p : GetOrderedHashMap(table_)) {
    const auto& old_original_array = p.first;
    const auto& new_original_array = p.second.first;
    HloModule* recovery_module = p.second.second;
    // Wraps the recovery module with double quotes so that it can be parsed as
    // a string. This is to make sure it can be parsed as a standalone module
    // without interfering with the parsing of the main module the table is
    // associated with.
    const std::string tab(2 * (options.indent_amount()), ' ');
    std::string recovery_module_string;
    if (recovery_module != nullptr) {
      std::string recovery_module_text = recovery_module->ToString(
          HloPrintOptions().set_indent_amount(options.indent_amount() + 1));
      // Escape the double quotes and backslashes in the recovery module text.
      absl::StrReplaceAll({{"\\", "\\\\"}, {"\"", "\\\""}},
                          &recovery_module_text);
      absl::StrAppend(&recovery_module_string, ",\n", tab, "\"\n",
                      recovery_module_text, "\n", tab, "\"");
    }
    absl::StrAppend(&result, tab, "{", old_original_array.ToString(), "} : {",
                    new_original_array.ToString(), "}", recovery_module_string,
                    "\n");
  }
  return result;
}

OriginalValueRecoveryTableProto HloModule::OriginalValueRecoveryTable::ToProto()
    const {
  OriginalValueRecoveryTableProto original_value_recovery_table_proto;
  for (const auto& p : GetOrderedHashMap(table_)) {
    const auto& old_original_array = p.first;
    const auto& new_original_array = p.second.first;
    HloModule* recovery_module = p.second.second;
    auto* entry = original_value_recovery_table_proto.add_entries();
    *entry->mutable_old_original_array() = old_original_array.ToProto();
    *entry->mutable_new_original_array() = new_original_array.ToProto();
    if (recovery_module != nullptr) {
      *entry->mutable_recovery_module() = recovery_module->ToProto();
    }
  }
  return original_value_recovery_table_proto;
}

absl::StatusOr<HloModule::OriginalValueRecoveryTable>
HloModule::OriginalValueRecoveryTable::FromProto(
    const xla::OriginalValueRecoveryTableProto&
        original_value_recovery_table_proto) {
  OriginalValueRecoveryTable original_value_recovery_table;

  for (const auto& entry : original_value_recovery_table_proto.entries()) {
    OriginalArray old_original_array =
                      OriginalArray::FromProto(entry.old_original_array()),
                  new_original_array =
                      OriginalArray::FromProto(entry.new_original_array());
    std::unique_ptr<HloModule> recovery_module;
    if (entry.has_recovery_module()) {
      const HloModuleProto proto = entry.recovery_module();
      ABSL_ASSIGN_OR_RETURN(HloModuleConfig config,
                            HloModule::CreateModuleConfigFromProto(
                                proto, GetDebugOptionsFromFlags()));
      ABSL_ASSIGN_OR_RETURN(recovery_module,
                            HloModule::CreateFromProto(proto, config));
    }
    original_value_recovery_table.table_[old_original_array] =
        std::make_pair(new_original_array, std::move(recovery_module));
  }
  return original_value_recovery_table;
}

namespace {
std::string GetOriginalValuePlaceholderInstructionName(
    absl::string_view original_value_instruction_name) {
  std::string base_name = std::string(original_value_instruction_name);
  int64_t placeholder_index = 0;
  if (absl::StrContains(original_value_instruction_name,
                        kOriginalValuePlaceholderDelimiter)) {
    // split by the delimiter and update the base and index
    std::vector<std::string> parts = absl::StrSplit(
        original_value_instruction_name, kOriginalValuePlaceholderDelimiter);
    CHECK_EQ(parts.size(), 2)
        << "Original value instruction name does not have the expected format: "
        << original_value_instruction_name;
    base_name = parts[0];
    CHECK(absl::SimpleAtoi(parts[1], &placeholder_index))
        << "Invalid placeholder index in original value name: "
        << original_value_instruction_name;
    ++placeholder_index;
  }
  return absl::StrCat(base_name, kOriginalValuePlaceholderDelimiter,
                      placeholder_index);
}
}  // namespace

void HloModule::OriginalValueRecoveryTable::AddRecoveryComputation(
    const HloInstruction* old_inst, HloInstruction* new_inst,
    std::function<std::optional<std::unique_ptr<HloModule>>(
        const ShapeIndex& index, const OriginalArray& old_original_array,
        const xla::Shape& old_array_shape, const xla::Shape& new_array_shape)>&&
        build_recovery_computation) {
  CHECK(ShapeUtil::EqualStructure(old_inst->shape(), new_inst->shape()));
  std::shared_ptr<OriginalValue> old_original_value =
      old_inst->original_value();
  if (old_original_value == nullptr ||
      old_original_value->is_synthetic_call()) {
    return;
  }
  if (new_inst->original_value() == nullptr) {
    new_inst->set_original_value(std::make_shared<OriginalValue>(
        TupleTree<std::optional<OriginalArray>>(new_inst->shape())));
  }
  for (const auto& [shape_index, old_original_array] :
       old_original_value->original_arrays()) {
    if (!old_original_array.has_value() ||
        table_.contains(*old_original_array)) {
      // If the original array is already tracked by the recovery table, we can
      // ignore it since it is already handled by another path.
      continue;
    }
    std::optional<std::unique_ptr<HloModule>> recovery_computation(nullptr);
    if (build_recovery_computation) {
      recovery_computation = build_recovery_computation(
          shape_index, *old_original_array,
          ShapeUtil::GetSubshape(old_inst->shape(), shape_index),
          ShapeUtil::GetSubshape(new_inst->shape(), shape_index));
      if (!recovery_computation.has_value()) {
        // Skips if build_recovery_computation returns a nullopt, which
        // indicates
        // the original array is not recoverable.
        continue;
      }
    }
    std::optional<OriginalArray>* new_original_array =
        new_inst->original_value()->mutable_original_array(shape_index);
    if (!new_original_array->has_value()) {
      if (*recovery_computation == nullptr) {
        // If the recovery computation is a nullptr, it means this is an
        // identity computation and we can just pass through the original array.
        new_original_array->emplace(*old_original_array);
        continue;
      }
      new_original_array->emplace(
          OriginalArray{GetOriginalValuePlaceholderInstructionName(
                            old_original_array->instruction_name),
                        old_original_array->shape_index});
    }
    table_.emplace(
        *old_original_array,
        std::make_pair(**new_original_array, std::move(*recovery_computation)));
  }
}

void HloModule::OriginalValueRecoveryTable::BuildAndAddRecoveryComputation(
    const HloInstruction* old_inst, HloInstruction* new_inst,
    std::function<std::optional<HloInstruction*>(
        xla::HloComputation::Builder& builder, const ShapeIndex& index,
        const OriginalArray& old_original_array,
        const xla::Shape& old_array_shape, const xla::Shape& new_array_shape)>&&
        build_recovery_computation) {
  AddRecoveryComputation(
      old_inst, new_inst,
      [build_recovery_computation](
          const ShapeIndex& index, const OriginalArray& old_original_array,
          const xla::Shape& old_array_shape, const xla::Shape& new_array_shape)
          -> std::optional<std::unique_ptr<HloModule>> {
        xla::HloComputation::Builder builder("recovery_computation");
        xla::HloModuleConfig config;
        auto recovery_module =
            std::make_unique<xla::HloModule>("recovery_module", config);
        std::optional<HloInstruction*> root_instruction =
            build_recovery_computation(builder, index, old_original_array,
                                       old_array_shape, new_array_shape);
        if (!root_instruction.has_value()) {
          return std::nullopt;
        }
        if (*root_instruction == nullptr) {
          return nullptr;
        }
        recovery_module->AddEntryComputation(builder.Build(*root_instruction));
        return recovery_module;
      });
}

/* static */ std::atomic<int> HloModule::next_unique_module_id_(0);

bool HloModule::IsEntryComputationUnboundedDynamic() const {
  if (computations().begin() == computations().end()) {
    return false;
  }
  return (*computations().begin())->IsEntryInstUnboundedDynamic();
}

}  // namespace xla
