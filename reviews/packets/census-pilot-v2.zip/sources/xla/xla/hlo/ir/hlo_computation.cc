/* Copyright 2017 The OpenXLA Authors.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
==============================================================================*/

#include "xla/hlo/ir/hlo_computation.h"

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <iterator>
#include <memory>
#include <optional>
#include <ostream>
#include <queue>
#include <stack>
#include <string>
#include <utility>
#include <variant>
#include <vector>

#include "absl/algorithm/container.h"
#include "absl/container/btree_map.h"
#include "absl/container/flat_hash_map.h"
#include "absl/container/flat_hash_set.h"
#include "absl/container/inlined_vector.h"
#include "absl/functional/function_ref.h"
#include "absl/functional/overload.h"
#include "absl/log/check.h"
#include "absl/memory/memory.h"
#include "absl/status/status.h"
#include "absl/status/status_macros.h"
#include "absl/strings/escaping.h"
#include "absl/strings/str_cat.h"
#include "absl/strings/str_format.h"
#include "absl/strings/str_join.h"
#include "absl/strings/string_view.h"
#include "absl/types/span.h"
#include "google/protobuf/repeated_ptr_field.h"
#include "xla/hlo/ir/backend_config.h"
#include "xla/hlo/ir/dfs_hlo_visitor.h"
#include "xla/hlo/ir/hlo_casting_utils.h"
#include "xla/hlo/ir/hlo_clone_context.h"
#include "xla/hlo/ir/hlo_input_output_alias_config.h"
#include "xla/hlo/ir/hlo_instruction.h"
#include "xla/hlo/ir/hlo_instruction_utils.h"
#include "xla/hlo/ir/hlo_instructions.h"
#include "xla/hlo/ir/hlo_module.h"
#include "xla/hlo/ir/hlo_opcode.h"
#include "xla/hlo/ir/hlo_print_options.h"
#include "xla/hlo/ir/hlo_schedule.h"
#include "xla/hlo/ir/ptrvec.h"
#include "xla/hlo/parser/hlo_lexer.h"
#include "xla/literal.h"
#include "xla/printer.h"
#include "xla/service/hlo.pb.h"
#include "xla/service/hlo_module_config.h"
#include "xla/service/mapped_ptr_container_sorter.h"
#include "xla/service/name_uniquer.h"
#include "xla/shape.h"
#include "xla/shape_layout.h"
#include "xla/shape_tree.h"
#include "xla/shape_util.h"
#include "xla/sort_json.h"
#include "xla/status_macros.h"
#include "xla/tsl/lib/gtl/iterator_range.h"
#include "xla/tsl/platform/logging.h"
#include "xla/util.h"
#include "xla/xla_data.pb.h"

namespace xla {

using absl::StrCat;

namespace {

// Tagged pointer discriminator for `HloComputation::callers_`.
// To avoid allocating a heap hash map for the common case where a computation
// has at most one caller instruction, `callers_` stores either a direct
// `HloInstruction*` (tagged with `kHloInstruction`) or a heap-allocated
// `absl::flat_hash_map<const HloInstruction*, int>*` (tagged with
// `kCallerCountHashMap`) in the pointer bits, using the lowest bit as tag.
enum class CallersType : uint8_t {
  kHloInstruction = 0,
  kCallerCountHashMap = 1,
};
constexpr uintptr_t kCallerTypeMask = 0b1;

enum class VisitState { kNew = 0, kVisiting = 1, kVisited = 2 };

}  // namespace

static std::ostream& operator<<(std::ostream& os, const VisitState& state) {
  switch (state) {
    case VisitState::kNew:
      os << "new";
      break;
    case VisitState::kVisiting:
      os << "visiting";
      break;
    case VisitState::kVisited:
      os << "visited";
      break;
  }
  return os;
}

class HloComputation::VisitMap {
 public:
  VisitMap() = default;
  explicit VisitMap(int capacity) : size_(capacity) {
    int num_words = (capacity + 31) / 32;
    bits_.resize(num_words);
    bit_ptr_ = bits_.empty() ? nullptr : bits_.data();
  }

  // A handle is a dense index used to identify a particular node.
  using Handle = uint32_t;

  // Returns the current VisitState for the instruction with handle "h"
  VisitState GetState(Handle h) const {
    DCHECK_LT(h, size_);
    uint32_t word = (h / 32);
    uint32_t shift = (h % 32) << 1;
    return static_cast<VisitState>((bit_ptr_[word] >> shift) & 0x3);
  }

  // Sets the VisitState for the instruction with Handle "h" to "new_state"
  void SetState(Handle h, VisitState new_state) {
    DCHECK_LT(h, size_);
    uint32_t word = (h / 32);
    uint32_t shift = (h % 32) << 1;
    uint64_t mask = ~(3ull << shift);
    uint64_t val = static_cast<uint64_t>(new_state);
    bit_ptr_[word] = (bit_ptr_[word] & mask) | (val << shift);
  }

 private:
  // bits_ stores VisitState entries (2 bits per entry, packed 32 entries per
  // 64-bit word)
  absl::InlinedVector<uint64_t, 1> bits_;
  uint64_t* bit_ptr_ = nullptr;  //
  int size_ = 0;  // Number of entries.  bits_ holds at least 2 * this many bits
};

absl::StatusOr<HloInstruction*> HloComputation::Builder::AddParameter(
    std::unique_ptr<HloInstruction> parameter) {
  if (!parameter_numbers_.insert(parameter->parameter_number()).second) {
    return Internal("Duplicate parameter number %d",
                    parameter->parameter_number());
  }
  return AddInstruction(std::move(parameter));
}

absl::Status HloComputation::Builder::ForEachInstruction(
    absl::FunctionRef<absl::Status(const HloInstruction*)> func) const {
  for (const auto& instruction : instructions_) {
    ABSL_RETURN_IF_ERROR(func(instruction.get()));
  }
  return absl::OkStatus();
}

std::unique_ptr<HloComputation> HloComputation::Builder::Build(
    HloInstruction* root_instruction) {
  int parameter_count = absl::c_count_if(
      instructions_, [](const std::unique_ptr<HloInstruction>& instruction) {
        return instruction->opcode() == HloOpcode::kParameter;
      });
  // If root_instruction is not specified use the last added instruction.
  HloInstruction* root =
      root_instruction != nullptr ? root_instruction : last_added_instruction();
  CHECK_NE(nullptr, root);
  return absl::WrapUnique(
      new HloComputation(name_, parameter_count, &instructions_, root));
}

HloComputation::HloComputation(
    const std::string& name, int parameter_count,
    std::vector<std::unique_ptr<HloInstruction>>* instructions,
    HloInstruction* root_instruction, bool preserve_instruction_ids)
    : unique_id_(-1),
      root_instruction_(root_instruction),
      instruction_count_(0),
      name_(NameUniquer::GetSanitizedName(name)) {
  param_instructions_.resize(parameter_count, nullptr);
  bool root_found = false;

  if (preserve_instruction_ids) {
    // Pre-allocate all instructions in the vector since it state should be
    // identical.
    int32_t max_instruction_local_id = 0;
    for (auto& instruction : *instructions) {
      if (instruction != nullptr) {
        max_instruction_local_id =
            std::max(max_instruction_local_id, instruction->local_id());
      }
    }
    instructions_.resize(max_instruction_local_id + 1);
  }

  for (auto& instruction : *instructions) {
    if (instruction == nullptr) {
      // The instruction is actually a gap left in the instructions vector which
      // should be represented by an empty HloInstructionInfo.
      instructions_.push_back(HloInstructionInfo());
      continue;
    }
    if (instruction->opcode() == HloOpcode::kParameter) {
      int64_t param_no = instruction->parameter_number();
      CHECK(param_no >= 0 && param_no < parameter_count)
          << "\nERROR: invalid parameter number. Expected [0, "
          << parameter_count << "), got " << param_no;
      CHECK(param_instructions_[param_no] == nullptr)
          << "\nERROR: parameter number " << param_no
          << " already allocated in this computation";
      param_instructions_[param_no] = instruction.get();
    }
    root_found |= instruction.get() == root_instruction_;
    AddInstructionInternal(std::move(instruction), preserve_instruction_ids);
  }
  CHECK(root_found)
      << "\nERROR: root instruction is not present in computation.";
  root_instruction_->MarkAsRoot();
}

HloComputation::~HloComputation() {
  if (FusionInstruction() != nullptr) {
    CHECK(FusionInstruction()->fused_instructions_computation() == this);
    FusionInstruction()->ClearCalledComputations();
  }
  // Every live instruction dies below, so only the edges that leave the
  // computation are unlinked; the call also makes ~HloInstruction skip the
  // rest. Instructions in to_be_deleted_ were detached at removal.
  for (HloInstruction* instruction : instructions()) {
    instruction->DetachFromOperandsAndUsersOutside(this);
  }
  Cleanup();
  ClearCalledComputations();

  // We need to make sure there are no dangling references to this computation
  // from instructions in other computations.
  std::vector<HloComputation*> callers;
  callers.reserve(caller_computations_.size());
  for (const auto& [caller, count] : caller_computations_) {
    callers.push_back(caller);
  }
  for (HloComputation* caller : callers) {
    for (HloInstruction* inst : caller->instructions()) {
      for (int i = 0; i < inst->called_computations().size(); ++i) {
        if (inst->called_computations()[i] == this) {
          inst->set_called_computation(i, nullptr);
        }
      }
    }
  }
  CHECK(caller_computations_.empty());

  // Delete the map from caller instructions to count, if it exists.
  delete GetCallersMap();

  for (const auto& i : instructions_) {
    delete i.inst();
  }
}

void HloComputation::ClearCalledComputations() {
  for (HloInstruction* i : instructions()) {
    i->ClearCalledComputations();
  }
  // Clearing the instructions should have removed all callee computations.
  CHECK(callee_computations_.empty());
}

HloInstruction* HloComputation::AddInstruction(
    std::unique_ptr<HloInstruction> instruction, absl::string_view new_name) {
  CHECK(instruction->opcode() != HloOpcode::kParameter)
      << "Parameter instructions cannot be added to a computation after "
      << "it has been built";
  if (!new_name.empty()) {
    instruction->SetAndSanitizeName(new_name);
  }
  return AddInstructionInternal(std::move(instruction));
}

HloInstruction* HloComputation::AddInstruction(
    std::unique_ptr<HloInstruction> instruction, const OpMetadata* metadata) {
  if (metadata != nullptr) {
    instruction->set_metadata(*metadata);
  }
  return AddInstruction(std::move(instruction));
}

HloInstruction* HloComputation::AddInstruction(
    std::unique_ptr<HloInstruction> instruction, const OpMetadata* metadata,
    const FrontendAttributes* frontend_attributes) {
  if (metadata != nullptr) {
    instruction->set_metadata(*metadata);
  }
  if (frontend_attributes != nullptr) {
    instruction->set_frontend_attributes(*frontend_attributes);
  }
  return AddInstruction(std::move(instruction));
}

void HloComputation::CopyLocalIdsFromComputation(
    const HloComputation& source_computation, const HloCloneContext& context) {
  ClearUniqueIdInternal();
  SetUniqueIdHelper(source_computation.unique_id_);
  VLOG(2) << "Copying local ids from computation " << source_computation.name()
          << " to computation " << name();
  // Rewrites the instructions_ vector to copy the local_id_ from the source
  // computation to the destination computation since the local_id_ represents
  // physical order of the instructions in the computation.
  HloInstructionList cloned_instructions(
      source_computation.instructions_.size());
  for (HloInstruction* source_instruction : source_computation.instructions()) {
    if (source_instruction == nullptr) {
      // Instruction is a gap left in the instructions vector.
      continue;
    }
    HloInstruction* destination_instruction =
        context.FindInstruction(source_instruction);
    if (destination_instruction == nullptr) {
      VLOG(2) << "Destination instruction is nullptr for source instruction "
              << source_instruction->ToString();
      continue;
    }

    int32_t original_destination_local_id = destination_instruction->local_id_;
    CHECK(cloned_instructions.at(source_instruction->local_id_).inst() ==
          nullptr)
        << "Instruction local_id_ conflict at index "
        << source_instruction->local_id_;
    destination_instruction->ClearUniqueIdInternal();
    destination_instruction->SetLocalId(source_instruction->local_id_);
    cloned_instructions[source_instruction->local_id_] =
        std::move(instructions_[original_destination_local_id]);
  }

  instructions_ = std::move(cloned_instructions);
  next_instruction_unique_id_ = instructions_.size();
}

static void IncrementCount(
    absl::btree_map<HloComputation*, int, HloComputation::UniqueIdComparator>&
        map,
    HloComputation* key) {
  ++map[key];
}

static void DecrementCount(
    absl::btree_map<HloComputation*, int, HloComputation::UniqueIdComparator>&
        map,
    HloComputation* key) {
  auto it = map.find(key);
  CHECK(it != map.end());
  CHECK_GT(it->second, 0);
  --it->second;
  if (it->second == 0) {
    map.erase(it);
  }
}

void HloComputation::AddCallee(HloInstruction* caller, HloComputation* callee) {
  IncrementCount(callee_computations_, callee);
  IncrementCount(callee->caller_computations_, this);

  if (auto* map = callee->GetCallersMap()) {
    ++(*map)[caller];
  } else if (callee->callers_ == 0) {
    callee->callers_ = reinterpret_cast<uintptr_t>(caller);
  } else {
    // Convert the single instruction to a map.
    auto* current_caller = reinterpret_cast<const HloInstruction*>(
        callee->callers_ & ~kCallerTypeMask);
    auto* map = new absl::flat_hash_map<const HloInstruction*, int>();
    (*map)[current_caller] = 1;
    ++(*map)[caller];
    callee->callers_ = reinterpret_cast<uintptr_t>(map) |
                       static_cast<uintptr_t>(CallersType::kCallerCountHashMap);
  }

  if (parent() != nullptr && callee->parent() == parent()) {
    parent()->topological_sort_.AddEdge(this, callee);
  }
}

void HloComputation::RemoveCallee(HloInstruction* caller,
                                  HloComputation* callee) {
  CHECK(caller);
  CHECK(callee);
  DecrementCount(callee_computations_, callee);
  DecrementCount(callee->caller_computations_, this);

  if (callee->callers_ == reinterpret_cast<uintptr_t>(caller)) {
    // The callee had just this single caller, so we reset it to 0 (no caller).
    callee->callers_ = 0;
  } else {
    auto* map = callee->GetCallersMap();
    CHECK(map) << "Attempted to remove a caller " << caller->name()
               << " that did not call the computation " << name() << "."
               << callee->callers_;
    auto it = map->find(caller);
    CHECK(it != map->end())
        << "Attempted to remove a caller " << caller->name()
        << " that did not call the computation " << name() << ".";
    --it->second;
    // We don't convert back to the inline representation, since this case
    // should be rare.
  }
}

absl::flat_hash_map<HloInstruction*, int>* HloComputation::GetCallersMap() {
  if (static_cast<CallersType>(callers_ & kCallerTypeMask) ==
      CallersType::kCallerCountHashMap) {
    return reinterpret_cast<absl::flat_hash_map<HloInstruction*, int>*>(
        callers_ & ~kCallerTypeMask);
  }
  return nullptr;
}

const absl::flat_hash_map<HloInstruction*, int>* HloComputation::GetCallersMap()
    const {
  if (static_cast<CallersType>(callers_ & kCallerTypeMask) ==
      CallersType::kCallerCountHashMap) {
    return reinterpret_cast<const absl::flat_hash_map<HloInstruction*, int>*>(
        callers_ & ~kCallerTypeMask);
  }
  return nullptr;
}

HloInstruction* HloComputation::AddInstructionInternal(
    std::unique_ptr<HloInstruction> instruction, bool preserve_unique_id) {
  if (parent() != nullptr) {
    instruction->UniquifyName(parent());
  }
  instruction->set_parent(this);
  HloInstruction* pinst = instruction.release();  // Take ownership
  HloInstructionInfo info;
  info.opcode_ = pinst->opcode();
  info.inst_ = pinst;

  if (preserve_unique_id && pinst->local_id_ >= 0) {
    // Already set unique id previously therefore it is preserved.
    // Calls for AddInstructionInternal from preserving sources assume that all
    // space in instructions_ vector has been pre-allocated.
    CHECK(pinst->local_id() < instructions_.size())
        << "Instruction local_id " << pinst->local_id()
        << " is out of range [0, " << instructions_.size()
        << ") when adding instruction from proto";
    next_instruction_unique_id_ = instructions_.size();
    instructions_[pinst->local_id()] = info;
  } else {
    // Unset instructions from preserving sources and regular instructions get
    // assigned a new unique id.
    pinst->ClearUniqueIdInternal();
    // Must match the size of the instructions_ vector.
    CHECK_EQ(next_instruction_unique_id_, instructions_.size())
        << "Mismatch between next_instruction_unique_id_ and instructions_ "
           "vector size at computation: "
        << name();
    pinst->SetLocalId(next_instruction_unique_id_++);
    instructions_.push_back(info);
  }

  instruction_count_++;

  for (HloComputation* called_computation : pinst->called_computations()) {
    CHECK(called_computation);
    // TODO(b/399394039): Consider enforcing that
    // called_computation->parent() != nullptr.
    CHECK(parent() == nullptr || called_computation->parent() == parent())
        << "Called computation " << called_computation->name()
        << " is not in the same module as " << name();
    AddCallee(pinst, called_computation);
  }
  return pinst;
}

HloInstruction* HloComputation::AddParameter(
    std::unique_ptr<HloInstruction> instruction) {
  CHECK(instruction->opcode() == HloOpcode::kParameter);
  CHECK(!IsFusionComputation() ||
        FusionInstruction()->operand_count() == param_instructions_.size());
  instruction->set_parent(this);
  param_instructions_.push_back(instruction.get());
  AddInstructionInternal(std::move(instruction));
  return instructions_.back().get();
}

HloInstruction* HloComputation::AddEntryComputationParameter(
    std::unique_ptr<HloInstruction> instruction) {
  CHECK_EQ(instruction->opcode(), HloOpcode::kParameter);
  CHECK_EQ(instruction->parameter_number(), num_parameters());
  CHECK(parent()->entry_computation() == this);

  HloModuleConfig config = parent()->config();
  config.mutable_entry_computation_layout()->add_parameter_layout(
      ShapeLayout(instruction->shape()));
  parent()->set_config(config);

  instruction->set_parent(this);
  param_instructions_.push_back(instruction.get());
  AddInstructionInternal(std::move(instruction));

  return instructions_.back().get();
}

absl::Status HloComputation::ReplaceEntryComputationParameter(
    int64_t param_no, HloInstruction* old_instruction,
    std::unique_ptr<HloInstruction> instruction) {
  CHECK_GE(param_no, 0);
  CHECK_LT(param_no, param_instructions_.size());
  CHECK_EQ(instruction->opcode(), HloOpcode::kParameter);
  CHECK(parent()->entry_computation() == this);

  HloModuleConfig config = parent()->config();
  *config.mutable_entry_computation_layout()->mutable_parameter_layout(
      param_no) = ShapeLayout(instruction->shape());
  parent()->set_config(config);

  instruction->set_parent(this);
  param_instructions_[param_no] = instruction.get();
  AddInstructionInternal(std::move(instruction));

  return ForceRemoveInstruction(old_instruction);
}

absl::Status HloComputation::RemoveParameter(int64_t param_no) {
  CHECK_GE(param_no, 0);
  CHECK_LT(param_no, param_instructions_.size());
  HloInstruction* param_instruction = param_instructions_[param_no];
  auto param_instruction_iterator = param_instructions_.begin() + param_no;
  param_instructions_.erase(param_instruction_iterator);
  // Throw removed fused parameter instruction away.
  ABSL_RETURN_IF_ERROR(ForceRemoveInstruction(param_instruction));

  while (param_no < param_instructions_.size()) {
    param_instruction = param_instructions_[param_no];
    HloInstruction* new_instr =
        AddInstructionInternal(HloInstruction::CreateParameter(
            param_no, param_instruction->shape(), StrCat("param_", param_no)));
    param_instruction->SetupDerivedInstruction(new_instr);
    ABSL_RETURN_IF_ERROR(param_instruction->ReplaceAllUsesWith(new_instr));
    param_instructions_[param_no] = new_instr;
    ABSL_RETURN_IF_ERROR(ForceRemoveInstruction(param_instruction));
    param_no++;
  }

  return absl::OkStatus();
}

HloInstruction* HloComputation::ReplaceParameter(
    int64_t param_no, std::unique_ptr<HloInstruction> instruction) {
  CHECK_GE(param_no, 0);
  CHECK_LT(param_no, param_instructions_.size());
  CHECK(instruction->opcode() == HloOpcode::kParameter);
  CHECK(!IsFusionComputation() ||
        FusionInstruction()->operand_count() == param_instructions_.size());

  instruction->set_parent(this);
  HloInstruction* new_instruction =
      AddInstructionInternal(std::move(instruction));
  HloInstruction* old_instruction = param_instructions_[param_no];
  CHECK_OK(old_instruction->ReplaceAllUsesWithDifferentShape(new_instruction));
  param_instructions_[param_no] = new_instruction;
  CHECK_OK(ForceRemoveInstruction(old_instruction));
  return new_instruction;
}

absl::Status HloComputation::RemoveUnusedParametersFromFusedComputation() {
  return RemoveUnusedParametersImpl(/*allow_non_fusion=*/false);
}

absl::Status HloComputation::RemoveUnusedParametersFromAnyComputation() {
  return RemoveUnusedParametersImpl(/*allow_non_fusion=*/true);
}

absl::Status HloComputation::RemoveUnusedParametersImpl(bool allow_non_fusion) {
  CHECK(allow_non_fusion || IsFusionComputation());
  int64_t removed = 0;
  for (int64_t i = 0; i < param_instructions_.size(); ++i) {
    HloInstruction* param_instruction = param_instructions_[i];
    if (param_instruction->IsDead()) {
      ABSL_RETURN_IF_ERROR(
          RemoveInstructionImpl(param_instruction, allow_non_fusion));
      ++removed;
      continue;
    }

    if (removed > 0) {
      const int64_t param_no = i - removed;
      HloInstruction* new_instr = AddInstructionInternal(
          HloInstruction::CreateParameter(param_no, param_instruction->shape(),
                                          StrCat("param_", param_no)));
      ABSL_RETURN_IF_ERROR(param_instruction->ReplaceAllUsesWith(new_instr));
      param_instructions_[param_no] = new_instr;
      ABSL_RETURN_IF_ERROR(
          RemoveInstructionImpl(param_instruction, allow_non_fusion));
    }
  }
  param_instructions_.resize(param_instructions_.size() - removed);
  return absl::OkStatus();
}

absl::Status HloComputation::PermuteParameters(
    absl::Span<const int64_t> permutation) {
  if (permutation.size() != num_parameters()) {
    return absl::InvalidArgumentError(
        "Permutation size must match the number of parameters.");
  }
  if (permutation.size() == 1) {
    return absl::OkStatus();
  }

  std::vector<std::unique_ptr<HloInstruction>> new_param_instructions(
      num_parameters());
  for (int64_t i = 0; i < num_parameters(); ++i) {
    int64_t new_param_number = permutation[i];
    new_param_instructions[new_param_number] = HloInstruction::CreateParameter(
        new_param_number, param_instructions_[i]->shape(),
        param_instructions_[i]->name());
  }

  for (int64_t i = 0; i < num_parameters(); ++i) {
    ReplaceParameter(i, std::move(new_param_instructions[permutation[i]]));
  }

  absl::c_sort(param_instructions_,
               [](const HloInstruction* a, const HloInstruction* b) {
                 return a->parameter_number() < b->parameter_number();
               });
  return absl::OkStatus();
}

bool HloComputation::IsSafelyRemovable(
    const HloInstruction* instruction, bool ignore_control_dependency,
    std::optional<
        absl::FunctionRef<std::vector<HloInstruction*>(const HloComputation*)>>
        computation_callers,
    bool remove_dead_param_from_entry) const {
  // If the instruction has control predecessors or successors then we cannot
  // remove the instruction without violating ordering constraints (added, for
  // example, to avert interference due to buffer aliasing).
  if (!ignore_control_dependency && instruction->HasControlDependencies()) {
    return false;
  }

  if (instruction->opcode() == HloOpcode::kParameter) {
    // If there is no parent, it is safe to remove the child.
    if (instruction->parent() == nullptr) {
      return true;
    }
    // Entry computation parameters can never be removed unless explicitly
    // specified. Then user needs to update the entry computation layout
    // accordingly.
    if (instruction->parent()->IsEntryComputation() &&
        !remove_dead_param_from_entry) {
      return false;
    }
    // We generally want to be using the call graph to determine who the caller
    // is, as this back pointer is very fragile, however its not reasonable to
    // expect every caller to be passing in the call graph.
    if (IsFusionComputation()) {
      return true;
    }
    // If we can't fixup the caller, then we can't remove the parameter.
    if (!computation_callers.has_value()) {
      return false;
    }
    std::vector<HloInstruction*> callers =
        (*computation_callers)(instruction->parent());
    if (callers.empty() && !instruction->parent()->IsEntryComputation()) {
      return false;
    }
    for (HloInstruction* caller : callers) {
      if (caller->opcode() != HloOpcode::kFusion &&
          caller->opcode() != HloOpcode::kCall &&
          caller->opcode() != HloOpcode::kAsyncStart) {
        // We don't handle callers with non-trivial control flow today.
        return false;
      }
    }
  }

  // All instruction generally are safe to remove.
  return true;
}

bool HloComputation::HasSideEffect() const {
  return absl::c_any_of(instructions(), [](const HloInstruction* instruction) {
    return instruction->HasSideEffect();
  });
}

bool HloComputation::IsMarkedAsDead(const HloInstruction* inst) {
  return inst->IsMarkedAsDead();
}

absl::Status HloComputation::RemoveInstructionAndUnusedOperands(
    HloInstruction* instruction,
    std::optional<absl::FunctionRef<void(HloInstruction*)>> cleanup,
    bool ignore_control_dependencies,
    std::optional<
        absl::FunctionRef<std::vector<HloInstruction*>(const HloComputation*)>>
        computation_callers,
    bool remove_dead_parameters_from_entry_computation) {
  TF_RET_CHECK(root_instruction() != instruction);
  TF_RET_CHECK(instruction->IsDead());
  if (instruction->opcode() == HloOpcode::kAfterAll) {
    for (const HloInstruction* operand : instruction->operands()) {
      const HloInstruction* source = operand;
      if (operand->opcode() == HloOpcode::kGetTupleElement) {
        source = operand->operand(0);
      }
      // Do not allow DCE to remove a sink `after-all` that is the sole consumer
      // of a side-effecting instruction's token (or its token GTE, which would
      // otherwise become dead and be deleted by the worklist below). However,
      // if `operand` has other users (`user_count() > 1`)—for example, when CSE
      // replaces a duplicate `after-all` with an equivalent representative that
      // shares the same operands—`operand` remains live and anchored, so the
      // redundant `after-all` is safe to remove.
      if (source->HasSideEffect() && operand->user_count() == 1) {
        return absl::OkStatus();
      }
    }
  }
  TF_RET_CHECK(IsSafelyRemovable(instruction, ignore_control_dependencies,
                                 computation_callers,
                                 remove_dead_parameters_from_entry_computation))
      << "Cannot remove instruction: " << instruction->ToString();
  // Remember the parent, in case we lose all references to it, in order to
  // clean up the callers.
  HloComputation* parent = instruction->parent();
  absl::flat_hash_set<HloInstruction*> removed;
  std::queue<HloInstruction*> worklist;
  worklist.push(instruction);
  std::vector<HloInstruction*> parameters_to_be_removed;
  while (!worklist.empty()) {
    HloInstruction* item = worklist.front();
    worklist.pop();

    if (removed.contains(item) || !item->IsDead() ||
        !IsSafelyRemovable(item, ignore_control_dependencies,
                           computation_callers,
                           remove_dead_parameters_from_entry_computation) ||
        (item->HasSideEffect() && item != instruction)) {
      continue;
    }
    if (ignore_control_dependencies) {
      ABSL_RETURN_IF_ERROR(item->SafelyDropAllControlDependencies());
    } else if (item->HasControlDependencies()) {
      continue;
    }

    for (HloInstruction* operand : item->mutable_operands()) {
      worklist.push(operand);
    }

    if (cleanup.has_value()) {
      (*cleanup)(item);
    }
    if (item->opcode() == HloOpcode::kParameter) {
      // We cannot remove a parameter directly, because it may cause a
      // renumbering of other parameters which may invalidate some of the
      // pointers in the worklist.
      parameters_to_be_removed.push_back(item);
    } else {
      ABSL_RETURN_IF_ERROR(RemoveInstruction(item));
    }
    removed.insert(item);
  }
  // Sort into decreasing order by parameter number, otherwise the renumbering
  // of parameters when one parameter is deleted will cause issues.
  absl::c_sort(parameters_to_be_removed,
               [](const HloInstruction* a, const HloInstruction* b) {
                 return a->parameter_number() > b->parameter_number();
               });
  std::vector<HloInstruction*> callers;
  if (!parameters_to_be_removed.empty()) {
    if (parent != nullptr && computation_callers.has_value()) {
      callers = (*computation_callers)(parent);
    }
    // We generally want to be using the call graph to determine who the caller
    // is, as this back pointer is very fragile, however its not reasonable to
    // expect every caller to be passing in the call graph.
    if (callers.empty() && FusionInstruction() != nullptr) {
      callers = {FusionInstruction()};
    }
  }
  const bool is_entry_computation = parent != nullptr &&
                                    parent->parent() != nullptr &&
                                    parent->IsEntryComputation();
  // Only attempt to remove parameters if we can fixup the caller.
  if (callers.empty() && !is_entry_computation) {
    return absl::OkStatus();
  }
  for (HloInstruction* param : parameters_to_be_removed) {
    int64_t parameter_number = param->parameter_number();
    ABSL_RETURN_IF_ERROR(RemoveParameter(parameter_number));
    for (HloInstruction* caller : callers) {
      // The caller could have been eagerly removed.
      if (caller->IsDead()) {
        continue;
      }
      auto operand = caller->mutable_operand(parameter_number);
      caller->RemoveOperandAt(parameter_number);
      // Another parameter of the caller may still read the operand.
      if (!absl::c_linear_search(caller->operands(), operand)) {
        caller->DetachFrom(operand);
      }
      // Cleanup operand shape embedded into the async-start shape.
      if (caller->opcode() == HloOpcode::kAsyncStart) {
        std::vector<Shape>* operand_shapes = caller->mutable_shape()
                                                 ->mutable_tuple_shapes(0)
                                                 ->mutable_tuple_shapes();
        operand_shapes->erase(operand_shapes->begin() + parameter_number);
      }
      if (operand->IsDead() &&
          operand->parent()->IsSafelyRemovable(
              operand, ignore_control_dependencies, computation_callers)) {
        ABSL_RETURN_IF_ERROR(
            operand->parent()->RemoveInstructionAndUnusedOperands(
                operand, cleanup, ignore_control_dependencies,
                computation_callers));
      }
    }
  }
  return absl::OkStatus();
}

absl::Status HloComputation::RemoveInstruction(HloInstruction* instruction) {
  return RemoveInstructionImpl(instruction, /*ignore_safety_check=*/false);
}

absl::Status HloComputation::ForceRemoveInstruction(
    HloInstruction* instruction) {
  return RemoveInstructionImpl(instruction, /*ignore_safety_check=*/true);
}

absl::Status HloComputation::RemoveInstructionImpl(HloInstruction* instruction,
                                                   bool ignore_safety_check) {
  TF_RET_CHECK(instruction != nullptr);
  TF_RET_CHECK(instruction->parent() == this)
      << "instruction " << instruction->name()
      << " does not belong to computation " << name();
  TF_RET_CHECK(!instruction->IsMarkedAsDead())
      << "instruction " << instruction->name() << " is already marked dead";

  VLOG(2) << "Removing instruction " << instruction << " "
          << instruction->name() << " from computation " << name();
  TF_RET_CHECK(ignore_safety_check || IsSafelyRemovable(instruction))
      << "cannot remove instruction: " << instruction->ToString();
  TF_RET_CHECK(instruction->IsDead()) << "instruction " << instruction->name()
                                      << " is live and cannot be removed";
  TF_RET_CHECK(instruction->control_predecessors().empty())
      << "instruction " << instruction->name()
      << " has control predecessors and cannot be removed";
  TF_RET_CHECK(instruction->control_successors().empty())
      << "instruction " << instruction->name()
      << " has control successors and cannot be removed";

  const int32_t local_id = instruction->local_id();
  TF_RET_CHECK(local_id >= 0 && local_id < instructions_.size())
      << "instruction " << instruction->name() << " has invalid local_id "
      << local_id;

  HloInstructionInfo* info = &instructions_[local_id];
  TF_RET_CHECK(info->inst() == instruction)
      << "instruction " << instruction->name()
      << " does not match entry at local_id " << local_id;

  if (instruction->opcode() == HloOpcode::kParameter) {
    const int64_t param_no = instruction->parameter_number();
    if (param_no >= 0 && param_no < param_instructions_.size() &&
        param_instructions_[param_no] == instruction) {
      param_instructions_[param_no] = nullptr;
    }
  }

  instruction->DetachFromOperandsAndUsers();
  // Clear all operands to avoid Null operands.
  instruction->RemoveAllOperands();
  instruction->ClearCalledComputations();
  instruction->MarkAsDead();
  instruction->set_parent(nullptr);

  // If this instruction is a constant, clear the literal eagerly instead of
  // waiting for the instruction to be deleted in Cleanup(). This greatly
  // reduces the peak heap memory during constant folding.
  if (auto constant = DynCast<HloConstantInstruction>(instruction)) {
    *constant->mutable_literal() = Literal();
  }
  // Leave a hole: this is no longer part of "instructions()"
  info->inst_ = nullptr;
  instruction->local_id_ = -1;
  instruction_count_--;

  to_be_deleted_.push_back(instruction);  // Takes ownership

  return absl::OkStatus();
}

void HloComputation::Cleanup() {
  if (to_be_deleted_.empty()) {
    return;
  }

  // Given that there are instructions to be deleted, there must be at least one
  // instruction not marked for deletion. Otherwise we have deleted *all*
  // instructions, which is probably a bug.
  DCHECK_GT(instruction_count(), 0);

  // Perform a stable compaction with the erase-remove idiom. We have to open
  // code it (instead of using std::erase(std::remove_if)) because we must
  // update the reverse mapping.
  auto is_marked_for_removal = [](const HloInstructionInfo& info) {
    return info.inst() == nullptr;
  };
  auto marked_it = absl::c_find_if(instructions_, is_marked_for_removal);
  DCHECK(marked_it < instructions_.end());
  for (auto it = marked_it + 1; it < instructions_.end(); ++it) {
    if (is_marked_for_removal(*it)) {
      continue;
    }
    // Update reverse mapping and overwrite the 'marked' entry.
    HloInstruction* unmarked_instruction = it->inst();
    // Changes the unique_id of the instruction due to recompaction.
    unmarked_instruction->local_id_ =
        std::distance(instructions_.begin(), marked_it);
    *marked_it++ = std::move(*it);
  }

  DCHECK(marked_it < instructions_.end());
  for (HloInstruction* marked_instruction : to_be_deleted_) {
    delete marked_instruction;
  }
  to_be_deleted_.clear();
  instructions_.resize(instruction_count());
  next_instruction_unique_id_ = instructions_.size();
}

void HloComputation::CanonicalizeLocalIds() {
  Cleanup();
  auto post_order = MakeInstructionPostOrder();
  std::vector<HloInstructionInfo> new_instructions;
  new_instructions.reserve(post_order.size());

  for (size_t i = 0; i < post_order.size(); ++i) {
    HloInstruction* inst = post_order[i];
    HloInstructionInfo info;
    info.inst_ = inst;
    info.opcode_ = inst->opcode();
    inst->local_id_ = i;
    new_instructions.push_back(info);
  }

  instructions_ = std::move(new_instructions);
  next_instruction_unique_id_ = instructions_.size();
}

void HloComputation::set_root_instruction(HloInstruction* new_root_instruction,
                                          bool accept_different_shape) {
  // The shape of the root (ignoring layout) is an invariant of the computation
  // for non-fusion cases.
  if (!IsFusionComputation() && !accept_different_shape) {
    CHECK(ShapeUtil::Compatible(new_root_instruction->shape(),
                                root_instruction_->shape()))
        << new_root_instruction->shape() << " is incompatible with "
        << root_instruction_->shape();
  }
  bool root_found = false;
  for (auto& instruction : instructions_) {
    if (new_root_instruction == instruction.get()) {
      root_found = true;
      break;
    }
  }
  DCHECK(root_found);

  if (parent() && parent()->has_entry_computation() &&
      parent()->entry_computation() == this) {
    if (!Shape::Equal().IgnoreLayout()(new_root_instruction->shape(),
                                       root_instruction_->shape()) &&
        !Shape::Equal().IgnoreLayout()(
            new_root_instruction->shape(),
            parent()->input_output_alias_config().shape()) &&
        !Shape::Equal().IgnoreLayout()(
            new_root_instruction->shape(),
            parent()->entry_computation_layout().result_shape())) {
      // Do not remove this CHECK. Hitting it means a pass or caller is about
      // to silently drop configured input/output aliases by changing the entry
      // root shape. Fix the caller to update or clear the alias configuration
      // explicitly instead of removing this check.
      CHECK(!parent()->input_output_alias_config().OutputHasAnyAlias())
          << "Cannot overwrite non-empty input_output_alias_config ("
          << parent()->input_output_alias_config().ToShortString()
          << ") when changing entry computation root from "
          << root_instruction_->ToString() << " to "
          << new_root_instruction->ToString();
      // Rebuild input output alias config now that we have a new output shape.
      parent()->input_output_alias_config() =
          HloInputOutputAliasConfig(new_root_instruction->shape());
    }
  }

  // `root_instruction_` can be equal to `new_root_instruction` and so it is
  // important that we call MarkAsNonRoot before calling MarkAsRoot.
  root_instruction_->MarkAsNonRoot();
  new_root_instruction->MarkAsRoot();
  root_instruction_ = new_root_instruction;
}

void HloComputation::ComputeInstructionPostOrder(
    HloInstruction* root, VisitMap& visited,
    std::vector<HloInstruction*>& post_order,
    std::vector<HloInstruction*>* dfs_stack_scratch) const {
  ForEachInstructionPostOrderImpl(
      [&post_order](HloInstruction* hlo) { post_order.push_back(hlo); }, root,
      visited, dfs_stack_scratch);
}

void HloComputation::ForEachInstructionPostOrderImpl(
    absl::FunctionRef<void(HloInstruction*)> func, HloInstruction* root,
    VisitMap& visited, std::vector<HloInstruction*>* dfs_stack_scratch) const {
  auto* dfs_stack = dfs_stack_scratch;
  dfs_stack->clear();

  // Pushes instruction to dfs stack only if it was not already processed.
  auto dfs_stack_push = [&](HloInstruction* instr) {
    VisitState state = visited.GetState(instr->local_id_);
    if (state != VisitState::kVisited) {
      dfs_stack->push_back(instr);
    }
  };

  dfs_stack_push(root);
  while (!dfs_stack->empty()) {
    HloInstruction* current = dfs_stack->back();
    DCHECK_EQ(current->parent(), this)
        << "Instruction " << current->name()
        << " is not in the current computation (" << name() << ").";

    VisitMap::Handle h = current->local_id_;
    VisitState state = visited.GetState(h);
    if (state == VisitState::kNew) {
      visited.SetState(h, VisitState::kVisiting);
    } else {
      dfs_stack->pop_back();
      if (state != VisitState::kVisited) {
        visited.SetState(h, VisitState::kVisited);
        func(current);
      }
      continue;
    }

    // Add the operands to the stack in reverse order so the first operand is
    // processed first. This will produce a more natural ordering and a nicer
    // result for things like HLO stringification.
    const HloInstruction::InstructionVector& operands = current->operands();
    absl::c_for_each(tsl::gtl::make_range(operands.rbegin(), operands.rend()),
                     dfs_stack_push);

    // Add control predecessors to the stack.
    absl::c_for_each(current->control_predecessors(), dfs_stack_push);
  }
}

std::vector<HloInstruction*> HloComputation::MakeInstructionPostOrderFrom(
    HloInstruction& postorder_root) const {
  std::vector<HloInstruction*> post_order;
  post_order.reserve(instruction_count());
  VisitMap visited(instructions_.size());

  std::vector<HloInstruction*> dfs_stack_scratch;
  dfs_stack_scratch.reserve(instruction_count());
  ComputeInstructionPostOrder(&postorder_root, visited, post_order,
                              &dfs_stack_scratch);
  return post_order;
}

std::vector<HloInstruction*> HloComputation::MakeInstructionPostOrder() const {
  std::vector<HloInstruction*> post_order;
  post_order.reserve(instruction_count());
  VisitMap visited(instructions_.size());
  std::vector<HloInstruction*> dfs_stack_scratch;
  dfs_stack_scratch.reserve(instruction_count());

  for (const auto& instruction : instructions()) {
    // We don't consider users outside any computation as real users. This can
    // happen when creating new instructions for replacement when cloning
    // computations.
    if (absl::c_all_of(instruction->users(), [](const HloInstruction* user) {
          return user->parent() == nullptr;
        })) {
      ComputeInstructionPostOrder(instruction, visited, post_order,
                                  &dfs_stack_scratch);
    }
  }
  CHECK_EQ(instruction_count(), post_order.size())
      << "number of instructions does not match post order size";
  return post_order;
}

std::vector<HloInstruction*>
HloComputation::MakeInstructionPostOrderWithReshapeFirst() const {
  std::vector<HloInstruction*> frontier_std;
  std::vector<HloInstruction*> frontier_reshapes;
  std::vector<HloInstruction*> sorted;
  absl::flat_hash_map<int64_t, uint32_t> visitations;
  sorted.reserve(instruction_count());
  visitations.reserve(instruction_count());

  auto pop_frontier_element = [&frontier_std, &frontier_reshapes]() mutable {
    // Because the result of this sort is going to be reverse, check for
    // Reshapes later, which we want to occur earlier in the final result
    if (!frontier_std.empty()) {
      HloInstruction* const to_return = frontier_std.back();
      frontier_std.pop_back();
      return to_return;
    }
    if (!frontier_reshapes.empty()) {
      HloInstruction* const to_return = frontier_reshapes.back();
      frontier_reshapes.pop_back();
      return to_return;
    }
    return static_cast<HloInstruction*>(nullptr);
  };

  auto add_to_frontier = [&frontier_std, &frontier_reshapes](
                             HloInstruction* const instruction_to_add) mutable {
    if (instruction_to_add->opcode() == HloOpcode::kReshape) {
      frontier_reshapes.push_back(instruction_to_add);
    } else {
      frontier_std.push_back(instruction_to_add);
    }
  };

  // Add all instructions with no users inside the computation, including the
  // root instruction
  bool found_root_instruction = false;
  for (HloInstruction* const inst : instructions()) {
    if (inst->user_count() == 0) {
      if (inst == root_instruction()) {
        found_root_instruction = true;
      }
      add_to_frontier(inst);
    }
  }
  CHECK(found_root_instruction);

  while (HloInstruction* const inst = pop_frontier_element()) {
    sorted.push_back(inst);
    for (HloInstruction* const child : inst->operands()) {
      // Will increment, or set to 1 if not present
      ++visitations[child->unique_id()];
      if (child->user_count() == visitations[child->unique_id()]) {
        add_to_frontier(child);
      }
    }
  }

  absl::c_reverse(sorted);
  CHECK_EQ(sorted.size(), instruction_count());
  return sorted;
}

void HloComputation::ForEachInstructionPostOrder(
    absl::FunctionRef<void(HloInstruction*)> func) const {
  VisitMap visited(instructions_.size());
  std::vector<HloInstruction*> dfs_stack_scratch;
  dfs_stack_scratch.reserve(instruction_count());
  for (const auto& instruction : instructions()) {
    // We don't consider users outside any computation as real users. This can
    // happen when creating new instructions for replacement when cloning
    // computations.
    if (absl::c_all_of(instruction->users(), [](const HloInstruction* user) {
          return user->parent() == nullptr;
        })) {
      ForEachInstructionPostOrderImpl(func, instruction, visited,
                                      &dfs_stack_scratch);
    }
  }
}

std::vector<HloComputation*> HloComputation::MakeEmbeddedComputationsList()
    const {
  absl::flat_hash_set<HloComputation*> visited;
  std::vector<HloComputation*> post_order;
  // The first element of the pair is the currently processed computation, the
  // second is iterator inside the instructions list of the computation that is
  // currently being processed.
  using ComputationIter =
      std::pair<HloComputation*, InstructionList::const_iterator>;
  std::stack<ComputationIter, absl::InlinedVector<ComputationIter, 8>> st;

  if (!HasCalledComputations()) {
    return {};
  }
  // We cannot directly push (this, instructions_.cbegin()) to the stack, as the
  // stack should contain only mutable computations. Also, we don't want to
  // include the computation itself in the list of embedded computations.
  for (const HloInstructionInfo& instruction : instructions_with_info()) {
    if (!HloInstruction::MightHaveCalledComputations(instruction.opcode())) {
      DCHECK(instruction->called_computations().empty());
      continue;
    }
    using PtrVec = PtrVec<HloComputation*>;
    auto process_called_computations = [&](const PtrVec& called_computations) {
      if (called_computations.empty()) {
        return;
      }
      // Put the called computations in reverse order onto the stack.
      // Otherwise we don't match the recursive enumeration of
      // computations, which processes the first called computation first.
      for (auto it = called_computations.rbegin();
           it != called_computations.rend(); ++it) {
        HloComputation* called_computation = *it;
        if (visited.insert(called_computation).second) {
          // If `called_computation` calls no other computations, push it with
          // its iterator already at `cend()` so the DFS loop below still emits
          // it in post-order without scanning its instructions.
          st.emplace(called_computation,
                     called_computation->HasCalledComputations()
                         ? called_computation->instructions_.cbegin()
                         : called_computation->instructions_.cend());
        }
      }
    };
    process_called_computations(instruction->called_computations());
    while (!st.empty()) {
      auto& [computation, instr_it] = st.top();
      if (instr_it == computation->instructions_.cend()) {
        post_order.push_back(computation);
        st.pop();
      } else if (instr_it->inst() == nullptr) {
        ++instr_it;
      } else {
        HloOpcode opcode = instr_it->opcode();
        HloInstruction* next_instruction = instr_it->get();
        ++instr_it;
        if (HloInstruction::MightHaveCalledComputations(opcode)) {
          process_called_computations(next_instruction->called_computations());
        } else {
          DCHECK(next_instruction->called_computations().empty());
        }
      }
    }
  }

  return post_order;
}

void HloComputation::Print(Printer* printer,
                           const HloPrintOptions& options) const {
  // Use post-order if order is not specified.
  Print(printer, options, /*instruction_order=*/{});
}

void HloComputation::Print(
    Printer* printer, const HloPrintOptions& options,
    absl::Span<const HloInstruction* const> instruction_order) const {
  const std::string tab(2 * options.indent_amount(), ' ');

  printer->Append(tab);

  if (options.print_computation_mode() ==
          HloPrintOptions::PrintComputationMode::kComputationWithEntryKeyword &&
      IsEntryComputation()) {
    printer->Append("ENTRY ");
  }

  if (!options.is_in_nested_computation()) {
    if (options.print_percent()) {
      printer->Append("%");
    }
    if (options.print_ids()) {
      // When print_ids() is false, exclude entry computation's name because it
      // includes and leads to non-deterministic fingerprint.
      printer->Append(name());
      printer->Append(" ");
    }
  }

  if (options.print_program_shape()) {
    ShapeUtil::PrintHumanString(printer,
                                ComputeProgramShape(options.print_ids()));
    printer->Append(" ");
  }
  printer->Append("{\n");

  {
    // Print the instructions in this computation.
    HloPrintOptions new_options =
        HloPrintOptions(options)
            .set_indent_amount(options.indent_amount() + 1)
            .set_is_in_nested_computation(true);

    CanonicalNameMap name_map;
    name_map.Reserve(instruction_count());
    auto print_one = [&](const HloInstruction* instruction) {
      DCHECK_EQ(this, instruction->parent());
      if (options.compact_gte() &&
          instruction->opcode() == HloOpcode::kGetTupleElement &&
          instruction != root_instruction_) {
        return;
      }
      // 2 more spaces than just 'tab' due to indent_amount()+1 above
      printer->Append(tab);
      printer->Append("  ");
      if (instruction == root_instruction_) {
        printer->Append("ROOT ");
      }
      instruction->PrintWithCanonicalNameMap(printer, new_options, &name_map);
      printer->Append("\n");
    };
    // Use post-order if order is not specified.
    if (instruction_order.empty()) {
      ForEachInstructionPostOrder(print_one);
    } else {
      for (const HloInstruction* const instruction : instruction_order) {
        print_one(instruction);
      }
    }
  }

  printer->Append(tab);
  printer->Append("}");
  if (options.print_ids() && !IsMainThread()) {
    // When print_ids() is false, exclude entry computation's thread name
    // because it includes and leads to non-deterministic fingerprint.
    printer->Append(", execution_thread=\"");
    printer->Append(execution_thread());
    printer->Append("\"");
  }
  if (options.print_backend_config() && has_backend_config()) {
    absl::string_view config = raw_backend_config_string();
    std::string sorted_config;
    if (options.sort_backend_config()) {
      sorted_config = SortJson(config).value_or(std::string(config));
      config = sorted_config;
    }
    printer->Append(", backend_config=");
    if (printer->is_hasher() || LexesAsJsonDict(config)) {
      printer->Append(config);
    } else {
      printer->Append("\"");
      printer->Append(absl::CEscape(config));
      printer->Append("\"");
    }
  }
  if (options.print_name_after_closing_brace() && instruction_count() > 5) {
    printer->Append(" // ");
    printer->Append(name());
  }
}

std::string HloComputation::ToString() const {
  return ToString(HloPrintOptions::Default());
}

std::string HloComputation::ToString(const HloPrintOptions& options) const {
  return ToString(options, MakeInstructionPostOrder());
}

std::string HloComputation::ToString(
    const HloPrintOptions& options,
    absl::Span<const HloInstruction* const> instruction_order) const {
  StringPrinter printer;
  Print(&printer, options, instruction_order);
  return std::move(printer).ToString();
}

absl::Cord HloComputation::ToCord(
    const HloPrintOptions& options,
    absl::Span<const HloInstruction* const> instruction_order) const {
  CordPrinter printer;
  Print(&printer, options, instruction_order);
  return std::move(printer).ToCord();
}

void HloComputation::ToProto(HloComputationProto* proto,
                             HloProtoOptions options) const {
  CHECK(unique_id_ != -1)
      << "This computation does not have a valid id. Please make sure the "
         "computation is inside a module before dumping it.";
  proto->set_id(unique_id_);
  proto->set_name(name_);
  proto->mutable_instructions()->Reserve(proto->instructions_size() +
                                         instruction_count());
  for (const HloInstruction* instruction : MakeInstructionPostOrder()) {
    instruction->ToProto(proto->add_instructions(), options);
  }
  proto->set_root_id(root_instruction()->unique_id());
  ComputeProgramShape().ToProto(*proto->mutable_program_shape());
  proto->set_is_fusion_computation(IsFusionComputation());
  proto->set_execution_thread(IsMainThread() ? ""
                                             : std::string(execution_thread()));
  if (has_backend_config()) {
    proto->set_backend_config(raw_backend_config_string());
  }
}

/* static */ absl::StatusOr<std::unique_ptr<HloComputation>>
HloComputation::CreateFromProto(
    const HloComputationProto& proto,
    const absl::flat_hash_map<int64_t, HloComputation*>& computation_map,
    bool prohibit_empty_literal, bool preserve_instruction_ids,
    absl::flat_hash_map<int64_t, int64_t>* id_remap_map,
    absl::Span<const std::shared_ptr<BackendConfigWrapper>> backend_configs) {
  // Instruction_map uses the ids of the instructions as defined in the proto.
  // The final instruction ids will change if preserve_instruction_ids is false.
  absl::flat_hash_map<int64_t, HloInstruction*> instruction_map;
  absl::flat_hash_map<HloInstruction*, int64_t> to_proto_id;
  std::vector<std::unique_ptr<HloInstruction>> instructions;

  if (preserve_instruction_ids) {
    // If preserve_instruction_ids is true, we need to reserve space for all
    // instructions in the proto, even if they are gaps to keep the condition
    // that instructions[instruction->local_id_] == instruction.
    const auto instruction_with_max_id = absl::c_max_element(
        proto.instructions(),
        [](const HloInstructionProto& a, const HloInstructionProto& b) {
          return HloInstruction::CalculateLocalId(a.id()) <
                 HloInstruction::CalculateLocalId(b.id());
        });
    int32_t max_proto_instruction_local_id =
        instruction_with_max_id == proto.instructions().end()
            ? 0
            : HloInstruction::CalculateLocalId(instruction_with_max_id->id());
    instructions.resize(max_proto_instruction_local_id + 1);
  }

  int64_t parameter_count = 0;

  for (const HloInstructionProto& instruction_proto : proto.instructions()) {
    ABSL_ASSIGN_OR_RETURN(
        std::unique_ptr<HloInstruction> instruction,
        HloInstruction::CreateFromProto(instruction_proto, instruction_map,
                                        computation_map, prohibit_empty_literal,
                                        backend_configs));
    if (instruction->opcode() == HloOpcode::kParameter) {
      parameter_count++;
    }

    int32_t local_proto_id =
        HloInstruction::CalculateLocalId(instruction_proto.id());

    TF_RET_CHECK(!instruction_map.contains(local_proto_id));
    instruction_map[local_proto_id] = instruction.get();
    to_proto_id[instruction.get()] = local_proto_id;
    if (preserve_instruction_ids) {
      // The instruction's id is the same as the index in the instructions
      // vector. This will be reproduced when placing the instruction in the
      // instructions vector.
      TF_RET_CHECK(instruction->local_id_ >= 0 &&
                   instruction->local_id_ < instructions.size())
          << "Instruction local id is out of bounds" << " Value is "
          << instruction->local_id_ << " and size is " << instructions.size();
      TF_RET_CHECK(instructions[instruction->local_id_] == nullptr)
          << "Instruction " << instruction->name() << " has duplicate local id "
          << instruction->local_id_;
      instructions[instruction->local_id_] = std::move(instruction);
    } else {
      // Instructions will be placed sequentially in the instructions vector.
      // The local id will be assigned sequentially starting from 0.
      instruction->local_id_ = instructions.size();
      if (id_remap_map != nullptr) {
        // When creating a new HloComputation from proto, the computation ids
        // are preserved.
        (*id_remap_map)[instruction_proto.id()] =
            HloInstruction::CalculateUniqueId(proto.id(),
                                              instruction->local_id_);
      }
      instructions.push_back(std::move(instruction));
    }
  }
  TF_RET_CHECK(proto.root_id() != -1);
  int32_t root_local_id = HloInstruction::CalculateLocalId(proto.root_id());
  TF_RET_CHECK(instruction_map.contains(root_local_id))
      << "Root instruction not found in instruction map";
  HloInstruction* root = instruction_map.at(root_local_id);

  // Check if each computation's instructions are unique in their local id
  // (lowers 32bits)
  absl::flat_hash_set<int32_t> instruction_local_ids;
  for (const auto& instruction : instructions) {
    // Since the instructions vector replicates the instructions from the proto
    // when preserve_instruction_ids is true, if there are any gaps in the
    // sequence of instruction ids in the proto, it will be represented as a
    // null instruction in the vector.
    if (instruction == nullptr && preserve_instruction_ids) {
      continue;
    }
    auto proto_id_it = to_proto_id.find(instruction.get());
    TF_RET_CHECK(proto_id_it != to_proto_id.end())
        << "Instruction not found in to_proto_id map: " << instruction->name()
        << " local_id: " << instruction->local_id_;
    int32_t local_id_from_proto =
        HloInstruction::CalculateLocalId(proto_id_it->second);

    if (preserve_instruction_ids) {
      TF_RET_CHECK(local_id_from_proto == instruction->local_id_)
          << "Instruction has different local id from proto: proto: "
          << local_id_from_proto << " vs local: " << instruction->local_id_;
    }

    TF_RET_CHECK(instruction_local_ids.insert(instruction->local_id_).second)
        << "Instruction " << instruction->name()
        << " has duplicate internal unique id " << instruction->local_id_;
  }
  ABSL_RETURN_IF_ERROR([&]() -> absl::Status {
    std::vector<bool> parameters_seen(parameter_count);
    int parameters_seen_count = 0;
    for (auto& instruction : instructions) {
      if (instruction == nullptr) {
        continue;
      }
      if (instruction->opcode() == HloOpcode::kParameter) {
        int64_t param_no = instruction->parameter_number();
        TF_RET_CHECK(param_no >= 0 && param_no < parameter_count)
            << "Invalid parameter number. Expected [0, " << parameter_count
            << "), got " << param_no;
        TF_RET_CHECK(!parameters_seen[param_no])
            << "Parameter number " << param_no
            << " already allocated in this computation";
        parameters_seen[param_no] = true;
        parameters_seen_count++;
      }
    }
    TF_RET_CHECK(parameters_seen_count == parameter_count)
        << "Not all parameters in range [0, " << parameter_count
        << ") were referenced";
    return absl::OkStatus();
  }());

  // Because we have formed the instructions vector manually, we can have the
  // creator of the HLO computation assume the instructions vector is well
  // formed and that the instruction ids are consistent. Will also assume that
  // instructions[instruction->local_id_] == instruction.
  auto computation = absl::WrapUnique(
      new HloComputation(proto.name(), parameter_count, &instructions, root,
                         /*preserve_instruction_ids=*/true));
  computation->SetUniqueIdHelper(proto.id());
  if (!proto.execution_thread().empty()) {
    computation->SetExecutionThread(proto.execution_thread());
  }
  if (!proto.backend_config().empty()) {
    computation->set_raw_backend_config_string(proto.backend_config());
  }
  return computation;
}

void HloComputation::AppendInstructionsIntoCalledComputation(
    absl::Span<HloInstruction* const> instructions_to_append,
    HloInstruction* caller) {
  HloInstruction* root = instructions_to_append.front();
  CHECK_OK(caller->CopyAllControlDepsFrom(root));
  CHECK_OK(root->DropAllControlDeps());
  CHECK_OK(root->ReplaceAllUsesWith(caller));
  if (root == root_instruction()) {
    set_root_instruction(caller);
  }
  CHECK_OK(RemoveInstruction(root));
  absl::Span<HloInstruction* const> remaining_instructions =
      instructions_to_append.subspan(1);
  for (HloInstruction* instruction : remaining_instructions) {
    caller->AppendInstructionIntoCalledComputation(instruction);
    if (instruction->IsDead()) {
      CHECK_OK(RemoveInstruction(instruction));
    }
  }
}

HloInstruction* HloComputation::CreateFusionInstruction(
    absl::Span<HloInstruction* const> instructions_to_fuse,
    HloInstruction::FusionKind fusion_kind) {
  HloInstruction* root = instructions_to_fuse.front();
  HloInstruction* fusion_instruction = AddInstruction(
      HloInstruction::CreateFusion(root->shape(), fusion_kind, root));
  AppendInstructionsIntoCalledComputation(instructions_to_fuse,
                                          fusion_instruction);
  return fusion_instruction;
}

HloInstruction* HloComputation::CreateCallInstruction(
    absl::Span<HloInstruction* const> instructions_to_call) {
  HloInstruction* root = instructions_to_call.front();
  HloInstruction* call_instruction = AddInstruction(
      HloInstruction::CreateCall(root->shape(), root), root->name());
  AppendInstructionsIntoCalledComputation(instructions_to_call,
                                          call_instruction);
  return call_instruction;
}

HloInstruction* HloComputation::CreateCompositeCallInstruction(
    absl::Span<HloInstruction* const> instructions_to_call,
    const std::string& name, const std::string& attributes, int64_t version) {
  HloInstruction* root = instructions_to_call.front();
  HloInstruction* call_instruction =
      AddInstruction(HloInstruction::CreateCompositeCall(
                         root->shape(), root, name, attributes, version),
                     root->name());
  AppendInstructionsIntoCalledComputation(instructions_to_call,
                                          call_instruction);
  return call_instruction;
}

absl::StatusOr<HloInstruction*> HloComputation::CreateAsyncInstructions(
    HloInstruction* instruction, absl::Span<const Shape> context_shapes,
    absl::string_view async_execution_thread, bool replace,
    bool override_names) {
  HloInstruction* async_start;
  HloInstruction* async_done;
  if (instruction->opcode() == HloOpcode::kCopy) {
    // Until the async ops are unified, add specialized support for copy here.
    // TODO(b/319466176): Remove this special case once this bug is complete.
    // Note that CopyStart/CopyDone uses (dest_shape, src_shape, context)
    // convention while async-start/async-done uses ((src_shapes), dest_shape,
    // context).
    std::vector<Shape> context_shapes_tuple;
    context_shapes_tuple.reserve(context_shapes.size() + 2);
    Shape instruction_shape_destination = instruction->shape();
    context_shapes_tuple.push_back(instruction_shape_destination);
    Shape instruction_shape_source = instruction->operand(0)->shape();
    context_shapes_tuple.push_back(instruction_shape_source);
    context_shapes_tuple.insert(context_shapes_tuple.end(),
                                context_shapes.begin(), context_shapes.end());

    async_start = AddInstruction(HloInstruction::CreateCopyStart(
        ShapeUtil::MakeTupleShape(context_shapes_tuple),
        instruction->mutable_operand(0)));
    async_done = AddInstruction(HloInstruction::CreateUnary(
        instruction_shape_destination, HloOpcode::kCopyDone, async_start));
  } else {
    Builder builder("async_computation");
    std::vector<HloInstruction*> parameters(instruction->operand_count());
    std::vector<Shape> parameter_shapes(instruction->operand_count());
    for (int i = 0; i < instruction->operand_count(); ++i) {
      const Shape& parameter_shape = instruction->operand(i)->shape();
      parameters[i] = builder.AddInstruction(HloInstruction::CreateParameter(
          i, parameter_shape, absl::StrCat("param_", i)));
      parameter_shapes[i] = parameter_shape;
    }
    HloInstruction* root = builder.AddInstruction(
        instruction->CloneWithNewOperands(instruction->shape(), parameters));
    if (override_names) {
      parent()->SetAndUniquifyInstrName(
          root, absl::StrCat(instruction->name(), ".cloned"));
    }
    HloComputation* async_computation =
        parent_->AddEmbeddedComputation(builder.Build(root));
    std::vector<Shape> start_shapes;
    start_shapes.reserve(2 + context_shapes.size());
    start_shapes.push_back(ShapeUtil::MakeTupleShape(parameter_shapes));
    start_shapes.push_back(root->shape());
    start_shapes.insert(start_shapes.end(), context_shapes.begin(),
                        context_shapes.end());
    async_start = AddInstruction(HloInstruction::CreateAsyncStart(
        ShapeUtil::MakeTupleShape(start_shapes), instruction->operands(),
        async_computation, async_execution_thread));
    async_done = AddInstruction(
        HloInstruction::CreateAsyncDone(root->shape(), async_start));
    if (override_names) {
      parent()->SetAndUniquifyInstrName(
          async_start, absl::StrCat(root->name(), ".call-start"));
      parent()->SetAndUniquifyInstrName(
          async_done, absl::StrCat(root->name(), ".call-done"));
    }
  }
  async_start->set_metadata(instruction->metadata());
  async_start->CopyBackendConfigFrom(instruction);
  async_done->set_metadata(instruction->metadata());
  async_done->CopyBackendConfigFrom(instruction);
  for (HloInstruction* control_pred : instruction->control_predecessors()) {
    ABSL_RETURN_IF_ERROR(control_pred->AddControlDependencyTo(async_start));
  }
  for (HloInstruction* control_successor : instruction->control_successors()) {
    ABSL_RETURN_IF_ERROR(async_done->AddControlDependencyTo(control_successor));
  }

  if (replace) {
    ABSL_RETURN_IF_ERROR(instruction->DropAllControlDeps());
    ABSL_RETURN_IF_ERROR(ReplaceInstruction(instruction, async_done));
  }
  return async_done;
}

absl::StatusOr<HloInstruction*> HloComputation::ReplaceWithSyncVariant(
    HloInstruction* async_start, HloInstruction* async_done) {
  HloInstruction* sync_instruction = nullptr;

  const HloOpcode async_start_op = async_start->opcode();
  switch (async_start_op) {
    case HloOpcode::kAllReduceStart: {
      auto* async_ar = Cast<HloAllReduceInstruction>(async_start);
      sync_instruction = AddInstruction(HloInstruction::CreateAllReduce(
          async_done->shape(), async_ar->operands(), async_ar->to_apply(),
          async_ar->device_list(), async_ar->constrain_layout(),
          async_ar->channel_id(), async_ar->use_global_device_ids()));
      break;
    }
    case HloOpcode::kAllGatherStart: {
      auto* async_ag = Cast<HloAllGatherInstruction>(async_start);
      sync_instruction = AddInstruction(HloInstruction::CreateAllGather(
          async_done->shape(), async_ag->operands(),
          async_ag->all_gather_dimension(), async_ag->device_list(),
          async_ag->constrain_layout(), async_ag->channel_id(),
          async_ag->use_global_device_ids()));
      break;
    }
    case HloOpcode::kCollectivePermuteStart: {
      auto* async_cp = Cast<HloCollectivePermuteInstruction>(async_start);
      if (async_cp->inplace()) {
        sync_instruction =
            AddInstruction(HloInstruction::CreateCollectivePermute(
                async_done->shape(), async_cp->mutable_operand(0),
                async_cp->mutable_operand(1), async_cp->mutable_operand(2),
                async_cp->mutable_operand(3), async_cp->source_target_pairs(),
                async_cp->dynamic_slice_sizes_list(), async_cp->channel_id()));
      } else {
        sync_instruction =
            AddInstruction(HloInstruction::CreateCollectivePermute(
                async_done->shape(), async_cp->operands(),
                async_cp->source_target_pairs(), async_cp->channel_id()));
      }
      break;
    }
    case HloOpcode::kAsyncStart: {
      auto* as_start = Cast<HloAsyncInstruction>(async_start);
      HloInstruction* wrapped = as_start->async_wrapped_instruction();
      sync_instruction = AddInstruction(wrapped->CloneWithNewOperands(
          async_done->shape(), as_start->operands()));
      break;
    }
    default:
      return Internal("Unexpected async start op %s",
                      HloOpcodeString(async_start->opcode()));
  }

  sync_instruction->set_metadata(async_start->metadata());
  sync_instruction->CopyBackendConfigFrom(async_start);
  FrontendAttributes fas = async_done->frontend_attributes();
  sync_instruction->set_frontend_attributes(fas);

  HloInstruction* final_result = sync_instruction;
  if (async_done->operand(0) != async_start) {
    auto forward_path = hlo_instruction_utils::async::TraceDataflowPath(
        async_done, async_start);
    if (!forward_path.has_value()) {
      return Internal("Could not trace from async done %s to async start %s",
                      async_done->name(), async_start->name());
    }
    ABSL_ASSIGN_OR_RETURN(final_result,
                          hlo_instruction_utils::async::PropagateDataflow(
                              *forward_path, sync_instruction));
  }

  ABSL_RETURN_IF_ERROR(async_done->ReplaceAllUsesWith(final_result));

  // Copy control dependencies.
  //
  // For simplicity, we throw away all control successors of a start and all
  // control predecessors of a done. However, the only control dependencies we
  // cannot respect are those that schedule an operation to run between a start
  // and done.
  for (HloInstruction* pred : async_start->control_predecessors()) {
    ABSL_RETURN_IF_ERROR(pred->AddControlDependencyTo(sync_instruction));
  }
  for (HloInstruction* succ : async_done->control_successors()) {
    ABSL_RETURN_IF_ERROR(final_result->AddControlDependencyTo(succ));
  }
  if (!async_start->control_successors().empty()) {
    LOG(WARNING) << "Async start " << async_start->name()
                 << " is being replaced by a synchronous op, but it has "
                    "control successors. These dependencies are being dropped";
  }
  if (!async_done->control_predecessors().empty()) {
    LOG(WARNING)
        << "Async done " << async_done->name()
        << " is being replaced by a synchronous op, but it has "
           "control predecessors. These dependencies are being dropped";
  }
  ABSL_RETURN_IF_ERROR(async_start->DropAllControlDeps());
  ABSL_RETURN_IF_ERROR(async_done->DropAllControlDeps());

  return sync_instruction;
}

absl::Status HloComputation::ReplaceAsyncInstructionsWithSync(
    absl::Span<const std::pair<HloInstruction*, HloInstruction*>> async_pairs) {
  absl::flat_hash_map<HloInstruction*, HloInstruction*> replaced_ops;
  for (auto& [async_start, async_done] : async_pairs) {
    ABSL_ASSIGN_OR_RETURN(HloInstruction * sync,
                          ReplaceWithSyncVariant(async_start, async_done));
    replaced_ops[async_start] = nullptr;
    replaced_ops[async_done] = sync;
  }

  // Update schedule, if there is one.
  if (parent_ != nullptr && parent_->has_schedule() &&
      parent_->schedule().is_computation_scheduled(this)) {
    const HloInstructionSequence& sequence = parent_->schedule().sequence(this);
    std::vector<HloInstruction*> new_sequence;
    new_sequence.reserve(sequence.size());
    for (HloInstruction* instr : sequence.instructions()) {
      auto it = replaced_ops.find(instr);
      if (it != replaced_ops.end()) {
        if (it->second != nullptr) {
          new_sequence.push_back(it->second);
        }
      } else {
        new_sequence.push_back(instr);
      }
    }
    parent_->schedule().set_sequence(this, new_sequence);
  }

  // Remove the replaced async instructions and their unused operands.
  for (const auto& pair : async_pairs) {
    // Explicit locals rather than a structured binding: lambdas capturing
    // structured bindings require C++20, and OSS XLA builds as C++17.
    HloInstruction* async_start = pair.first;
    HloInstruction* async_done = pair.second;
    bool is_async_start_removed = false;
    auto track_async_start_removed = [&](const HloInstruction* instr) {
      is_async_start_removed |= instr == async_start;
    };
    ABSL_RETURN_IF_ERROR(RemoveInstructionAndUnusedOperands(
        async_done, track_async_start_removed));
    if (!is_async_start_removed) {
      ABSL_RETURN_IF_ERROR(RemoveInstruction(async_start));
    }
  }

  return absl::OkStatus();
}

absl::StatusOr<HloInstruction*> HloComputation::DeepCopyHelper(
    HloInstruction* instruction, ShapeIndex* index,
    absl::FunctionRef<HloInstruction*(HloInstruction* leaf,
                                      const ShapeIndex& leaf_index,
                                      HloComputation* computation)>
        copy_leaf) {
  if (instruction->shape().IsTuple()) {
    std::vector<HloInstruction*> elements;
    for (int64_t i = 0; i < ShapeUtil::TupleElementCount(instruction->shape());
         i++) {
      HloInstruction* gte =
          AddInstruction(HloInstruction::CreateGetTupleElement(
              ShapeUtil::GetTupleElementShape(instruction->shape(), i),
              instruction, i));

      index->push_back(i);
      ABSL_ASSIGN_OR_RETURN(HloInstruction * element,
                            DeepCopyHelper(gte, index, copy_leaf));
      elements.push_back(element);
      index->pop_back();
    }
    return AddInstruction(HloInstruction::CreateTuple(elements));
  }
  if (instruction->shape().IsToken()) {
    // Tokens have no on-device representation and cannot be copied. Pass
    // through transparently.
    return instruction;
  }

  HloInstruction* copy = copy_leaf(instruction, *index, this);
  // We shouldn't copy buffers.
  TF_RET_CHECK(instruction->shape().IsArray() ||
               (instruction->shape().IsBuffer() && copy == instruction));
  return copy;
}

absl::StatusOr<HloInstruction*> HloComputation::DeepCopyInstruction(
    HloInstruction* instruction, const ShapeTree<bool>* indices_to_copy,
    ShapeTree<HloInstruction*>* copies_added) {
  if (instruction->parent() != this) {
    return FailedPrecondition(
        "Can't deep copy instruction %s: instruction is not in computation %s",
        instruction->name(), name());
  }
  if (indices_to_copy != nullptr &&
      !ShapeUtil::Compatible(instruction->shape(), indices_to_copy->shape())) {
    return FailedPrecondition(
        "Can't deep copy instruction %s: given shape tree of indices to copy "
        "has incompatible shapes: %s vs. %s",
        instruction->name(), ShapeUtil::HumanString(instruction->shape()),
        ShapeUtil::HumanString(indices_to_copy->shape()));
  }

  ShapeIndex index;
  auto copy_leaf = [indices_to_copy, copies_added](
                       HloInstruction* leaf, const ShapeIndex& leaf_index,
                       HloComputation* computation) {
    if (indices_to_copy == nullptr || indices_to_copy->element(leaf_index)) {
      HloInstruction* copy = computation->AddInstruction(
          HloInstruction::CreateUnary(leaf->shape(), HloOpcode::kCopy, leaf));
      if (copies_added != nullptr) {
        *copies_added->mutable_element(leaf_index) = copy;
      }
      return copy;
    }
    // Elements which are not to be copied are passed through
    // transparently.
    return leaf;
  };
  return DeepCopyHelper(instruction, &index, copy_leaf);
}

absl::StatusOr<HloInstruction*>
HloComputation::DeepCopyInstructionWithCustomCopier(
    HloInstruction* instruction,
    absl::FunctionRef<HloInstruction*(HloInstruction* leaf,
                                      const ShapeIndex& leaf_index,
                                      HloComputation* computation)>
        copy_leaf) {
  if (instruction->parent() != this) {
    return FailedPrecondition(
        "Can't deep copy instruction %s: instruction is not in computation %s",
        instruction->name(), name());
  }
  ShapeIndex index;
  return DeepCopyHelper(instruction, &index, copy_leaf);
}

ProgramShape HloComputation::ComputeProgramShape(bool include_ids) const {
  ProgramShape program_shape;

  for (auto* param_instruction : param_instructions_) {
    program_shape.AddParameter(
        param_instruction->shape(),
        std::string(PrintName(param_instruction->name(), include_ids)));
  }
  *program_shape.mutable_result() = root_instruction_->shape();

  return program_shape;
}

bool HloComputation::EqualInternal(
    const HloComputation& other, bool is_layout_sensitive,
    std::optional<
        absl::FunctionRef<bool(const HloComputation*, const HloComputation*)>>
        computations_comparator,
    bool ignore_channel_id_values, bool ignore_execution_thread) const {
  if (this == &other) {
    return true;
  }
  if (num_parameters() != other.num_parameters()) {
    // There are situations where the number of parameters matters, even if
    // some of them are unused, and the computations are otherwise equivalent.
    return false;
  }
  if (!ignore_execution_thread &&
      execution_thread() != other.execution_thread()) {
    return false;
  }

  // To avoid stack overflow with deeply nested subcomputations (b/123082518),
  // we compare computations iteratively using a worklist rather than recursion.
  std::vector<std::pair<const HloComputation*, const HloComputation*>>
      computation_worklist;
  absl::flat_hash_set<std::pair<const HloComputation*, const HloComputation*>>
      visited_computations;

  computation_worklist.push_back({this, &other});
  visited_computations.insert({this, &other});

  auto enqueue_subcomputations = [&](const HloComputation* a,
                                     const HloComputation* b) {
    if (a == b) {
      return true;
    }
    if (a->num_parameters() != b->num_parameters()) {
      return false;
    }
    if (!ignore_execution_thread &&
        a->execution_thread() != b->execution_thread()) {
      return false;
    }
    if (visited_computations.insert({a, b}).second) {
      computation_worklist.push_back({a, b});
    }
    return true;
  };

  auto comp_eq = computations_comparator.value_or(enqueue_subcomputations);
  constexpr auto operands_eq = [](const HloInstruction*,
                                  const HloInstruction*) { return true; };

  while (!computation_worklist.empty()) {
    const auto [comp1, comp2] = computation_worklist.back();
    computation_worklist.pop_back();

    absl::flat_hash_set<std::pair<const HloInstruction*, const HloInstruction*>>
        visited_instructions;
    std::vector<std::pair<const HloInstruction*, const HloInstruction*>>
        instruction_worklist;

    instruction_worklist.push_back(
        {comp1->root_instruction(), comp2->root_instruction()});

    while (!instruction_worklist.empty()) {
      const auto [inst1, inst2] = instruction_worklist.back();
      instruction_worklist.pop_back();

      if (!visited_instructions.insert({inst1, inst2}).second) {
        continue;
      }

      bool identical_ignoring_operands =
          ignore_channel_id_values
              ? inst1->IdenticalIgnoringChannelIdValues(
                    *inst2, operands_eq, comp_eq, is_layout_sensitive)
              : inst1->Identical(*inst2, operands_eq, comp_eq,
                                 is_layout_sensitive);
      if (!identical_ignoring_operands) {
        return false;
      }
      for (int64_t i = 0; i < inst1->operand_count(); ++i) {
        instruction_worklist.push_back({inst1->operand(i), inst2->operand(i)});
      }
    }
  }

  return true;
}

absl::Status HloComputation::ReplaceWithNewInstruction(
    HloInstruction* old_instruction,
    std::unique_ptr<HloInstruction> new_instruction, bool preserve_sharding,
    bool relay_control_dependency, bool remove_unused_operands,
    bool preserve_frontend_attributes) {
  ABSL_ASSIGN_OR_RETURN(
      bool changed,
      ReplaceInstruction(
          old_instruction, AddInstruction(std::move(new_instruction)),
          /*preserve_sharding=*/preserve_sharding,
          /*relay_control_dependency=*/relay_control_dependency,
          /*remove_unused_operands=*/remove_unused_operands,
          /*preserve_frontend_attributes=*/preserve_frontend_attributes));
  DCHECK(changed);
  return absl::OkStatus();
}

absl::Status HloComputation::ReplaceWithNewEntryComputationParameter(
    HloInstruction* old_instruction,
    std::unique_ptr<HloInstruction> new_instruction) {
  return ReplaceInstruction(old_instruction, AddEntryComputationParameter(
                                                 std::move(new_instruction)));
}

absl::StatusOr<bool> HloComputation::ReplaceInstruction(
    HloInstruction* old_instruction, HloInstruction* new_instruction,
    bool preserve_sharding, bool relay_control_dependency,
    bool remove_unused_operands, bool preserve_frontend_attributes) {
  TF_RET_CHECK(
      ShapeUtil::Compatible(old_instruction->shape(), new_instruction->shape()))
      << absl::StreamFormat(
             "\"%s\" (%s) vs \"%s\" (%s)", old_instruction->name(),
             old_instruction->shape().ToString(/*print_layout=*/true),
             new_instruction->name(),
             new_instruction->shape().ToString(/*print_layout=*/true));
  return ReplaceInstructionWithDifferentShape(
      old_instruction, new_instruction, preserve_sharding,
      relay_control_dependency, remove_unused_operands,
      preserve_frontend_attributes);
}

absl::Status HloComputation::ReplaceInstruction(
    HloInstruction* old_instruction, HloInstruction* new_instruction) {
  ABSL_ASSIGN_OR_RETURN(bool changed,
                        ReplaceInstruction(old_instruction, new_instruction,
                                           /*preserve_sharding=*/false));
  DCHECK(changed);
  return absl::OkStatus();
}

absl::StatusOr<bool> HloComputation::ReplaceInstructionWithDifferentShape(
    HloInstruction* old_instruction, HloInstruction* new_instruction,
    bool preserve_sharding, bool relay_control_dependency,
    bool remove_unused_operands, bool preserve_frontend_attributes) {
  if (preserve_sharding && new_instruction->has_sharding() &&
      old_instruction->has_sharding() &&
      !new_instruction->has_compatible_sharding(old_instruction)) {
    VLOG(10) << "Skipping replacement due to incompatible sharding";
    return false;
  }
  if (relay_control_dependency) {
    ABSL_RETURN_IF_ERROR(
        new_instruction->CopyAllControlDepsFrom(old_instruction));
    ABSL_RETURN_IF_ERROR(old_instruction->DropAllControlDeps());
  } else if (old_instruction->HasControlDependencies()) {
    VLOG(10) << "Skipping replacement because old instruction has "
                "control dependencies";
    return false;
  }
  VLOG(10) << "transformed " << old_instruction->ToString() << " to "
           << new_instruction->ToString();
  // Try to add metadata for HLO instructions that are created to replace
  // existing HLO instructions (e.g. during optimizations). The assumption is
  // that the old instruction and the new instruction would perform the same
  // function, and that they would be correlated to the same TF op. This might
  // not always be correct since HLO optimizations can cross TF op boundaries.
  // But still this seems to be better than nothing.
  bool overwrite_op_name = new_instruction->metadata().op_name().empty() &&
                           !old_instruction->metadata().op_name().empty();
  if (overwrite_op_name) {
    new_instruction->set_metadata(old_instruction->metadata());
  } else if (!new_instruction->metadata().has_metadata_payload() &&
             old_instruction->metadata().has_metadata_payload()) {
    *new_instruction->mutable_metadata().mutable_metadata_payload() =
        old_instruction->metadata().metadata_payload();
  }
  // Frontend attributes describe the replaced computation, so they must not
  // flow backward onto an existing operand of the old instruction (e.g. when a
  // no-op is forwarded to its operand): that operand is computed upstream and
  // may feed other users.
  if (preserve_frontend_attributes &&
      new_instruction->frontend_attributes().map().empty() &&
      !absl::c_linear_search(old_instruction->operands(), new_instruction)) {
    new_instruction->set_frontend_attributes(
        old_instruction->frontend_attributes());
  }

  new_instruction->CopyOriginalValue(old_instruction);

  // Like the metadata above, if the user didn't specify any sharding
  // information on the new instruction we should copy the old sharding
  // information (if any).
  if (!new_instruction->has_sharding()) {
    new_instruction->copy_sharding(old_instruction);
  }

  ABSL_RETURN_IF_ERROR(
      old_instruction->ReplaceAllUsesWithDifferentShape(new_instruction));

  // Preserve the old instruction's name if the new and old instruction have the
  // same opcode.  This makes it easier to follow instructions as they're
  // mutated through passes.
  if (old_instruction->opcode() == new_instruction->opcode() &&
      (old_instruction->opcode() != HloOpcode::kCustomCall ||
       old_instruction->custom_call_target() ==
           new_instruction->custom_call_target())) {
    new_instruction->SetAndSanitizeName(old_instruction->name());
  }
  if (remove_unused_operands) {
    ABSL_RETURN_IF_ERROR(RemoveInstructionAndUnusedOperands(
        old_instruction, /*cleanup=*/std::nullopt,
        /*ignore_control_dependencies=*/relay_control_dependency));
  } else {
    ABSL_RETURN_IF_ERROR(RemoveInstruction(old_instruction));
  }
  return true;
}

absl::Status HloComputation::ReplaceInstructionWithDifferentShape(
    HloInstruction* old_instruction, HloInstruction* new_instruction) {
  ABSL_ASSIGN_OR_RETURN(bool changed, ReplaceInstructionWithDifferentShape(
                                          old_instruction, new_instruction,
                                          /*preserve_sharding=*/false));
  DCHECK(changed);
  return absl::OkStatus();
}

std::vector<HloInstruction*> HloComputation::CollectUnreachableRoots() const {
  std::vector<HloInstruction*> unreachable_roots;
  for (auto* instruction : instructions()) {
    if (instruction->IsDead() && instruction->control_successors().empty()) {
      unreachable_roots.push_back(instruction);
    }
  }
  VLOG(3) << "Unreachable roots:"
          << absl::StrJoin(unreachable_roots, "\n\t",
                           [](std::string* out, const HloInstruction* hlo) {
                             absl::StrAppend(out, hlo->ToString());
                           });
  return unreachable_roots;
}

absl::Status HloComputation::AcceptWithOperandOrder(
    DfsHloVisitor* visitor,
    const HloInstruction::CompareFunction& operand_order) const {
  // Visit unreachable roots. Beware that the visitor might delete the currently
  // visited root, which would invalidate iterators if the unreachable roots
  // weren't computed ahead of time.
  for (HloInstruction* root : CollectUnreachableRoots()) {
    ABSL_RETURN_IF_ERROR(
        root->AcceptWithOperandOrder(visitor, operand_order,
                                     /*call_finish_visit=*/false));
  }
  // Visit the computation root instruction last.
  return root_instruction()->AcceptWithOperandOrder(visitor, operand_order,
                                                    /*call_finish_visit=*/true);
}

std::unique_ptr<HloComputation> HloComputation::Clone(
    const std::string& suffix, HloCloneContext* context) {
  return CloneWithReplacements(
      /*replacements=*/nullptr,
      /*extra_parameters=*/{}, context, suffix);
}

std::pair<std::unique_ptr<HloComputation>, std::vector<HloInstruction*>>
HloComputation::CloneWithSchedule(const std::string& suffix,
                                  HloCloneContext* context) {
  return CloneWithScheduleAndReplacements(
      /*replacements=*/nullptr,
      /*extra_parameters=*/{}, context, suffix);
}

std::unique_ptr<HloComputation> HloComputation::CloneWithReplacementPairs(
    std::pair<const HloInstruction*, std::unique_ptr<HloInstruction>> r1,
    HloCloneContext* context, const std::string& suffix) {
  absl::flat_hash_map<const HloInstruction*, std::unique_ptr<HloInstruction>>
      replacements;
  replacements.emplace(std::move(r1));
  return CloneWithReplacements(&replacements, /*extra_parameters=*/{}, context,
                               suffix);
}

std::unique_ptr<HloComputation> HloComputation::CloneWithReplacementPairs(
    std::pair<const HloInstruction*, std::unique_ptr<HloInstruction>> r1,
    std::pair<const HloInstruction*, std::unique_ptr<HloInstruction>> r2,
    HloCloneContext* context, const std::string& suffix) {
  absl::flat_hash_map<const HloInstruction*, std::unique_ptr<HloInstruction>>
      replacements;
  replacements.emplace(std::move(r1));
  replacements.emplace(std::move(r2));
  return CloneWithReplacements(&replacements, /*extra_parameters=*/{}, context,
                               suffix);
}

std::unique_ptr<HloComputation> HloComputation::CloneWithReplacementPairs(
    std::pair<const HloInstruction*, std::unique_ptr<HloInstruction>> r1,
    std::pair<const HloInstruction*, std::unique_ptr<HloInstruction>> r2,
    std::pair<const HloInstruction*, std::unique_ptr<HloInstruction>> r3,
    HloCloneContext* context, const std::string& suffix) {
  absl::flat_hash_map<const HloInstruction*, std::unique_ptr<HloInstruction>>
      replacements;
  replacements.emplace(std::move(r1));
  replacements.emplace(std::move(r2));
  replacements.emplace(std::move(r3));
  return CloneWithReplacements(&replacements, /*extra_parameters=*/{}, context,
                               suffix);
}

namespace {

// Sorts unordered_instructions according to the order of ordered_instructions,
// using MappedPtrContainerSorter. context and replace are used to map
// instructions in ordered_instructions to instructions in
// unordered_instructions. Unmapped parameter instructions are placed just after
// the last parameter instruction in the sorted mapped instruction order. All
// other mapped instructions are placed at the end.
template <typename OrderedInstructionPtr, typename UnorderedInstructionPtr>
void SortClonedInstructions(
    const HloCloneContext& context,
    absl::FunctionRef<const HloInstruction*(const HloInstruction*)> replace,
    const HloComputation& computation,
    const std::vector<OrderedInstructionPtr>& ordered_instructions,
    std::vector<UnorderedInstructionPtr>& unordered_instructions) {
  using InstructionSorter = MappedPtrContainerSorter<HloInstruction>;
  auto instruction_mapper = [&context, replace](const HloInstruction* i) {
    return context.FindInstruction(replace(i));
  };
  size_t num_mapped_instructions = 0;
  size_t mapped_index_of_last_parameter_plus_one = 0;
  for (const auto& instruction_ptr : ordered_instructions) {
    const HloInstruction* instruction;
    if constexpr (std::is_same_v<OrderedInstructionPtr, HloInstruction*>) {
      instruction = instruction_ptr;
    } else {
      instruction = instruction_ptr.get();
    }
    if (!instruction_mapper(instruction)) {
      continue;
    }
    ++num_mapped_instructions;
    if (!HloParameterInstruction::ClassOf(instruction)) {
      continue;
    }
    mapped_index_of_last_parameter_plus_one = num_mapped_instructions;
  }
  auto unmapped_ptr_index =
      [num_mapped_instructions,
       mapped_index_of_last_parameter_plus_one](const HloInstruction* i) {
        if (HloParameterInstruction::ClassOf(i)) {
          if (num_mapped_instructions > 0 &&
              mapped_index_of_last_parameter_plus_one > 0) {
            return mapped_index_of_last_parameter_plus_one - 1;
          }
          return InstructionSorter::IndexBeforeMappedElementsFn()(i);
        }
        return InstructionSorter::IndexAfterMappedElementsFn()(i);
      };
  auto status =
      InstructionSorter::Sort(instruction_mapper, unmapped_ptr_index,
                              ordered_instructions, unordered_instructions);
  if (!status.ok()) {
    LOG(ERROR) << "Failed to reorder instructions while cloning computation: "
               << computation.name() << "; " << status;
  }
}

// For cloned instructions, sorts their users, control predecessors, and control
// successors, according to the orders of those lists in the original
// instructions, before cloning. context and replace help us to map original
// instructions to cloned instructions, in addition to creating a list of
// cloned instructions.
void SortClonedInstructionUsersAndControlLists(
    const HloCloneContext& context,
    absl::FunctionRef<const HloInstruction*(const HloInstruction*)> replace,
    const HloComputation::InstructionList& sorted_instructions) {
  auto instruction_mapper = [&context, replace](const HloInstruction* i) {
    return context.FindInstruction(replace(i));
  };
  for (const HloInstructionInfo& instruction : sorted_instructions) {
    HloInstruction* cloned_instruction =
        context.FindInstruction(replace(instruction.get()));
    if (!cloned_instruction) {
      continue;
    }
    cloned_instruction->SortInstructionUsersAndControlLists(instruction_mapper,
                                                            *instruction);
  }
}

}  // namespace

std::unique_ptr<HloComputation> HloComputation::CloneWithReplacements(
    const absl::flat_hash_map<const HloInstruction*,
                              std::unique_ptr<HloInstruction>>* replacements,
    absl::Span<const HloInstruction* const> extra_parameters,
    HloCloneContext* context, const std::string& suffix,
    std::variant<const HloInstruction*, const absl::Span<HloInstruction* const>>
        new_root) {
  std::unique_ptr<HloCloneContext> context_ptr;
  if (context == nullptr) {
    context_ptr = std::make_unique<HloCloneContext>(parent(), suffix);
    context = context_ptr.get();
  }
  return CloneInContext(*context, replacements, extra_parameters, suffix,
                        new_root);
}

std::pair<std::unique_ptr<HloComputation>, std::vector<HloInstruction*>>
HloComputation::CloneWithScheduleAndReplacements(
    const absl::flat_hash_map<const HloInstruction*,
                              std::unique_ptr<HloInstruction>>* replacements,
    absl::Span<const HloInstruction* const> extra_parameters,
    HloCloneContext* context, const std::string& suffix,
    std::variant<const HloInstruction*, const absl::Span<HloInstruction* const>>
        new_root) {
  std::unique_ptr<HloCloneContext> context_ptr;
  if (context == nullptr) {
    context_ptr = std::make_unique<HloCloneContext>(parent(), suffix);
    context = context_ptr.get();
  }
  std::vector<HloInstruction*> clone_sequence;
  std::unique_ptr<HloComputation> cloned_computation =
      CloneInContext(*context, replacements, extra_parameters, suffix, new_root,
                     &clone_sequence);
  return {std::move(cloned_computation), std::move(clone_sequence)};
}

std::unique_ptr<HloComputation> HloComputation::CloneInContext(
    HloCloneContext& context,
    const absl::flat_hash_map<const HloInstruction*,
                              std::unique_ptr<HloInstruction>>* replacements,
    absl::Span<const HloInstruction* const> extra_parameters,
    const std::string& suffix,
    std::variant<const HloInstruction*, const absl::Span<HloInstruction* const>>
        new_root,
    std::vector<HloInstruction*>* clone_sequence) const {
  // Look up instr in the replacements map, and return either the replacement,
  // or instr, if the replacement isn't present.
  //
  // Note: This can return null, indicating that instr should not be present in
  // the new computation.
  auto replace = [&](const HloInstruction* instr) {
    if (!replacements) {
      return instr;
    }
    auto it = replacements->find(instr);
    return it != replacements->end() ? it->second.get() : instr;
  };
  VLOG(1) << "Cloning " << name() << " --> " << suffix << "\n";

  // We want to do a postorder walk over [replace(i) for i in instructions_].
  // We can't reuse MakeInstructionPostOrder() for this, because that will
  // generate a postorder of plain instructions_, and our replacements may
  // change the postorder!
  //
  // The postorder we want here is simpler than what MakeInstructionPostOrder()
  // does -- we only care about operand dependencies -- so let's just do it
  // ourselves.
  std::vector<const HloInstruction*> postorder;
  postorder.reserve(instruction_count());
  absl::flat_hash_map<const HloInstruction*, VisitState> visited;
  visited.reserve(instruction_count());
  std::vector<const HloInstruction*> dfs_stack;
  for (const auto& instr : instructions()) {
    const HloInstruction* new_instr = replace(instr);
    if (!new_instr) {
      continue;
    }
    dfs_stack.clear();
    dfs_stack.push_back(new_instr);

    while (!dfs_stack.empty()) {
      auto* cur = dfs_stack.back();
      auto it = visited.find(cur);
      if (it != visited.end()) {
        dfs_stack.pop_back();
        if (it->second == VisitState::kVisited) {
          continue;
        }
        CHECK_EQ(it->second, VisitState::kVisiting);
        postorder.push_back(cur);
        it->second = VisitState::kVisited;
        continue;
      }

      visited.insert({cur, VisitState::kVisiting});
      for (HloInstruction* operand : cur->operands()) {
        const HloInstruction* new_operand = replace(operand);
        if (new_operand) {
          dfs_stack.push_back(new_operand);
        }
      }
    }
  }

  std::vector<std::unique_ptr<HloInstruction>> instructions;
  instructions.reserve(postorder.size() + extra_parameters.size());
  // First add the extra parameters to 'instructions'.
  for (const auto& instr : extra_parameters) {
    CHECK_EQ(instr->opcode(), HloOpcode::kParameter)
        << "Only parameter instructions are allowed in 'extra_parameters'";
    instructions.emplace_back(instr->Clone());
  }
  HloInstruction::InstructionVector new_operands;
  for (const HloInstruction* instr : postorder) {
    new_operands.clear();
    for (HloInstruction* operand : instr->operands()) {
      auto replaced_operand = replace(operand);
      CHECK_NE(replaced_operand, nullptr)
          << "replacements map tried to eliminate a used instruction "
          << operand->ToString() << ", used by " << instr->ToString();
      new_operands.push_back(context.GetInstruction(replaced_operand));
    }
    std::unique_ptr<HloInstruction> new_instr =
        instr->CloneWithNewOperands(instr->shape(), new_operands, &context);
    if (instr->opcode() == HloOpcode::kParameter &&
        instr->parameter_replicated_at_leaf_buffers().has_value()) {
      new_instr->set_parameter_replicated_at_leaf_buffers(
          instr->parameter_replicated_at_leaf_buffers().value());
    }
    instructions.push_back(std::move(new_instr));
  }

  // To make clone behavior match uncloned behavior, we reorder instructions to
  // match the order in instructions_.
  SortClonedInstructions(context, replace, *this, instructions_, instructions);

  if (clone_sequence != nullptr) {
    clone_sequence->reserve(instructions.size());
    absl::c_transform(instructions, std::back_inserter(*clone_sequence),
                      [](const std::unique_ptr<HloInstruction>& instruction) {
                        return instruction.get();
                      });

    SortClonedInstructions(
        context, replace, *this,
        context.module()->schedule().sequence(this).instructions(),
        *clone_sequence);
  }

  Builder builder(suffix.empty() ? std::string(name())
                                 : absl::StrCat(name(), ".", suffix));
  for (auto& instr : instructions) {
    builder.AddInstruction(std::move(instr));
  }

  // Figure out the new root instruction for the clone. There are three cases:
  // 1. The new root is just the old root (nullptr `new_root` instruction)
  // 2. The new root is a different instruction in the computation (non-null
  // `new_root` instruction)
  // 3. The new root is a tuple of instructions, where the instructions are part
  // of the computation, but the tuple did not previously exist (`new_root`
  // span).
  HloInstruction* new_root_instruction;
  std::visit(absl::Overload{
                 [&](const HloInstruction* arg) {
                   if (arg == nullptr) {
                     new_root_instruction =
                         context.GetInstruction(replace(root_instruction()));
                   } else {
                     new_root_instruction =
                         context.GetInstruction(replace(arg));
                   }
                 },
                 [&](const absl::Span<HloInstruction* const> arg) {
                   std::vector<HloInstruction*> root_replacements;
                   for (HloInstruction* instr : arg) {
                     root_replacements.push_back(
                         context.GetInstruction(replace(instr)));
                   }
                   new_root_instruction = builder.AddInstruction(
                       HloInstruction::CreateTuple(root_replacements));
                 },
             },
             new_root);

  auto result = builder.Build(
      /*root_instruction=*/new_root_instruction);

  // Clone control dependencies.
  for (auto instr : postorder) {
    HloInstruction* new_instr = context.GetInstruction(instr);
    for (auto successor : instr->control_successors()) {
      auto replaced_successor = replace(successor);
      // successor may not have been remapped, because it might have been
      // removed by the replacements map.
      if (replaced_successor != nullptr) {
        CHECK_OK(new_instr->AddControlDependencyTo(
            context.GetInstruction(replaced_successor)));
      }
    }
  }

  // To make clone behavior match uncloned behavior, we reorder the user and
  // control lists, kept by cloned instructions.
  SortClonedInstructionUsersAndControlLists(context, replace, instructions_);

  context.MapComputation(this, result.get());
  result->SetExecutionThread(execution_thread());
  result->backend_config_ = backend_config_;
  return result;
}

void HloComputation::UniquifyName(NameUniquer* name_uniquer) {
  name_ = name_uniquer->GetUniqueName(name_);
}

void HloComputation::UniquifyName(HloModule* module) {
  UniquifyName(&module->computation_name_uniquer());
}

HloInstruction* HloComputation::GetInstructionWithName(absl::string_view name) {
  auto instructions_in_computation = instructions();
  auto it = absl::c_find_if(
      instructions_in_computation,
      [&](HloInstruction* instr) { return instr->name() == name; });
  return it == instructions_in_computation.end() ? nullptr : *it;
}

bool HloComputation::IsEntryComputation() const {
  return parent()->entry_computation() == this;
}

bool HloComputation::CanExpandIntoSingleInstruction() const {
  return absl::c_all_of(
      instructions(), [root = root_instruction()](const HloInstruction* instr) {
        return root == instr || instr->opcode() == HloOpcode::kParameter;
      });
}

bool HloComputation::IsFusionComputation() const {
  return !caller_instructions(HloOpcode::kFusion).empty();
}

HloInstruction* HloComputation::FusionInstruction() const {
  auto callers = caller_instructions(HloOpcode::kFusion);
  return callers.empty() ? nullptr : callers.front();
}

bool HloComputation::IsAsyncComputation() const {
  return !caller_instructions(HloOpcode::kAsyncStart).empty() ||
         !caller_instructions(HloOpcode::kAsyncDone).empty() ||
         !caller_instructions(HloOpcode::kAsyncUpdate).empty();
}

bool HloComputation::OnlyContainsSendRecv() const {
  return absl::c_all_of(instructions(), [](const HloInstruction* instruction) {
    return HloPredicateIsOp<HloOpcode::kSend, HloOpcode::kRecv,
                            HloOpcode::kBitcast, HloOpcode::kParameter,
                            HloOpcode::kTuple>(instruction);
  });
}

// The returned callers are in no particular order.
absl::InlinedVector<HloInstruction*, 1> HloComputation::caller_instructions(
    std::optional<HloOpcode> caller_opcode) const {
  if (const absl::flat_hash_map<HloInstruction*, int>* map = GetCallersMap()) {
    absl::InlinedVector<HloInstruction*, 1> result;
    // NOLINTNEXTLINE(*-custom-deterministic-iteration-order)
    for (const auto [instr, count] : *map) {
      if (count == 0) {
        continue;
      }
      if (!caller_opcode.has_value() || instr->opcode() == *caller_opcode) {
        result.push_back(instr);
      }
    }
    return result;
  }

  if (callers_ == 0) {
    return {};
  }

  auto* instr = reinterpret_cast<HloInstruction*>(callers_ & ~kCallerTypeMask);
  if (!caller_opcode.has_value() || instr->opcode() == *caller_opcode) {
    return {instr};
  }

  return {};
}

std::optional<HloInstruction*> HloComputation::GetUniqueCaller(
    HloOpcode opcode) const {
  auto callers = caller_instructions(opcode);
  if (callers.size() == 1) {
    return callers.front();
  }
  return std::nullopt;
}

HloInstruction* HloComputation::GetInstructionWithLocalId(int32_t local_id) {
  if (local_id < 0 || local_id >= instructions_.size()) {
    return nullptr;
  }
  return instructions_[local_id].get();
}

void HloComputation::ClearUniqueIdInternal() { SetUniqueIdHelper(-1); }

void HloComputation::SetUniqueId(int64_t id) {
  CHECK_EQ(unique_id_, -1);
  CHECK_GE(id, 0);
  CHECK_LT(id, INT32_MAX) << "Unique ID must fit in an int32_t";
  SetUniqueIdHelper(id);
}

void HloComputation::SetUniqueIdHelper(int64_t id) {
  // The caller/callee computations are ordered by unique ID, so we need to
  // remove and readd them to our neighbor's data structures.
  for (auto& [computation, count] : caller_computations_) {
    auto it = computation->callee_computations_.find(this);
    CHECK(it != computation->callee_computations_.end());
    CHECK_EQ(it->second, count);
    computation->callee_computations_.erase(it);
  }
  for (auto& [computation, count] : callee_computations_) {
    auto it = computation->caller_computations_.find(this);
    CHECK(it != computation->caller_computations_.end());
    CHECK_EQ(it->second, count);
    computation->caller_computations_.erase(it);
  }
  unique_id_ = id;
  for (auto& [computation, count] : caller_computations_) {
    computation->callee_computations_[this] = count;
  }
  for (auto& [computation, count] : callee_computations_) {
    computation->caller_computations_[this] = count;
  }
}

bool HloComputation::IsEntryInstUnboundedDynamic() const {
  for (HloInstruction* instruction : parameter_instructions()) {
    if (instruction->shape().is_unbounded_dynamic()) {
      return true;
    }
  }
  return root_instruction()->shape().is_unbounded_dynamic();
}

template <typename HloInstructionPtr>
absl::Status HloComputation::Accept(
    DfsHloVisitorBase<HloInstructionPtr>* visitor) const {
  // Visit unreachable roots. Beware that the visitor might delete the currently
  // visited root, which would invalidate iterators if the unreachable roots
  // weren't computed ahead of time.
  for (HloInstruction* root : CollectUnreachableRoots()) {
    VLOG(3) << "Traversing unreachable root: " << root->ToString();
    // Call FinishVisit only at the end.
    ABSL_RETURN_IF_ERROR(root->Accept(visitor, /*call_finish_visit=*/false));
  }
  // Visit the computation root instruction last.
  return root_instruction()->Accept(visitor, /*call_finish_visit=*/true);
}

// Explicit instantiations.
template absl::Status HloComputation::Accept(DfsHloVisitor* visitor) const;
template absl::Status HloComputation::Accept(ConstDfsHloVisitor* visitor) const;

template <typename HloInstructionPtr>
absl::Status HloComputation::AcceptOrdered(
    DfsHloVisitorBase<HloInstructionPtr>* visitor,
    absl::Span<HloInstruction* const> order) const {
  VLOG(3) << "Accepting visitor with order.";
  for (HloInstruction* root : CollectUnreachableRoots()) {
    TF_RET_CHECK(absl::c_linear_search(order, root)) << root->ToString();
  }
  TF_RET_CHECK(order.size() == instruction_count());
  absl::flat_hash_set<const HloInstruction*> visited;
  for (HloInstruction* instruction : order) {
    VLOG(3) << "Visiting ordered: " << instruction->ToString();
    TF_RET_CHECK(visited.insert(instruction).second)
        << "Instruction " << instruction->name()
        << " appears more than once in order";
    ABSL_RETURN_IF_ERROR(visitor->Preprocess(instruction));
    ABSL_RETURN_IF_ERROR(instruction->Visit(visitor));
    visitor->SetVisited(*instruction);
    ABSL_RETURN_IF_ERROR(visitor->Postprocess(instruction));
  }
  return visitor->FinishVisit(root_instruction());
}

// Explicit instantiations.
template absl::Status HloComputation::AcceptOrdered(
    DfsHloVisitor* visitor, absl::Span<HloInstruction* const> order) const;
template absl::Status HloComputation::AcceptOrdered(
    ConstDfsHloVisitor* visitor, absl::Span<HloInstruction* const> order) const;

}  // namespace xla
