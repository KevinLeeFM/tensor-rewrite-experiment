"""Build value pilot, audit axiom dependencies, check negative control, measure LOC."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
from lean_size import count_source
ROOT=Path(__file__).resolve().parents[1]

def main():
 outputs={}
 def run(name,cmd):
  p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
  outputs[name]={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
  return p
 for name,cmd in [('build',['lake','build']),('audit',['lake','env','lean','TensorRewrite/Pilot/Audit.lean']),('controls',['lake','env','lean','tests/fixtures/PilotControls.lean']),('transpose_controls',['lake','env','lean','tests/fixtures/TransposeControls.lean']),('float_exception_controls',['lake','env','lean','tests/fixtures/FloatExceptionalControls.lean']),('empty_slice_controls',['lake','env','lean','tests/fixtures/EmptySliceControls.lean'])]:
  p=run(name,cmd)
  if p.returncode or 'warning:' in p.stdout+p.stderr: raise RuntimeError(outputs[name])
 for name,fixture in [('invalid_control','InvalidPilot'),('invalid_reverse','InvalidReverse'),('invalid_transpose','InvalidTranspose'),('invalid_subtract','InvalidSubtract'),('invalid_float_exception','InvalidFloatExceptional'),('invalid_empty_slice','InvalidEmptySlice')]:
  p=run(name,['lake','env','lean','tests/fixtures/'+fixture+'.lean'])
  if p.returncode==0 or 'rfl' not in p.stdout+p.stderr: raise RuntimeError('Invalid proof was not rejected as expected')
 ledger=json.loads((ROOT/'census/pilot-value-proofs.json').read_text())
 rules=ledger['rules']
 support=ledger.get('support_theorems',[])
 numerical=ledger.get('numerical_refutation',{})
 shape=ledger.get('shape_refutation',{})
 refutations=numerical.get('refutation_theorems',[])+shape.get('refutation_theorems',[])
 consistency=numerical.get('consistency_theorems',[])+shape.get('consistency_theorems',[])
 witnesses=shape.get('witness_theorems',[])
 deps={name:[a.strip() for a in axioms.split(',') if a.strip()] for name,axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",outputs['audit']['stdout'])}
 for name in re.findall(r"'([^']+)' does not depend on any axioms", outputs['audit']['stdout']):
  deps[name]=[]
 expected=[r['theorem'] for r in rules]+support+refutations+consistency+witnesses
 assert len(expected)==len(set(expected)), 'duplicate theorem accounting'
 assert set(deps)==set(expected)
 assert all(set(axioms)<={'propext','Quot.sound','Classical.choice'} for axioms in deps.values())
 assert all(not deps[name] for name in refutations+consistency+witnesses)
 targets=shape.get('targets',[])
 assert len(targets)==len(shape.get('case_ids',[]))
 assert {t['case_id'] for t in targets}==set(shape.get('case_ids',[]))
 assert {t[k] for t in targets for k in ('refutation_theorem','not_preserving_theorem')}==set(shape.get('refutation_theorems',[]))
 assert {t['witness_theorem'] for t in targets}==set(witnesses)
 shape_cases={c['id'] for c in json.loads((ROOT/'census/shape-cases.json').read_text())['cases']}
 assert set(shape.get('case_ids',[]))<=shape_cases
 categories={'S':['TensorRewrite/Pilot/Tensor.lean','TensorRewrite/Pilot/Indexing.lean','TensorRewrite/Pilot/Permutation.lean','TensorRewrite/Pilot/PermutationArrays.lean','TensorRewrite/Pilot/PermutationLoop.lean','TensorRewrite/Pilot/Float32Exceptional.lean','TensorRewrite/Pilot/SliceShape.lean'],
             'H':['TensorRewrite/Pilot/IndexLemmas.lean','TensorRewrite/Pilot/PermutationArrayLemmas.lean','TensorRewrite/Pilot/PermutationLoopLemmas.lean'],
             'R':['TensorRewrite/Pilot/Boolean.lean','TensorRewrite/Pilot/Bitwise.lean','TensorRewrite/Pilot/Reverse.lean','TensorRewrite/Pilot/Transpose.lean','TensorRewrite/Pilot/Subtract.lean'],
             'A':['TensorRewrite.lean'],
             'C':['TensorRewrite/Pilot/PredMulRefutation.lean','TensorRewrite/Pilot/EmptySliceRefutation.lean']}
 rows=[]
 for category,paths in categories.items():
  for name in paths:
   data=(ROOT/name).read_bytes()
   rows.append({'path':name,'category':category,'sha256':hashlib.sha256(data).hexdigest(),**count_source(data.decode())})
 report={'schema':1,'status':'kernel_checked_values_and_explicit_contract_refutation_not_full_source_acceptance',
         'checked_value_theorems':len(rules),'checked_support_theorems':len(support),'accepted_source_rewrites':0,
         'checked_refutation_theorems':len(refutations),'checked_contract_consistency_theorems':len(consistency),
         'checked_shape_witness_theorems':len(witnesses),
         'refuted_value_targets_under_explicit_contract':1 if numerical.get('refutation_theorems') else 0,
         'refuted_shape_targets_under_explicit_contract':len(shape.get('case_ids',[])),
         'numerical_refutation_scope':numerical,
         'shape_refutation_scope':shape,
         'axiom_dependencies':deps,'checks':outputs,'files':rows,
         'category_lines':{c:sum(r['code_lines'] for r in rows if r['category']==c) for c in categories},
         'total_custom_lean_lines':sum(r['code_lines'] for r in rows),
         'refutation_certificate_lines':sum(r['code_lines'] for r in rows if r['category']=='C'),
         'measurement_scope':'full custom Lean value and static-shape development; audit/test files excluded and reported separately',
         'test_audit_lines':{name:count_source((ROOT/name).read_text()) for name in ['TensorRewrite/Pilot/Audit.lean','tests/fixtures/PilotControls.lean','tests/fixtures/InvalidPilot.lean','tests/fixtures/InvalidReverse.lean','tests/fixtures/TransposeControls.lean','tests/fixtures/InvalidTranspose.lean','tests/fixtures/InvalidSubtract.lean','tests/fixtures/FloatExceptionalControls.lean','tests/fixtures/InvalidFloatExceptional.lean','tests/fixtures/EmptySliceControls.lean','tests/fixtures/InvalidEmptySlice.lean']}}
 (ROOT/'reports/pilot-values.json').write_text(json.dumps(report,indent=2)+'\n')
 print('Pilot passed:',report['checked_value_theorems'],'value theorems;',report['category_lines'],'source rewrites accepted: 0')
if __name__=='__main__':main()
