Offline typed-evidence replay (Python standard library):

python tools/typed_call_inventory.py
python tools/typed_delegation_evidence.py
python tools/check_typed_call_evidence.py

This replays archived compiler output. It does not rerun C++ compilation, Lean or independent source review. Compiler/header identities are provenance, not a hermetic compiler-input closure.
