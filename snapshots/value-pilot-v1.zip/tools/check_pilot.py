"""Build value pilot, audit axiom dependencies, check negative control, measure LOC."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
from lean_size import count_source
ROOT=Path(__file__).resolve().parents[1]

def main():
 outputs={}
 def run(name,cmd):
  p=subprocess.run(cmd,cwd=ROOT,text=True,capture_output=True)
  outputs[name]={'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
  return p
 for name,cmd in [('build',['lake','build']),('audit',['lake','env','lean','TensorRewrite/Pilot/Audit.lean']),('controls',['lake','env','lean','tests/fixtures/PilotControls.lean'])]:
  p=run(name,cmd)
  if p.returncode or 'warning:' in p.stdout+p.stderr: raise RuntimeError(outputs[name])
 p=run('invalid_control',['lake','env','lean','tests/fixtures/InvalidPilot.lean'])
 if p.returncode==0 or 'rfl' not in p.stdout+p.stderr: raise RuntimeError('Invalid proof was not rejected as expected')
 rules=json.loads((ROOT/'census/pilot-value-proofs.json').read_text())['rules']
 deps={name:[a.strip() for a in axioms.split(',') if a.strip()] for name,axioms in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",outputs['audit']['stdout'])}
 assert set(deps)=={r['theorem'] for r in rules}
 assert all(set(axioms)<={'propext','Quot.sound','Classical.choice'} for axioms in deps.values())
 categories={'S':['TensorRewrite/Pilot/Tensor.lean'], 'H':[],
             'R':['TensorRewrite/Pilot/Boolean.lean','TensorRewrite/Pilot/Bitwise.lean'],
             'A':['TensorRewrite.lean']}
 rows=[]
 for category,paths in categories.items():
  for name in paths:
   data=(ROOT/name).read_bytes()
   rows.append({'path':name,'category':category,'sha256':hashlib.sha256(data).hexdigest(),**count_source(data.decode())})
 report={'schema':1,'status':'kernel_checked_value_pilot_not_source_rewrite_acceptance',
         'checked_value_theorems':len(rules),'accepted_source_rewrites':0,
         'axiom_dependencies':deps,'checks':outputs,'files':rows,
         'category_lines':{c:sum(r['code_lines'] for r in rows if r['category']==c) for c in categories},
         'measurement_scope':'full custom Lean value development; audit/test files excluded and reported separately',
         'test_audit_lines':{name:count_source((ROOT/name).read_text()) for name in ['TensorRewrite/Pilot/Audit.lean','tests/fixtures/PilotControls.lean','tests/fixtures/InvalidPilot.lean']}}
 (ROOT/'reports/pilot-values.json').write_text(json.dumps(report,indent=2)+'\n')
 print('Pilot passed:',report['checked_value_theorems'],'value theorems;',report['category_lines'],'source rewrites accepted: 0')
if __name__=='__main__':main()
