import TensorRewrite

#print axioms TensorRewrite.Pilot.Boolean.not_not
#print axioms TensorRewrite.Pilot.Boolean.and_rhs_false
#print axioms TensorRewrite.Pilot.Boolean.and_rhs_true
#print axioms TensorRewrite.Pilot.Boolean.and_lhs_false
#print axioms TensorRewrite.Pilot.Boolean.and_lhs_true
#print axioms TensorRewrite.Pilot.Boolean.or_rhs_false
#print axioms TensorRewrite.Pilot.Boolean.or_rhs_true
#print axioms TensorRewrite.Pilot.Boolean.or_lhs_false
#print axioms TensorRewrite.Pilot.Boolean.or_lhs_true
#print axioms TensorRewrite.Pilot.Boolean.xor_self
#print axioms TensorRewrite.Pilot.Boolean.xor_rhs_zero
#print axioms TensorRewrite.Pilot.Boolean.xor_lhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.not_not
#print axioms TensorRewrite.Pilot.Bitwise.and_rhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.and_lhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.or_rhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.or_lhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.xor_rhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.xor_lhs_zero
#print axioms TensorRewrite.Pilot.Bitwise.xor_self
