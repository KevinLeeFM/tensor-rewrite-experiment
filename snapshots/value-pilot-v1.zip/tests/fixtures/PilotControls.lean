import TensorRewrite

open TensorRewrite.Pilot Tensor

private abbrev scalarShape : Shape 0 := fun i => Fin.elim0 i

-- Rank zero has an index, so false identities cannot pass vacuously.
example : map₂ Bool.and (constant true : Tensor scalarShape Bool) (constant true) ≠
    constant false := by
  intro h
  have impossible : true = false := congrFun h (fun i => Fin.elim0 i)
  cases impossible

-- An extent of zero creates no legal indices, as required by empty tensors.
example (x y : Tensor (fun (_ : Fin 1) => 0) Bool) : x = y := by
  funext i
  exact Fin.elim0 (i 0)
